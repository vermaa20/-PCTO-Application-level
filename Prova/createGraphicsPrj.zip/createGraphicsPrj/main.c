#include <stdio.h>
#include <stdlib.h>
#include "utility.h"

int main(int argc, char *argv[]) 
{
	printf("\n Inizio....");
	getchar();
	
	
	
	lettura ();
	
	printf("\n letture eseguita");
	scrittura();
	
	bat();
	plc();
	
	return 0;
}


