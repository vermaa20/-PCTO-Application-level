#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utility.h"

#define MAX 1000

int main(){

   int secondi1[MAX], secondi2[MAX], secondi3[MAX], secondi4[MAX], secondi5[MAX], secondi6[MAX], secondi7[MAX], secondi8[MAX], secondi9[MAX], secondi10[MAX], secondi11[MAX], *contTipo;
    float risposta1[MAX], risposta2[MAX], risposta3[MAX], risposta4[MAX], risposta5[MAX], risposta6[MAX], risposta7[MAX], risposta8[MAX], risposta9[MAX], risposta10[MAX], risposta11[MAX];

	lettura (risposta1, secondi1, risposta2, secondi2, risposta3, secondi3, risposta4, secondi4, risposta5, secondi5, risposta6, secondi6, risposta7, secondi7, risposta8, secondi8, risposta9, secondi9, risposta10, secondi10, risposta11, secondi11);
	scrittura1(risposta1, secondi1, contTipo);
	scrittura2(risposta2, secondi2, contTipo);
	scrittura3(risposta3, secondi3, contTipo);
	scrittura4(risposta4, secondi4, contTipo);
	scrittura5(risposta5, secondi5, contTipo);
	scrittura6(risposta6, secondi6, contTipo);
	scrittura7(risposta7, secondi7, contTipo);
	scrittura8(risposta8, secondi8, contTipo);
	scrittura9(risposta9, secondi9, contTipo);
	scrittura10(risposta10, secondi10, contTipo);
	scrittura11(risposta11, secondi11, contTipo);

	bat1();
	bat2();
	bat3();
	bat4();
	bat5();
	bat6();
	bat7();
	bat8();
	bat9();
	bat10();
	bat11();
	plot();

	return 0;
}

