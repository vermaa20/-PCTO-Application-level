#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utility.h"
#define MAX_DATI 1000


int main(){
    int ymin = 0, punt, count;
    float *puntRis;
    float risposta[MAX_DATI];
    int secondi[MAX_DATI];

	count = lettura (risposta, secondi);
	scrittura(risposta, secondi, count);
	bat();
	plot();

	return 0;
}

