#ifndef UTILITY_H
#define UTILITY_H
#define MAX 4

void lettura ();
void scrittura1();
void scrittura2();
void scrittura3();
void scrittura4();
void scrittura5();
void scrittura6();
void scrittura7();
void scrittura8();
void scrittura9();
void scrittura10();
void scrittura11();
void bat1();
void bat2();
void bat3();
void bat4();
void bat5();
void bat6();
void bat7();
void bat8();
void bat9();
void bat10();
void bat11();
void plot();


#endif // UTILITY_H


