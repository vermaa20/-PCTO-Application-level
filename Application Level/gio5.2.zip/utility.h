#ifndef UTILITY_H
#define UTILITY_H
#define MAX 4

int lettura();
void scrittura();
void stampa();
void bat();
void plot();

#endif // UTILITY_H

