#include "stdint.h"
/**********************************************************
*
* The following software is for demonstration purposes only.
* It is not fully tested, nor validated in order to fullfill
* its task under all circumstances. Therefore, this software
* or any part of it must only be used in an evaluation
* laboratory environment.
* This software is subject to the rules of Accemic's
* standard DISCLAIMER, available at www.accemic.com.
*
* Copyright (c) 2001-2005 Accemic GmbH & Co. KG
* All rights reserved
*
***********************************************************
*
* Module name        : cpu.h
* Version            : 1.30
* Date of creation.  : 07.03.2003
* Last Modification  : 17.01.2005
* Authors            : Rainer Harthaus (RH)
* 
***********************************************************
* 
* Description: 
* - CPU series definition 
* - bootloader UART ICR definition
*
***********************************************************
*
* History
*
* Vers   * Datum    * Name  * Subject
* 1.00   * 07.03.03 * RH    * first creation
* 1.10   * 09.02.04 * RH    * new MCU families added
* 1.20   * 28.04.04 * RH    * new MCU families added
* 1.30   * 17.01.05 * RH    * new MCU families added
*
***********************************************************
*
* Please visit www.accemic.com
* for updates and other valuable developer ressources
*
**********************************************************/

#ifndef CPU_16LX_H
#define CPU_16LX_H

/**********************************************************
* 330 series
* Bootloader: UART 0
***********************************************************/
#if   defined(__CPU_MB90F334__)  || defined(__CPU_MB90F334A__)
#define __CPU_MB90330_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  14

/**********************************************************
* 335 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F337__)
#define __CPU_MB90335_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  14

/**********************************************************
* 340 series
* Bootloader: UART 0
***********************************************************/
#elif defined(__CPU_MB90F342__)  || defined(__CPU_MB90F342S__)  || \
      defined(__CPU_MB90F342C__) || defined(__CPU_MB90F342CS__) || \
      defined(__CPU_MB90F343__)  || defined(__CPU_MB90F343S__)  || \
      defined(__CPU_MB90F343C__) || defined(__CPU_MB90F343CS__) || \
      defined(__CPU_MB90F345__)  || defined(__CPU_MB90F345S__)  || \
      defined(__CPU_MB90F345C__) || defined(__CPU_MB90F345CS__) || \
      defined(__CPU_MB90F346__)  || defined(__CPU_MB90F346S__)  || \
      defined(__CPU_MB90F346C__) || defined(__CPU_MB90F346CS__) || \
      defined(__CPU_MB90F347__)  || defined(__CPU_MB90F347S__)  || \
      defined(__CPU_MB90F347C__) || defined(__CPU_MB90F347CS__) || \
      defined(__CPU_MB90F347D__) || defined(__CPU_MB90F347DS__) || \
      defined(__CPU_MB90F349__)  || defined(__CPU_MB90F349S__)  || \
      defined(__CPU_MB90F349C__) || defined(__CPU_MB90F349CS__)
#define __CPU_MB90340_SERIES 1
#define monitor_icr_tx  12
#define monitor_icr_rx  12

/**********************************************************
* 350 series
* Bootloader: UART 3
***********************************************************/
#elif   defined(__CPU_MB90F352__)  || defined(__CPU_MB90F352S__)  || \
        defined(__CPU_MB90F352C__) || defined(__CPU_MB90F352CS__)
#define __CPU_MB90350_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 385 series
* Bootloader: UART
***********************************************************/
#elif   defined(__CPU_MB90F387__)  || defined(__CPU_MB90F387S__)
#define __CPU_MB90385_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 390 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F394__)  || defined(__CPU_MB90F394H__)
#define __CPU_MB90390_SERIES 1
#define monitor_icr_tx  12
#define monitor_icr_rx  12

/**********************************************************
* 420 series
* Bootloader: UART 1
***********************************************************/
#elif defined(__CPU_MB90F423GA__) || defined(__CPU_MB90F423GB__) || \
      defined(__CPU_MB90F423GC__) || defined(__CPU_MB90F428GC__) || \
      defined(__CPU_MB90F428GA__) || defined(__CPU_MB90F428GB__) 
#define __CPU_MB90420_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 425 series
* Bootloader: UART 1
***********************************************************/
#elif   defined(__CPU_MB90F428GA__) || defined(__CPU_MB90F428GB__) || \
        defined(__CPU_MB90F428GC__)
#define __CPU_MB90425_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 435 series
* Bootloader: UART 1
***********************************************************/
#elif   defined(__CPU_MB90F438L__) || defined(__CPU_MB90F438LS__)  || \
        defined(__CPU_MB90F439__)  || defined(__CPU_MB90F439S__)
#define __CPU_MB90435_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14

/**********************************************************
* 440 series
* Bootloader: UART 
***********************************************************/
#elif   defined(__CPU_MB90F443G__)
#define __CPU_MB90440_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14

/**********************************************************
* 455 series
* Bootloader: UART
***********************************************************/
#elif   defined(__CPU_MB90F455__)  || defined(__CPU_MB90F455S__) || \
        defined(__CPU_MB90F456__)  || defined(__CPU_MB90F456S__) || \
        defined(__CPU_MB90F457__)  || defined(__CPU_MB90F457S__)
#define __CPU_MB90455_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 460 series
* Bootloader: UART 0
**********************************************************/
#elif   defined(__CPU_MB90F462__)
#define __CPU_MB90460_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14

/**********************************************************
* 470 series
* Bootloader: UART 0
**********************************************************/
#elif   defined(__CPU_MB90F474__)  || defined(__CPU_MB90F474H__) || \
        defined(__CPU_MB90F474L__)
#define __CPU_MB90470_SERIES 1
#define monitor_icr_tx  11
#define monitor_icr_rx  12

/**********************************************************
* 480 series
* Bootloader: UART 0
**********************************************************/
#elif   defined(__CPU_MB90F481__) || defined(__CPU_MB90F482__) || \
        defined(__CPU_MB90F483__)
#define __CPU_MB90480_SERIES 1
#define monitor_icr_tx  11
#define monitor_icr_rx  12

/**********************************************************
* 485 series
* Bootloader: UART 0
**********************************************************/
#elif   defined(__CPU_MB90F488__)
#define __CPU_MB90485_SERIES 1
#define monitor_icr_tx  11
#define monitor_icr_rx  12

/**********************************************************
* 495 series
* Bootloader: UART 1
***********************************************************/
#elif   defined(__CPU_MB90F497__)  || defined(__CPU_MB90F497G__) || \
        defined(__CPU_MB90F498__)  || defined(__CPU_MB90F498G__)
#define __CPU_MB90495_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 520 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F523__) || defined(__CPU_MB90F523B__)
#define __CPU_MB90520_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  14

/**********************************************************
* 540 series
* Bootloader: UART 1
***********************************************************/
#elif   defined(__CPU_MB90F543__)  || \
        defined(__CPU_MB90F543G__) || defined(__CPU_MB90F543GS__)
#define __CPU_MB90540_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14

/**********************************************************
* 545 series
* Bootloader: UART 1
***********************************************************/
#elif   defined(__CPU_MB90F548__)     || \
	    defined(__CPU_MB90F546__)   || defined(__CPU_MB90F546G__)   || \
	    defined(__CPU_MB90F546GS__) || defined(__CPU_MB90F548G__)   || \
	    defined(__CPU_MB90F548GL__) || defined(__CPU_MB90F548GLS__) || \
	    defined(__CPU_MB90F548GS__) || defined(__CPU_MB90F549__)    || \
	    defined(__CPU_MB90F549G__)  || defined(__CPU_MB90F549GS__)
#define __CPU_MB90545_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14

/**********************************************************
* 550 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F553A__)
#define __CPU_MB90550A_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  14

/**********************************************************
* 560 series
* Bootloader: UART 1 (P60/61)
***********************************************************/
#elif   defined(__CPU_MB90F562__)  || defined(__CPU_MB90F562B__)
#define __CPU_MB90560_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 565 series
* Bootloader: UART 1 (P60/61)
***********************************************************/
#elif   defined(__CPU_MB90F568__)
#define __CPU_MB90565_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 570 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F574__)  || defined(__CPU_MB90F574A__)
#define __CPU_MB90570_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14

/**********************************************************
* 580 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F583__)  || defined(__CPU_MB90F583B__)  || \
	      defined(__CPU_MB90F583C__) || defined(__CPU_MB90F583CA__) || \
  	    defined(__CPU_MB90F584C__) || defined(__CPU_MB90F584CA__)
#define __CPU_MB90580_SERIES 1
#define monitor_icr_tx  11
#define monitor_icr_rx  14

/**********************************************************
* 590 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F591__)  || defined(__CPU_MB90F591A__) || \
	    defined(__CPU_MB90F591G__) || defined(__CPU_MB90F594A__) || \
		defined(__CPU_MB90F594__)
#define __CPU_MB90590_SERIES 1
#define monitor_icr_tx  12
#define monitor_icr_rx  12

/**********************************************************
* 595 series
* Bootloader: UART 1
***********************************************************/
#elif   defined(__CPU_MB90F598__)  || defined(__CPU_MB90F598G__)
#define __CPU_MB90595_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14

/**********************************************************
* 800 series
* Bootloader: UART 0
***********************************************************/
#elif  defined(__CPU_MB90F804__) 
#define __CPU_MB90800_SERIES 1
#define monitor_icr_tx  12
#define monitor_icr_rx  12

/**********************************************************
* 820 series
* Bootloader: UART 0
***********************************************************/
#elif  defined(__CPU_MB90F822__)  || defined(__CPU_MB90F823__)
#define __CPU_MB90820_SERIES 1
#define monitor_icr_tx  14
#define monitor_icr_rx  14


/**********************************************************
* 860 series
* Bootloader: UART 1
***********************************************************/
#elif  defined(__CPU_MB90F867__)  || defined(__CPU_MB90F867S__) || \
       defined(__CPU_MB90F867A__)
#define __CPU_MB90860_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 895 series
* Bootloader: UART 1
***********************************************************/
#elif   defined(__CPU_MB90F897__)  || defined(__CPU_MB90F897S__)
#define __CPU_MB90895_SERIES 1
#define monitor_icr_tx  13
#define monitor_icr_rx  13

/**********************************************************
* 945 series
* Bootloader: UART 0
***********************************************************/
#elif   defined(__CPU_MB90F947__) 
#define __CPU_MB90945_SERIES 1
#define monitor_icr_tx  12
#define monitor_icr_rx  12

#else
/**********************************************************
* Error: Your selected CPU is not defined in "cpu_16lx.h"
***********************************************************/
  #error Your selected CPU is not found in "cpu_16lx.h"
#endif

#endif // CPU_16LX_H