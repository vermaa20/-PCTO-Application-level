#include "stdint.h"
#define MUX_LOW_LEVEL_C					// used to enable variable generation in mux_low_level.h

#include "sistema.h"

#ifndef ACCEMIC_ON
 #ifdef	EMULATOR_ON
	#include "ram_code.h"
 #endif
#endif


#include "mux_low_level.h"
#include "time.h"
#include "vectors.h"
#include "hw.h"

#ifdef EMULATOR_ON
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------
// sets the Mux communication lines to idle state
__far void mux_init(void)
{
	// direction register
	PORT_MUX_CK_P = 1;					// output
	PORT_MUX_D_P = 0;					// input
	// initial value
	MUX_D_P = 0;
	MUX_CK_P = 1;

	// uses 16bit I/O Timer to generate very int16_t delays
	// TCCS: 16bit I/O Timer Control Status Register
	//	bit		Description
	//	7		Reseved
	//	6		Irq request flag. (1=irq request)
	//	5		Irq enable bit (1=Irq enabled)
	//	4		Timer STOP. (1= stopped)
	//	3		Counter reset MODE. (0= reset by clear bit; 1=by clear bit and compare register 0)
	//	2		CLR bit. (1=resets counter)
	//	1		CLK1	prescaler
	//	0		CLK0	prescaler
	//		prescaler table
	//		CLK1	CLK0	clock/x
	//		0		0		4
	//		0		1		16
	//		1		0		64
	//		1		1		256
	TCCS = 0x11;					//no IRQ, stopped, clock/16 (@16MHz -> 1us)

	// resets internal mux
	analog_switch_driver(AS_OFF);

	// init related vars
	mux_ext_cfg = 0x0000L;
	mux_int_cfg = 0x00;
	mux_status = MUX_PC_STATUS_IDLE;
}

// sends a frame to the mux
// checks the 2nd uint8_t for the frame length
// the frame length must be equal or greater than 5
// the frame to be sent must include the checksum
// the structure is:
// SOF, Length, Function, [Data], Cheksum H, Checksum L
__far void mux_send_frame(BYTE *_p_frame)
{
	BYTE data;
	BYTE ind;
	BYTE len;
	WORD start_time;

	PORT_MUX_D_P = 1;					// output

	// frame length
	len = *(_p_frame + 1);

	// generates the Start
	ResetOrol(&start_time);
	MUX_CK_P = 0;

	while(GetTime(&start_time) < MUX_T_START);

	// sends the frame to the mux
	while(len--)
	{
		// byte to send
		data = *_p_frame++;

		// shifts out the bits (LSB first)
		for (ind = 0; ind < 8; ind++)
		{
			MUX_CK_P = 0;	
			
			// waits for MUX_T_WAIT/2 at least
			// resets timer
			TCCS_STOP = 1;
			TCDT = 0x0000;
			TCCS_STOP = 0;
			while(TCDT < (MUX_T_WAIT_0 / 2));

			if (data & 0x01)
				MUX_D_P = 1;		
			else
				MUX_D_P = 0;		

			// waits for MUX_T_WAIT/2 at least
			// resets timer
			TCCS_STOP = 1;
			TCDT = 0x0000;
			TCCS_STOP = 0;
			while(TCDT < (MUX_T_WAIT_0 / 2));

			data >>= 1;

			MUX_CK_P = 1;	

			// waits for MUX_T_WAIT at least
			// resets timer
			TCCS_STOP = 1;
			TCDT = 0x0000;
			TCCS_STOP = 0;
			while(TCDT < MUX_T_WAIT_1);
		}
	}

	PORT_MUX_D_P = 0;					// input

	// generates the Interval between request and answer
	ResetOrol(&start_time);
	while(GetTime(&start_time) < MUX_T_INTERVAL);
}

// gets a frame from the mux
// checks the 2nd uint8_t received for the frame length
// the frame length must be equal or greater than 5. (max length = 20 byte)
// the structure is:
// SOF, Length, Function, [Data], Cheksum H, Checksum L
// returns the status of the reception:
//											MUX_OK				everything is ok							
//											MUX_TIMEOUT			data line is staked
//											MUX_ERROR			error in protocol							
__far BYTE mux_get_frame(BYTE *_p_frame)
{
	BYTE data;
	BYTE ind;
	BYTE len;	BYTE actual;

	PORT_MUX_D_P = 0;					// input

	// sets frame length to the max allowed
	len = 20;
	// resets counter received bytes
	actual = 0;

	// gets the frame from the mux
	while(len--)
	{
		data = 0;

		// shifts in the bits (LSB first)
		for (ind = 0; ind < 8; ind++)
		{
			MUX_CK_P = 0;	

			// waits for MUX_T_WAIT/2 
			// resets timer
			TCCS_STOP = 1;
			TCDT = 0x0000;
			TCCS_STOP = 0;
			while(TCDT < MUX_T_WAIT_0);

			MUX_CK_P = 1;	

			// waits for MUX_T_WAIT 
			// resets timer
			TCCS_STOP = 1;
			TCDT = 0x0000;
			TCCS_STOP = 0;
			while(TCDT < (MUX_T_WAIT_1 / 2));

			data >>= 1;

			if (MUX_D_P & 0x01)
				data |= 0x80;		

			// waits for MUX_T_WAIT 
			// resets timer
			TCCS_STOP = 1;
			TCDT = 0x0000;
			TCCS_STOP = 0;
			while(TCDT < (MUX_T_WAIT_1 / 2));
		}

		// checks receiving frame for protocol compliance
		switch(actual)
		{
			// first byte: is it SOF?
			case 0:
				// if data line does not move: timeout
				if ((data == 0) || (data == 0xFF))
					return MUX_TIMEOUT;

				if (data != MUX_SOF)
					return MUX_ERROR;
				break;

			// second byte: length. Is it >= 5?
			case 1:
				if (data < 5)
					return MUX_ERROR;
				else
					len = data - 2;	

				break;

			// third byte: Function or NAK code
			case 2:
				if (data == MUX_STATUS_FUNCTION_NA)
					return MUX_WRONG_CMD;

			// fourth byte: Checks for returned error codes
			case 3:
				if ((data == MUX_STATUS_CHECKSUM) || (data == MUX_STATUS_FAILURE) || (data == MUX_STATUS_FUNCTION_NA))
					return MUX_WRONG_CMD;

				break;

			default:
				break;
		}

		// received byte
		*_p_frame++ = data;
		actual++;
	}

	// everything ok
	return MUX_OK;
}

// resets the mux lines 
__far void mux_lines_reset(void)
{
	WORD	dummy_w;
	BYTE	dummy_b;
	BYTE	ind;
	BYTE	mux_retry;

	#define MUX_MAX_RETRY	3

	// builds mux command frame
	mux_command_frame[0] = MUX_SOF;							//start of frame
	mux_command_frame[1] = 0x09;							// frame length
	mux_command_frame[2] = MUX_SET;							// function
	mux_command_frame[3] = 0x00;		
	mux_command_frame[4] = 0x00;
	mux_command_frame[5] = 0x00;
	mux_command_frame[6] = 0x00;

	// computes checksum
	dummy_w = 0;
	for (ind = 0; ind < 7; ind++)
		dummy_w += mux_command_frame[ind];

	mux_command_frame[7] = (BYTE)((dummy_w >> 8) & 0xFFL);
	mux_command_frame[8] = (BYTE)(dummy_w & 0xFF);

	mux_retry = 0;

	while(mux_retry++ < MUX_MAX_RETRY)
	{
		mux_send_frame(mux_command_frame);

		// gets response from mux
		dummy_b = mux_get_frame(mux_response_frame);

		// test response
		switch(dummy_b)
		{
			// communication OK
			case MUX_OK:
				mux_retry = MUX_MAX_RETRY;					// used to exit loop
				break;

			// no response
			case MUX_TIMEOUT:
				ResetOrol(&dummy_w);
				while(GetTime(&dummy_w) < MUX_T_INTERFRAME);
				break;

			// communication error
			case MUX_ERROR:
				ResetOrol(&dummy_w);
				while(GetTime(&dummy_w) < MUX_T_INTERFRAME);
				break;
		}
	}
}

// driver for the analog switches
// input:	_direction = line to redirect to bus
//			0 = OFF
__far void analog_switch_driver(uint8_t _direction)
{
	switch(_direction)
	{
		case AS_485:
			MUX_EN_485 = 1;
			MUX_EN_KL = 0;
			MUX_EN_CAN = 0;
			MUX_EN_J1850 = 0;
			break;

		case AS_KL:
		// for compatibility with HW6
		case AS_K_RENAULT:
		case AS_K_FIAT:
			MUX_EN_485 = 0;
			MUX_EN_KL = 1;
			MUX_EN_CAN = 0;
			MUX_EN_J1850 = 0;
			break;

		case AS_CAN:
			MUX_EN_485 = 0;
			MUX_EN_KL = 0;
			MUX_EN_CAN = 1;
			MUX_EN_J1850 = 0;
			break;

		case AS_J1850_VPW:
		case AS_J1850_PWM:
			MUX_EN_485 = 0;
			MUX_EN_KL = 0;
			MUX_EN_CAN = 0;
			MUX_EN_J1850 = 1;
			break;

		default:
			MUX_EN_485 = 0;
			MUX_EN_KL = 0;
			MUX_EN_CAN = 0;
			MUX_EN_J1850 = 0;
			break;
	}
}

// this must be called in order to switch the analog switches according to the mux status
__far void analog_switch_handler()
{
	// checks mux status
	if (mux_status == MUX_PC_STATUS_OK)
	{
		// sets the analog switches as requested
		switch(mux_int_cfg)
		{
			case AS_KL:
			case AS_CAN:
			case AS_J1850_PWM:
			case AS_J1850_VPW:
			case AS_485:
				analog_switch_driver(mux_int_cfg);
				break;

			// for compatibility with HW7
			case AS_K_RENAULT:
			case AS_K_FIAT:
				analog_switch_driver(AS_KL);
				break;

			case AS_AMICO:
			default:
				analog_switch_driver(AS_OFF);
				break;
		}
		
		// loads structure fields with new data
		program_serial_port.mux_used = 1;
		program_serial_port.mux_int_cfg = mux_int_cfg;
		program_serial_port.mux_ext_cfg = mux_ext_cfg;
	}
	else
	{
		analog_switch_driver(AS_OFF);

		// loads structure fields with new data
		program_serial_port.mux_used = 0;
		program_serial_port.mux_int_cfg = 0;
		program_serial_port.mux_ext_cfg = 0L;
	}
}

//-------------------------------------------------------------------
//-------------------------------------------------------------------
//		HW7 MUX PROCEDURES SECTION
//-------------------------------------------------------------------
//-------------------------------------------------------------------
// sets-up the HW7 
__far void hw7_mux_init(void)
{
	// disables the MUX and all the special lines from the CPU
	MUX_ENABLE		= HW7_MUX_OFF;

	DRV_K_SP_ECU	= HW7_MUX_OFF;
	DRV_K_L_AMICO	= HW7_MUX_OFF;

	// init related vars
	mux_ext_cfg = 0x0000L;
	mux_int_cfg = 0x00;
	mux_status = MUX_PC_STATUS_IDLE;

	// inverts bit logic to adapt them to the switches latches and writes the result in the latches locations
	HW7_WRITE_SWITCH_A((WORD)(mux_ext_cfg >> 16) ^ 0xFFFF);
	HW7_WRITE_SWITCH_B((WORD)(mux_ext_cfg & 0xFFFFL) ^ 0xFFFF);

	// enables the MUX
	MUX_ENABLE = HW7_MUX_ON;
}

// this must be called in order to switch the analog switches according to the mux status
__far void hw7_mux_handler(void)
{
	WORD	as_word_a;
	WORD	as_word_b;
	WORD	dummy_w;
	BYTE	ind;

	// disables the MUX and all the special lines from the CPU
	MUX_ENABLE		= HW7_MUX_OFF;
	DRV_K_SP_ECU	= HW7_MUX_OFF;
	DRV_K_L_AMICO	= HW7_MUX_OFF;

	// **************************
	// sets mux for internal BUS+/- to EOBD connector pins

	// prepares word for switches latch A (BUS+)
	as_word_a = 0x0000;
	for (ind = 0, dummy_w = 0x0001; ind < 16; ind++, dummy_w <<= 1)
	{
		if (dummy_w & (WORD)((mux_ext_cfg >> 16) & 0xFFFFL))
			as_word_a |= hw7_eobd_pin[ind];
	}

	// prepares word for switches latch B
	as_word_b = 0x0000;
	for (ind = 0, dummy_w = 0x0001; ind < 16; ind++, dummy_w <<= 1)
	{
		if (dummy_w & (WORD)(mux_ext_cfg & 0xFFFFL))
			as_word_b |= hw7_eobd_pin[ind];
	}
	// **************************


	// **************************
	// sets mux for internal lines to internal BUS+/-
	// prepares word for switches latch A (BUS+)
	switch(mux_int_cfg)
	{
		case HW7_PROT_KL:
			as_word_a |= hw7_protocols_a[HW7_SETUP_KL];
			as_word_b |= hw7_protocols_b[HW7_SETUP_KL];
			break;

		case HW7_PROT_CAN:
			as_word_a |= hw7_protocols_a[HW7_SETUP_CAN];
			as_word_b |= hw7_protocols_b[HW7_SETUP_CAN];
			break;

		case HW7_PROT_J1850_PWM:
			as_word_a |= hw7_protocols_a[HW7_SETUP_J1850_PWM];
			as_word_b |= hw7_protocols_b[HW7_SETUP_J1850_PWM];
			break;

		case HW7_PROT_J1850_VPW:
			as_word_a |= hw7_protocols_a[HW7_SETUP_J1850_VPW];
			as_word_b |= hw7_protocols_b[HW7_SETUP_J1850_VPW];
			break;

		case HW7_PROT_485:
			as_word_a |= hw7_protocols_a[HW7_SETUP_485];
			as_word_b |= hw7_protocols_b[HW7_SETUP_485];
			break;

		case HW7_PROT_AMICO:
			as_word_a |= hw7_protocols_a[HW7_SETUP_AMICO];
			as_word_b |= hw7_protocols_b[HW7_SETUP_AMICO];
			DRV_K_L_AMICO	= HW7_MUX_ON;
			break;

		case HW7_PROT_K_RENAULT:
			as_word_a |= hw7_protocols_a[HW7_SETUP_K_RENAULT];
			as_word_b |= hw7_protocols_b[HW7_SETUP_K_RENAULT];
			break;

		case HW7_PROT_K_FIAT:
			as_word_a |= hw7_protocols_a[HW7_SETUP_K_FIAT];
			as_word_b |= hw7_protocols_b[HW7_SETUP_K_FIAT];
			DRV_K_SP_ECU	= HW7_MUX_ON;
			break;

		// no (or more than one) protocol selected 
		case HW7_PROT_OFF:
		default:
			break;
	}
	// **************************

	// inverts bit logic to adapt them to the switches latches and writes the result in the latches locations
	HW7_WRITE_SWITCH_A(as_word_a ^ 0xFFFF);
	HW7_WRITE_SWITCH_B(as_word_b ^ 0xFFFF);

	// enables the MUX
	MUX_ENABLE = HW7_MUX_ON;

	// sets mux status
	mux_status = MUX_PC_STATUS_OK;

	// loads structure fields with new data
	program_serial_port.mux_used = 1;
	program_serial_port.mux_int_cfg = mux_int_cfg;
	program_serial_port.mux_ext_cfg = mux_ext_cfg;
}

// THIS FUNCTION IS USED ONLY BY THE SETTA_MUX FUNCTION
void __far build_mux_frame(int16_t _protocollo)
{
	int16_t dummy_w;
	int16_t ind;

	mux_command_frame[0] = MUX_SOF;							//start of frame
	mux_command_frame[1] = 0x09;							// frame length
	mux_command_frame[2] = MUX_SET;							// function

	switch (_protocollo)
	{
		case SM_K_L_K2000:
		case SM_K_L_9141:
			mux_command_frame[3] = 0x00;		
			mux_command_frame[4] = 0x40;
			mux_command_frame[5] = 0x20;
			mux_command_frame[6] = 0x00;
			mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_7 << 16) | ((DWORD)HW7_EXT_MUX_PIN_15);
			break;

		case SM_PWM_J1850:
		case SM_VPW_J1850:
			mux_command_frame[3] = 0x00;		
			mux_command_frame[4] = 0x02;
			mux_command_frame[5] = 0x02;
			mux_command_frame[6] = 0x00;
			//mux_ext_cfg = 0x00020200;
			mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_2 << 16) | ((DWORD)HW7_EXT_MUX_PIN_10);
			break;
		
		case SM_CAN:
			mux_command_frame[3] = 0x00;		
			mux_command_frame[4] = 0x20;
			mux_command_frame[5] = 0x40;
			mux_command_frame[6] = 0x00;
			//mux_ext_cfg = 0x00204000;
			mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_6 << 16) | ((DWORD)HW7_EXT_MUX_PIN_14);
			break;
		
		// this is not a standard and we decided to assign as a default the pins 3(485+) and 11(485-)
		case SM_485:
			mux_command_frame[3] = 0x00;		
			mux_command_frame[4] = 0x04;
			mux_command_frame[5] = 0x04;
			mux_command_frame[6] = 0x00;
			//mux_ext_cfg = 0x00040400;
			mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_3 << 16) | ((DWORD)HW7_EXT_MUX_PIN_11);
			break;
		
		// this is used only in debug setting the mux by the system
		case SM_K_RENAULT:
		case SM_K_FIAT:
			mux_command_frame[3] = 0x00;		
			mux_command_frame[4] = 0x40;
			mux_command_frame[5] = 0x20;
			mux_command_frame[6] = 0x00;
			mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_7 << 16) | ((DWORD)HW7_EXT_MUX_PIN_15);
			break;
		
		// this is used only in debug setting the mux by the system
		case SM_AMICO:
		case SM_NO_STANDARD:
		default:
			mux_command_frame[3] = 0x00;		
			mux_command_frame[4] = 0x00;
			mux_command_frame[5] = 0x00;
			mux_command_frame[6] = 0x00;
			mux_ext_cfg = 0x00000000;

			break;
	}
			
	// computes checksum
	dummy_w = 0;
	
	for (ind = 0; ind < 7; ind++)
		dummy_w += mux_command_frame[ind];

	mux_command_frame[7] = (BYTE)((dummy_w >> 8) & 0xFFL);
	mux_command_frame[8] = (BYTE)(dummy_w & 0xFF);

	mux_status = MUX_PC_STATUS_CONNECTING;
}

// THIS FUNCTION IS USED TO HANDLE THE MUX FROM INSIDE THE SYSTEMS
// _IT RETURNS ZERO WHEN THE MUX HAS BEEN SETUP
// _OTHERWAYS IT RETURNS A NON ZERO VALUE
__far int16_t Setta_mux(int16_t _protocollo,int16_t _reset)
{
#define SM_IDLE					0
#define SM_FREE_INT_MUX			10
#define SM_WRITE_EXT_MUX		20
#define	SM_READ_EXT_MUX			30
#define SM_SET_INT_MUX			40
#define	SM_MUX_SET_ERROR		50

#define MUX_MAX_RETRY	3

	static BYTE dummy_b;
	static WORD timer_mux;	
	static int16_t	fase;
	static BYTE mux_retry;	
	static uint8_t *p_char;			

	DWORD	rx_mux_ext_cfg;			
	WORD	dummy;
	int16_t		ind;

	if (_reset)
	{
		fase = SM_IDLE;
		dummy = 0;
		ind = 0;
		return 0;
	}

	// ********************
	// this is only for HW7
	// ********************
	if (bbad_hw_version == HW_V7)
	{
		if (_protocollo != SM_NO_STANDARD)
		{
			// sets the mux variables to setup the mux
			switch (_protocollo)
			{
				case SM_K_L_K2000:
				case SM_K_L_9141:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_7 << 16) | ((DWORD)HW7_EXT_MUX_PIN_15);
					mux_int_cfg = HW7_PROT_KL;
					break;

				case SM_PWM_J1850:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_2 << 16) | ((DWORD)HW7_EXT_MUX_PIN_10);
					mux_int_cfg = HW7_PROT_J1850_PWM;
					break;
				
				case SM_VPW_J1850:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_2 << 16) | ((DWORD)HW7_EXT_MUX_PIN_10);
					mux_int_cfg = HW7_PROT_J1850_VPW;
					break;
				
				case SM_CAN:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_6 << 16) | ((DWORD)HW7_EXT_MUX_PIN_14);
					mux_int_cfg = HW7_PROT_CAN;
					break;
				
				case SM_485:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_3 << 16) | ((DWORD)HW7_EXT_MUX_PIN_11);
					mux_int_cfg = HW7_PROT_485;
					break;
				
				case SM_AMICO:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_7 << 16) | ((DWORD)HW7_EXT_MUX_PIN_15);
					mux_int_cfg = HW7_PROT_AMICO;
					break;
				
				case SM_K_RENAULT:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_7 << 16) | ((DWORD)HW7_EXT_MUX_PIN_15);
					mux_int_cfg = HW7_PROT_K_RENAULT;
					break;
				
				case SM_K_FIAT:
					mux_ext_cfg = ((DWORD)HW7_EXT_MUX_PIN_7 << 16) | ((DWORD)HW7_EXT_MUX_PIN_15);
					mux_int_cfg = HW7_PROT_K_FIAT;
					break;
				
				default:
					// turns off all the switches
					mux_ext_cfg = 0x00L;
					mux_int_cfg = 0x00;
					break;
			}
		}

		hw7_mux_handler();

		// in HW7 it always returns OK because there is no way to check 
		// if the mux is present or if it is well configured
		return SM_ENDOK_HW7;
	}

	// ********************
	// this is only for HW6
	// ********************
	switch (fase)
	{
		case SM_IDLE:
			fase = SM_FREE_INT_MUX;
			break;

		case SM_FREE_INT_MUX:
			if (_protocollo == SM_NO_STANDARD)
			{
				fase = SM_READ_EXT_MUX;
				break;
			}	

			analog_switch_driver(AS_OFF);
			fase = SM_WRITE_EXT_MUX;
			mux_retry = 0;
			mux_status = MUX_PC_STATUS_CONNECTING;
			break;

		case SM_WRITE_EXT_MUX:
			// builds the frame to be sent to the mux
			build_mux_frame(_protocollo);

			// sends the frame to the mux
			mux_send_frame(mux_command_frame);
			
			// gets response from mux
			dummy_b = mux_get_frame(mux_response_frame);

			// test response
			switch(dummy_b)
			{
				// communication OK
				case MUX_OK:
					mux_status = MUX_PC_STATUS_CONNECTING;
					fase = SM_READ_EXT_MUX;
					break;

				// no response
				case MUX_TIMEOUT:
					if (++mux_retry >= MUX_MAX_RETRY)
					{
						mux_status = MUX_PC_STATUS_TIMEOUT;
						fase = SM_MUX_SET_ERROR;
					}
					else
					{
						ResetOrol(&timer_mux);
						fase++;
					}
					break;

				// communication error
				case MUX_ERROR:
					if (++mux_retry >= MUX_MAX_RETRY)
					{
						mux_status = MUX_PC_STATUS_ERROR;
						fase = SM_MUX_SET_ERROR;
					}
					else
					{
						ResetOrol(&timer_mux);
						fase++;
					}
					break;

				// command error
				case MUX_WRONG_CMD:
					if (++mux_retry >= MUX_MAX_RETRY)
					{
						mux_status = MUX_PC_STATUS_ERROR;
						fase = SM_MUX_SET_ERROR;
					}
					else
					{
						ResetOrol(&timer_mux);
						fase++;
					}
					break;
			} 
	
			break;

		// waits T Interframe
		case SM_WRITE_EXT_MUX + 1:
			if (GetTime(&timer_mux) < MUX_T_INTERFRAME)
				break;

			fase = SM_WRITE_EXT_MUX;
			break;
		
		case SM_READ_EXT_MUX:
			mux_command_frame[0] = MUX_SOF;							//start of frame
			mux_command_frame[1] = 0x05;							// frame length
			mux_command_frame[2] = MUX_READ;						// function

			// computes checksum
			dummy = 0;

			for (ind = 0; ind < 3; ind++)
				dummy += mux_command_frame[ind];

			mux_command_frame[3] = (BYTE)((dummy >> 8) & 0xFFL);
			mux_command_frame[4] = (BYTE)(dummy & 0xFF);

			mux_retry = 0;
			fase++;	
			break;
			
		// sends status command to mux
		case SM_READ_EXT_MUX + 1:
			mux_send_frame(mux_command_frame);

			// gets response from mux
			dummy_b = mux_get_frame(mux_response_frame);

			switch(dummy_b)
			{
				// frame received correctly
				case MUX_OK:
					fase = SM_READ_EXT_MUX + 3;
					break;

				// no response
				case MUX_TIMEOUT:
					if (++mux_retry >= MUX_MAX_RETRY)
					{
						mux_status = MUX_PC_STATUS_TIMEOUT;
						fase = SM_MUX_SET_ERROR;
					}
					else
					{
						ResetOrol(&timer_mux);
						fase++;
					}
					break;

				// communication error
				case MUX_ERROR:
					if (++mux_retry >= MUX_MAX_RETRY)
					{
						mux_status = MUX_PC_STATUS_ERROR;
						fase = SM_MUX_SET_ERROR;
					}
					else
					{
						ResetOrol(&timer_mux);
						fase++;
					}
					break;

				// command error
				case MUX_WRONG_CMD:
					if (++mux_retry >= MUX_MAX_RETRY)
					{
						mux_status = MUX_PC_STATUS_ERROR;
						fase = SM_MUX_SET_ERROR;
					}
					else
					{
						ResetOrol(&timer_mux);
						fase++;
					}
					break;
			}
			break;

		// waits T Interframe
		case SM_READ_EXT_MUX + 2:
			if (GetTime(&timer_mux) < MUX_T_INTERFRAME)
				break;

			fase = SM_READ_EXT_MUX + 1;
			break;
		
		case SM_READ_EXT_MUX + 3:
			dummy_b = mux_response_frame[7];

			switch(dummy_b)
			{
				// the mux has finished successfully the configuration
				case MUX_STATUS_OK:
					// received external mux settings
					p_char = (uint8_t *)&rx_mux_ext_cfg;
					*p_char++ = mux_response_frame[6];
					*p_char++ = mux_response_frame[5];
					*p_char++ = mux_response_frame[4];
					*p_char++ = mux_response_frame[3];
					
					if (rx_mux_ext_cfg == mux_ext_cfg)
						mux_status = MUX_PC_STATUS_OK;
					else
						mux_status = MUX_PC_STATUS_MISMATCH;
					
					if (_protocollo == SM_NO_STANDARD)
						mux_status = MUX_PC_STATUS_OK;

					break;

				// the mux has has not finished the configuration yet
				case MUX_STATUS_BUSY:
					mux_status = MUX_PC_STATUS_CONNECTING;
					break;

				// the mux did not receive any setup request
				case MUX_STATUS_IDLE:
					mux_status = MUX_PC_STATUS_IDLE;
					break;

				// the mux has returned a checksum error
				case MUX_STATUS_CHECKSUM:
					mux_status = MUX_PC_STATUS_ERROR;
					break;

				// the mux has an internal failure
				case MUX_STATUS_FAILURE:
					mux_status = MUX_PC_STATUS_ERROR;
					break;

				// the mux did not recognize the last command
				case MUX_STATUS_FUNCTION_NA:
					mux_status = MUX_PC_STATUS_ERROR;
					break;
			}

			if (mux_status == MUX_PC_STATUS_OK)
				fase = SM_SET_INT_MUX;
			else
				fase = SM_MUX_SET_ERROR;
			
			break;

		case SM_SET_INT_MUX:
			switch(_protocollo)
			{
				case SM_K_L_9141:
				case SM_K_L_K2000:
					analog_switch_driver(AS_KL);
					break;

				case SM_PWM_J1850:
					analog_switch_driver(AS_J1850_PWM);
					break;

				case SM_VPW_J1850:
					analog_switch_driver(AS_J1850_VPW);
					break;

				case SM_CAN:
					analog_switch_driver(AS_CAN);
					break;

				case SM_AMICO:
					analog_switch_driver(AS_AMICO);
					break;

				case SM_K_RENAULT:
					analog_switch_driver(AS_K_RENAULT);
					break;

				case SM_K_FIAT:
					analog_switch_driver(AS_K_FIAT);
					break;

				case SM_NO_STANDARD:
					break;
				
				default:
					analog_switch_driver(AS_OFF);
					break;
			}
			
			fase = SM_IDLE;
			return SM_ENDOK_HW6;
			break;

		case SM_MUX_SET_ERROR:
			fase = SM_IDLE;
			return SM_ENDKO_HW6;	
			break;

		default:
			fase = SM_IDLE;
			return SM_ENDKO_HW6;	
			break;
	}

	return SM_RUNNING;
}

#else

// definizioni necessarie alla virtualizzazione delle funzioni per i sistemi
__far int16_t Setta_mux(int16_t _protocollo,int16_t _reset)
{
	 return ((__far int16_t (*)())vect240)(_protocollo, _reset);
}
#endif


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set mux configuration at strtup if the
//                process works without the firmware.
//                microcontroller.
// F/P CALLING:   main (main.c)
// F/P CALLED:    hw7_mux_init (level.c)
//                setta_mux (level.c)
//                mux_init(level.c)
//                mux_lines_reset(level.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void usa_mux()
{
#ifdef EMULATOR_ON
	int16_t Result;
	
	Result = Setta_mux(SM_K_L_K2000, TRUE);
	program_serial_port.mux_used = 0;
	
	if (bbad_hw_version == HW_V7)
	{
		hw7_mux_init();
		
		while (1)
		{
			Result = Setta_mux(SM_K_L_K2000, FALSE);
			
			if (Result == SM_ENDOK_HW7)
			{
				program_serial_port.mux_used = 1;
				break;
			}
		}
	}			
	else
	{
		mux_init();
		mux_lines_reset();

		while(1)
		{
			Result = Setta_mux(SM_K_L_K2000, FALSE);
			
			if (Result == SM_ENDOK_HW6)
			{
				program_serial_port.mux_used = 1;
				break;
			}
			else if (Result != SM_RUNNING)
			{
				if (!program_serial_port.mux_used)			// It's necessary to use without MUX
					PDR8 = 0X00;
					
				break;
			}
		}
	}
	p_program_serial_port = &program_serial_port;

#else
	p_program_serial_port = (program_serial_com_struct *)vect254;
#endif

} // end usa_mux procedure

