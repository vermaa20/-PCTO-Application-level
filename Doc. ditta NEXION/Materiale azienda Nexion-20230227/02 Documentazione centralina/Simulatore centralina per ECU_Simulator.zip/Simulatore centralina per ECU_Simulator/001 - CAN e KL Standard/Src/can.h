#include "stdint.h"
/* can.h
*************************************************************************
**                                                              
**                      CAN CONTROLLER FUNCTIONS
**                                                              
**       
**	(C) Fujitsu Mikroelektronik GmbH 1997, H. Loesche           
*************************************************************************
*/


//#ifndef _CAN_H
//#define _CAN_H

#define CAN_C

#include "mb90540.h"
#include "typedefs.h"

// Stop CAN
//#define CSRHALT		0x0081

// Livello di priorit� dell'interrupt CAN = 3
//#define CAN_LEVEL	3


// Inizio Settaggi
//  #define BAUD_RATE_500k     0x2B01 // Valore per BTR0/BTR1 per ottenere velocit� di 500 kbit/s
//  #define BAUD_RATE_250k     0x2B03 // Valore per BTR0/BTR1 per ottenere velocit� di 250 kbit/s
  
  
  /***********************************************************************************
  #define BAUD_RATE_500k     0x2B81 // Valore per BTR0/BTR1 per ottenere velocit� di 500 kbit/s
  #define BAUD_RATE_250k     0x2B83 // Valore per BTR0/BTR1 per ottenere velocit� di 250 kbit/s
  #define BAUD_RATE_50k      0x2B93 // Valore per BTR0/BTR1 per ottenere velocit� di 50  kbit/s 
  /***********************************************************************************/ 	

  #define BAUD_RATE_200k      0x3a31 
  #define BAUD_RATE_250k      0x3a27
  #define BAUD_RATE_300k      0x3a20 
  #define BAUD_RATE_330k      0x3a1d 
  #define BAUD_RATE_333k      0x4dd5 
  #define BAUD_RATE_500k      0x3a13 
  #define BAUD_RATE_833k      0x3a0b 
  #define BAUD_RATE_950k      0x380b
  #define BAUD_RATE_1000k     0x3a09 
  #define BAUD_RATE_1250k     0x3a07 
  #define BAUD_RATE_2000k     0x3a04 
  #define BAUD_RATE_2500k     0x3a03 
  #define BAUD_RATE_3333k     0x3a02 
  #define BAUD_RATE_5000k     0x3a01 
  #define BAUD_RATE_10M       0x3a00 

  #define CAN_TYPE_ID_11     0x0000 // Valore effettivamente assegnato a IDER0_IDE1 in "Can.c" per CAN "standard" a 11 bit
  #define CAN_TYPE_ID_29     0xFFFF // Valore effettivamente assegnato a IDER0_IDE1 in "Can.c" per CAN "standard" a 29 bit


  #define ID_TESTER_29	0x889FD9C6L // ID = 18DB33F1 (29 bit)
  #define ID_TESTER_11	     0xE0FB // ID = 7DF (11 bit)


  #define ID_ECU_29 		0x0888D7C6L // ID = 18DAF101 (29 bit)
  #define ID_ECU_11	  	     0x00FD // ID = 7E8 (11 bit)
// Fine Settaggi


#define LENGHT_RX_CAN_BUFFER 	160		//lunghezza del buffer di ricezione


// Struttura frame arrivati
typedef struct{
// Originale:   WORD  ID[2]; 			// 2 byte
	BYTE  ID[4];				// 4 byte: In modo da contenere gli ID a 11 e a 29 bit
	BYTE  Type;					// 1 byte
	BYTE  Len;        			// 1 byte
	BYTE  Data[8];    			// 8 byte
	BOOL  Overrun;				// 1 Boolean
	BYTE  Frame_arrivati;		// 1 byte
}CANFrame;


#ifdef CAN_C
	uint8_t can_pack_tx[8];
	uint8_t can_pack_rx[8];
	uint8_t can_num;

	uint8_t rx_can_buffer[LENGHT_RX_CAN_BUFFER];	//buffer in cui salvo tutte le risposte consecutive 
												//per una stessa domanda, considero al massimo 20 consecutive
	BYTE count_rx_buffer;	//contatore per il buffer di ricezione
							//� usato nella RxCan0Local()
#else
	extern uint8_t can_pack_tx[8];
	extern uint8_t can_pack_rx[8];
	extern uint8_t can_num;
	extern uint8_t rx_can_buffer[LENGHT_RX_CAN_BUFFER];
#endif


extern __far void RxCan0(void); /* 11 CAN #0 (receive complete)    */
extern __far void TxCan0(void); /* 12 CAN #0 (Transmission complete)    */


// Prototipi delle funzioni
void CAN0_init(void);
void CAN0_buffer6(void);
void CAN0_buffer1(void);

void TxCan0Local (void);
void RxCan0Local (void);

void PutPackCan (uint8_t len);
BOOL TxEmptyCan(void);


// Inizio variabili per Settaggi
extern uint8_t Baud_Rate_Imp;   // "1" per 500kbit/s (default), "0" per 250kbit/s
extern uint16_t Baud_Rate;     // Valore effettivamente assegnato al registro "BTR0" per impostare il baud-Rate

extern uint8_t Can_Type_Id_Imp; // "1" per CAN standard a 11 bit (default), "0" per CAN esteso a 29 bit
extern uint16_t Can_Type_Id;   // Valore effettivamente assegnato a IDER0 per impostare il protocollo CAN


extern uint32_t Id_Tester;      // Valore effettivamente assegnato per controlli sull'ID del Tester (a 11 o a 29 bit)
extern uint32_t Id_Ecu;         // Valore effettivamente assegnato per controlli sull'ID dell'ECU (a 11 o a 29 bit)
// Fine variabili per Settaggi


//#endif
