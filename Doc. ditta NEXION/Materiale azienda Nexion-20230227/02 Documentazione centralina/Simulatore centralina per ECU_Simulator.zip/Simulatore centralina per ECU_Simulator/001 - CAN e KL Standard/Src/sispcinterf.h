#include "stdint.h"

//Stati comunicazione con centralina
#define INIT_WAIT			0x00
#define DATANOTREADY		0x01
#define END_ATT_OK		0x03
#define END_ATT_KO		0x04
#define DATA_OK			0x06
#define ATT_ABORT			0x80



// Definizione dei possibili errori in ricezione
#define AFFERMATIVE_RESPONSE			0x00		// Non si � verificato nessun errore
#define ERROR_DETECTION		 			0x01	 	// Errore di cksum
#define ERROR_DEST						0x04		// Errore nel destinatario
#define FUNCTION_NOT_SUPPORTED 		0x11  		// Funzione non riconosciuta
#define SERVICE_NOT_SUPPORTED			0x12  		// Servizio non riconosciuto
#define TYPE_SERVICE_NOT_SUPPORTED	0x13		// Tipo servizio non supportato
#define DATA_NOT_SUPPORTED				0x14		// Dato richiesto non riconosciuto
#define TYPE_NOT_SUPPORTED				0x13     	// Service Type not supported



//Flag di richieste comunicazioni visualizzatore
#define SISSTARTCOMM	0x01	// Inizio comunicazione
#define SISSTOPCOMM	0x80	// Stop comunicazione
#define SISSEXIT		0xFF	// Uscita dal sistema



// Definizione delle funzioni riconosciute
#define	DATI					0x22
#define	NOTIFICA				0x3F
#define 	NEGATIVE_RESPONSE	0x7F

// Definizione delle costanti
#define ABILITA				1		// Costanti usate per facilitare la lettura
#define DISABILITA			0


#define MAX_CENTRALINE			16	// Definisco il numero max di centraline disponibili sulla
									// macchina, deriva dall'eobd


// Definizione della struttura per i messaggi da visualizzare
typedef struct{
	uint32_t tipo_finestra;    // Contiene il tipo della finestra, cio� Stop, Clessidra...
	uint32_t tipo_messaggio;	// Contiene il tipo msg, cio� Attendi pressione tasto, ...
	uint32_t id1;				// Identificativi del tipo di msg da visualizzare
	uint32_t id2;
	uint32_t id3;
	uint32_t id4;
   }finestra;


#ifdef SYSPCINTERF_C
	uint8_t	errore_in_ricezione;		// Contiene eventuali errori in ricezione
	uint8_t stato_attivazione;			// Stato attivazione, restituito all' interfaccia
	uint8_t local_address;			// Indirizzo micro
	finestra pacchetto_finestra;   		// Contiene i messaggi da visualizzare durante l'attivazione
	uint8_t monitor_line;

	// Valori restituiti dalla attivazione
	uint8_t	att_umis;		// in tx
	float	att_value;		// in tx
	float	att_min;		// in tx
	float	att_max;		// in tx

	uint32_t valore_impostato;			// Valore inviato dal visualizzatore durante l'attivazione
	uint32_t attivazione_richiesta;	// Indice della attivazione

	uint32_t centraline_disponibili[MAX_CENTRALINE];	// Array che contengono informazioni nell' eobd
	uint8_t centralina;
	uint8_t normativa;
	uint8_t centralina_scelta;
	uint8_t protocollo_scelto;

	uint32_t SisStatus;			// Stato della comunicazione tra Black Box ed ECU

	DWORD SisStartCom;

#else
	// Variabili necessarie per restituire i valori di un' attivazione
	extern uint8_t    att_umis;		// in tx
	extern float	att_value;		// in tx
	extern float	att_min;		// in tx
	extern float	att_max;		// in tx


	extern uint32_t valore_impostato;			// Valore passato durante un attivazione dal visualizzatore
	extern uint32_t attivazione_richiesta;		// Indice dell' attivazione passata dal visualizzatore

	extern uint32_t centraline_disponibili[MAX_CENTRALINE];
	extern uint8_t centralina;
	extern uint8_t normativa;
	extern uint8_t centralina_scelta;
	extern uint8_t protocollo_scelto;

	extern uint32_t SisStatus;			// Stato della comunicazione tra Black Box ed ECU

	extern DWORD SisStartCom;

	extern uint8_t stato_attivazione;		// Stato attivazione, restituito all' interfaccia
	extern uint8_t monitor_line;
#endif


// Nuova gestione dell' interfaccia con il PC
__far void Rx_tecnomotor_frame(void);
__far void Unknown_frame_handler(void);
__far void Pc_command_decode(uint8_t _com,BOOL Reset);


//Prototipi funzioni
extern __far uint8_t MonitorManager(uint8_t ser_ut,BOOL Reset);
// Riempe la finestra per i messaggi
extern __far void RiempiFinestra(uint32_t tipo_fin, uint32_t tipo_mess, uint32_t id1, uint32_t id2, uint32_t id3, uint32_t id4);




