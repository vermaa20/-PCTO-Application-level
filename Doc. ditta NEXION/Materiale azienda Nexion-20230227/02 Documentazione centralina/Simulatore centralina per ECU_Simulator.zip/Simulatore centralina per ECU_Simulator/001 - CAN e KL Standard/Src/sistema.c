#include "stdint.h"
//------------------------------------------------------------------------------
// HEADING

// PROJECT NAME:     Sis_NNN.prj/Sis_RAM_NNN.prj
// PROJECT RELEASE:  3.1
//                   (CHANGE THE RELEASE SOFTWARE IN VARIABLE DECLARATIONS IN
//                   "sistema.c" EVERY PROGRAM CHANGING)
// FILE NAME:        sistema.c
// FILE RELEASE:     1.0
// DATE:             February 2004
// FILE DESCRIPTION: It contains the vectors initialization of status, parameter,
//                   ... using the index value of data-base.
//
// REVIEW  BY:       Ing. Andrea Acunzo - Ing. Diego Mainardi
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// FURTHER INFORMATIONS

//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// AVAILABLE PRCEDURE/FUNCTION

// extern __far void InitVariante(void)
// extern __far void InitIndexAtt (void)
// extern __far void InitInfo (void)
// extern __far void InitStati (void)
// extern __far void InitParam (void)
// extern __far void InitAtt(void)
// extern __far void InterpretaInfo (void)
// extern void DisabilitaSingoloSnap(int16_t)
// extern __far void InterpretaParametriStati (void)
// extern __far void Azzera_errori (uint8_t, uint8_t)
// extern uint8_t DisponiErrori(uint8_t)
// extern __far void InterpretaErrori(void)
// extern __far void CancErrori(void)
// extern __far void InterpretaAttivazione(void)
// extern __far uint8_t GestioneErroreTX(uint8_t,BOOL)
// extern __far uint8_t GestioneErroreRX(uint8_t,BOOL)
// extern __far uint8_t Attiva_Fast(BOOL)
// extern int16_t Send5Baud (uint8_t, BOOL)
// extern int16_t Wait_iso (uint8_t, BOOL)
// extern __far uint8_t AttivaEcu(BOOL)
// extern __far void Riattiva(void)
// extern uint8_t ComponiDomanda (int16_t,int16_t,uint8_t)
// extern uint16_t SequenzaDomande (BOOL)
// extern __far uint8_t Tx_Request(uint8_t,uint16_t, BOOL)
// extern uint8_t RispostaOk (uint8_t, uint8_t)
// extern __far uint8_t RxAnswer(uint8_t, BOOL)
// extern void InterpretaRisposta(void)
// extern __near uint8_t SystemManager(BOOL)


//------------------------------------------------------------------------------
// COMPILER DIRECTIVE

//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// INCLUDE HEADER LIST

#include "typedefs.h"
#include "serial.h"
#include "sistema.h"
#include "sispcinterf.h"
#include "hw.h"
#include "mux_low_level.h"

#ifndef ACCEMIC_ON
 #ifndef	EMULATOR_ON
	#include "ram_code.h"
 #endif
#endif



//------------------------------------------------------------------------------
// PRAGMA DECLARATION

#pragma  section DATA=EXTRAMDATA, attr=DATA
#pragma  section FAR_DATA=EXTRAMDATA, attr=DATA


//------------------------------------------------------------------------------
// VARIABLES DECLARATIONS

float release_sw = 3.1;	 // IMPORTANT: CHANGE THE RELEASE SOFTWARE EVERY PROGRAM CHANGING


// Parameter and status are managed by 1 bit called "PID" (Pricess Identifier). Theese PID
// are organized in byte structure and collected in a vector. The vector length is equal at
// the number of byte needed for PID description.
uint8_t param_abilitati[(TOTALEPARAMETRI / 8) + 1];	// List of Parameter enabled
uint8_t stati_abilitati[(TOTALESTATI / 8) + 1];		  // List of Status enabled
l_word abilita_pid[TOT_DOMANDE];
uint8_t domanda[TOT_DOMANDE];

uint8_t pid_richiesti[((TOT_DOMANDE) / 8) + 1];	// Request PID
uint8_t pid_abilitati[((TOT_DOMANDE) / 8) + 1];	// Enabled PID
uint16_t new_par;

// The following statements are defined as variable because they could
//  assume different values depending the presence of different variants.
uint32_t variante;
int16_t tot_parametri;
int16_t tot_stati;
int16_t tot_attivazioni;
int16_t tot_domande;
int16_t variante_ok;




//------------------------------------------------------------------------------

//Array con info centralina
uint8_t setInfo[TOTALEINFO][NUMINFOBYTE];

//Parametri
float setParametri[TOTALEPARAMETRI]; //32bit ok
//Stati
uint32_t setStati[TOTALESTATI];

//Errori 4 bytes per errore
uint8_t bufferErrori[TOTERRORI*4];
uint8_t bufErrAttivi[TOTERRORI*4];


int16_t fase_comunicazione;	// Phase of comunication
int16_t fase_attivazione;		// Phase of active-test
int16_t NumStorico;					// Number of stored historic

uint8_t buffer_Tx[LUNGH_BUFFER_TX];	// TX-Buffer for BBAD-Visualizator comunication

	// Vector of requests
uint8_t domanda_att[TOTALEATTIVAZIONI];

int16_t pid_attivo;			// Active PID
uint8_t len_tx;			// frame length

uint16_t BlinkTime;		// LED blinking time
uint16_t BTime;				// Time-out management variables
uint16_t lTout;
uint16_t ltime;				// Message time-out
uint16_t Wait_Time;   // Waiting time for a new request

uint8_t conta_att;		// Number of active error
uint8_t conta_mem;		// Number of stored error

//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set the number of parameter, status, ...
//                depending the presence of different variants.
// F/P CALLING:   main (main.c)
// F/P CALLED:    Pc_command_decode (SisPCIinterf.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InitVariante(void)
{

	if (!variante)
		{
		tot_parametri = TOTALEPARAMETRI;
		tot_stati = TOTALESTATI;
		tot_attivazioni = TOTALEATTIVAZIONI;
        tot_domande = TOT_DOMANDE;
		}
	else
		{
		tot_parametri = TOTALEPARAMETRI;
		tot_stati = TOTALESTATI;
		tot_attivazioni = TOTALEATTIVAZIONI;
        tot_domande = TOT_DOMANDE;
		}
}



//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set the index value (generated by
//                data-base) of Active Tests.
// F/P CALLING:   main (main.c)
// F/P CALLED:    MonitorManager (SisPCIinterf.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------

__far void InitIndexAtt ()
{
	elenc_attiv[ATT_CANCELLA_ERRORI							]	=	0;
	elenc_attiv[ATT_BLOCCAGGIO								]	=	707;
	elenc_attiv[ATT_SBLOCCAGGIO								]	=	708;
}

//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set the index value (generated by
//                data-base) of Informations.
// F/P CALLING:   main (main.c)
// F/P CALLED:    MonitorManager (SisPCIinterf.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InitInfo ()
{
elencInfo[I_FORNITORE						]=31;
elencInfo[I_VERSIONE_SOFTWARE				]=2;							
elencInfo[I_RIFERIMENTO_PSA					]=65;							
elencInfo[I_VERSIONE_CALIBRAZIONE			]=139;					
elencInfo[I_VERSIONE_DIAGNOSTICA			]=66;
elencInfo[I_NUMERO_PIANO_FUNZIONALE			]=151;
						
/*elencInfo[I_RIFERIMENTO_PSA_SATELLITI		]=140;					
elencInfo[I_FORNITORE_SATELLITI				]=141;						
elencInfo[I_VERSIONE_CALIBRATURA_SATELLITI	]=142;			
elencInfo[I_VERSIONE_PROGRAMMA_SATELLITI	]=143;				
elencInfo[I_VERSIONE_MATERIALI_SATELLITI	]=144;					
*/
}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set the index value (generated by
//                data-base) of Status and their values.
// F/P CALLING:   main (main.c)
// F/P CALLED:    MonitorManager (SisPCIinterf.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InitStati ()
{
// List of Status
	elencStati[0									] =	  0;	// IMPORTANT: YOU MUST PUT THIS STATEMENT ALWAYS
	elencStati[S_Stato_della_Scatola				] =1557;
	elencStati[S_Commutatore_Neutralizzazione		] =1492;		
	elencStati[S_Cinture_Pirotecniche_A				] =1488;				
	//Per 206 elencStati[S_Cinture_Pirotecniche_P			] =1489;				
	elencStati[S_Airbag_Laterali_Anteriori			] =1493;				
	//Per 206 elencStati[S_Tendine_Airbag_Laterali			] =1494;			
	elencStati[S_Copertura_Airbag_Laterali			] =1495;				
	elencStati[S_Airbag_Guida						] =1490;							
	elencStati[S_Airbag_Passeggero					] =1491;						
	elencStati[S_Satelliti							] =1496;							   
	elencStati[S_Controllo_Assistenza				] =1484;				   
	elencStati[S_Controllo_Officina					] =1485;                    							
	elencStati[S_Controllo_Fornitore				] =1486;				   
	

// List of Status Value
	
	possStati[NON_EFFETTUATO]=197;		
	possStati[ESEGUITO		]=371;			
	possStati[NO			]=22;					
	possStati[SI			]=21;					
	possStati[Sbloccato		]=251;			
	possStati[Bloccato		]=252;					
	possStati[OFF			]=1;
	possStati[No_Defin		]=200;
						


}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set the index value (generated by
//                data-base) of Parameters and their measurement units and
//                the precision (number of decimals).
// F/P CALLING:   main (main.c)
// F/P CALLED:    MonitorManager (SisPCIinterf.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InitParam ()
{
elencParam[0								]=0;		// Non usato
elencParam[P_Controllo_Intervento			]=1067;

umParam[P_Controllo_Intervento				]=0;

PrecParam[0									] = (uint32_t) 0;//	Non usato
PrecParam[P_Controllo_Intervento			]=0;

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set the byte value that discriminate the
//                active-test.
// F/P CALLING:   main (main.c)
// F/P CALLED:    InitPid (Pid.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InitAtt(void)
{
uint8_t *_ptrUchar;
uint8_t _i;

// Azzero l'array delle domande di attivazione
_ptrUchar = (uint8_t *)domanda_att;
for (_i = 0; _i < tot_attivazioni; _i++, _ptrUchar++)
  	*_ptrUchar = 0x00; 

domanda_att[ATT_CANCELLA_ERRORI		 ] = 0x83;
domanda_att[ATT_BLOCCAGGIO			 ] = 0xD1;
domanda_att[ATT_SBLOCCAGGIO			 ] = 0xE1;
}



//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to read, interpret and set the information
//                vector.
// F/P CALLING:   InterpretaRisposta (sistema.c)
// F/P CALLED:    ConvertiCar (SisPCIinterf.c)
//                GetBytefromBuffer (SisPCIinterf.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InterpretaInfo (void)
{

// Temporary variables
uint8_t j,k;
BYTE per_ind_evol = 0;
//int16_t RISULTATO;

	switch(fase_comunicazione)
		{

   	case RICHIEDI_INFO1:
 				 // Data 1
   				for (j=12,k=0; j<17; j++,k=k+2)
      				{
								setInfo[I_RIFERIMENTO_PSA][k] = ConvertiCar((GetBytefromBuffer(KLINE,j) >> 4));
								setInfo[I_RIFERIMENTO_PSA][k+1] = ConvertiCar((GetBytefromBuffer(KLINE,j) & 0x0f));
         			}
					setInfo[I_RIFERIMENTO_PSA][k] = '\0';

					for (j=5,k=0; j<10; j++,k=k+2)
      				{
								setInfo[I_NUMERO_PIANO_FUNZIONALE][k] = ConvertiCar((GetBytefromBuffer(KLINE,j) >> 4));
								setInfo[I_NUMERO_PIANO_FUNZIONALE][k+1] = ConvertiCar((GetBytefromBuffer(KLINE,j) & 0x0f));
         			}
					setInfo[I_NUMERO_PIANO_FUNZIONALE][k] = '\0';

					
 				 // Data 2
     		if (GetBytefromBuffer(KLINE,10))
       		setInfo[I_FORNITORE][0] = '\0';
         else
         	{
      		switch (GetBytefromBuffer(KLINE,11))
         		{

            		case 1:
            		  setInfo[I_FORNITORE][0] = 'P';
                  setInfo[I_FORNITORE][1] = '.';
                  setInfo[I_FORNITORE][2] = 'S';
                  setInfo[I_FORNITORE][3] = '.';
                  setInfo[I_FORNITORE][4] = 'A';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

								case 2:
            			setInfo[I_FORNITORE][0 ] = 'M';
                  setInfo[I_FORNITORE][1 ] = 'A';
                  setInfo[I_FORNITORE][2 ] = 'G';
                  setInfo[I_FORNITORE][3 ] = 'N';
                  setInfo[I_FORNITORE][4 ] = 'E';
                  setInfo[I_FORNITORE][5 ] = 'T';
                  setInfo[I_FORNITORE][6 ] = 'I';
            			setInfo[I_FORNITORE][7 ] = '_';
                  setInfo[I_FORNITORE][8 ] = 'M';
                  setInfo[I_FORNITORE][9 ] = 'A';
                  setInfo[I_FORNITORE][10] = 'R';
                  setInfo[I_FORNITORE][11] = 'E';
                  setInfo[I_FORNITORE][12] = 'L';
                  setInfo[I_FORNITORE][13] = 'L';
                  setInfo[I_FORNITORE][14] = 'I';
         				  setInfo[I_FORNITORE][15] = '\0';
                  break;

                case 3:
            			setInfo[I_FORNITORE][0] = 'B';
                  setInfo[I_FORNITORE][1] = 'O';
                  setInfo[I_FORNITORE][2] = 'S';
                  setInfo[I_FORNITORE][3] = 'C';
                  setInfo[I_FORNITORE][4] = 'H';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

                case 4:
            			setInfo[I_FORNITORE][0] = 'S';
                  setInfo[I_FORNITORE][1] = 'I';
                  setInfo[I_FORNITORE][2] = 'E';
                  setInfo[I_FORNITORE][3] = 'M';
                  setInfo[I_FORNITORE][4] = 'E';
                  setInfo[I_FORNITORE][5] = 'N';
                  setInfo[I_FORNITORE][6] = 'S';
         				  setInfo[I_FORNITORE][7] = '\0';
                  break;

                case 5:
            			setInfo[I_FORNITORE][0] = 'S';
                  setInfo[I_FORNITORE][1] = 'A';
                  setInfo[I_FORNITORE][2] = 'G';
                  setInfo[I_FORNITORE][3] = 'E';
                  setInfo[I_FORNITORE][4] = 'M';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

                case 6:
            			setInfo[I_FORNITORE][0] = 'V';
                  setInfo[I_FORNITORE][1] = 'A';
                  setInfo[I_FORNITORE][2] = 'L';
                  setInfo[I_FORNITORE][3] = 'E';
                  setInfo[I_FORNITORE][4] = 'O';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

            		case 7:
            			setInfo[I_FORNITORE][0] = 'Z';
                  setInfo[I_FORNITORE][1] = '.';
                  setInfo[I_FORNITORE][2] = 'F';
                  setInfo[I_FORNITORE][3] = '.';
         				  setInfo[I_FORNITORE][4] = '\0';
                  break;

                case 8:
            			setInfo[I_FORNITORE][0] = 'B';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'N';
                  setInfo[I_FORNITORE][3] = 'D';
                  setInfo[I_FORNITORE][4] = 'I';
                  setInfo[I_FORNITORE][5] = 'X';
         				  setInfo[I_FORNITORE][6] = '\0';
                  break;

                case 9:
            			setInfo[I_FORNITORE][0] = 'T';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'V';
                  setInfo[I_FORNITORE][3] = 'E';
                  setInfo[I_FORNITORE][4] = 'S';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

                case 10:
            			setInfo[I_FORNITORE][0] = 'L';
                  setInfo[I_FORNITORE][1] = 'U';
                  setInfo[I_FORNITORE][2] = 'C';
                  setInfo[I_FORNITORE][3] = 'A';
                  setInfo[I_FORNITORE][4] = 'S';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

                case 11:
            			setInfo[I_FORNITORE][0] = 'H';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'L';
                  setInfo[I_FORNITORE][3] = 'L';
                  setInfo[I_FORNITORE][4] = 'A';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

                case 12:
            			setInfo[I_FORNITORE][0] = 'B';
                  setInfo[I_FORNITORE][1] = 'I';
                  setInfo[I_FORNITORE][2] = 'T';
                  setInfo[I_FORNITORE][3] = 'R';
                  setInfo[I_FORNITORE][4] = 'O';
                  setInfo[I_FORNITORE][5] = 'N';
         				  setInfo[I_FORNITORE][6] = '\0';
                  break;

            		case 13:
            			setInfo[I_FORNITORE][0] = 'V';
                  setInfo[I_FORNITORE][1] = 'D';
                  setInfo[I_FORNITORE][2] = 'O';
         				  setInfo[I_FORNITORE][3] = '\0';
                  break;

                case 14:
            			setInfo[I_FORNITORE][0] = 'A';
                  setInfo[I_FORNITORE][1] = 'U';
                  setInfo[I_FORNITORE][2] = 'T';
                  setInfo[I_FORNITORE][3] = 'O';
                  setInfo[I_FORNITORE][4] = 'L';
                  setInfo[I_FORNITORE][5] = 'I';
                  setInfo[I_FORNITORE][6] = 'V';
         				  setInfo[I_FORNITORE][7] = '\0';
                  break;

            		case 15:
            			setInfo[I_FORNITORE][0] = 'T';
                  setInfo[I_FORNITORE][1] = 'R';
                  setInfo[I_FORNITORE][2] = 'W';
         				  setInfo[I_FORNITORE][3] = '\0';
                  break;

                case 16:
            			setInfo[I_FORNITORE][0] = 'T';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'M';
                  setInfo[I_FORNITORE][3] = 'I';
                  setInfo[I_FORNITORE][4] = 'C';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

                case 18:
            			setInfo[I_FORNITORE][0] = 'T';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'X';
                  setInfo[I_FORNITORE][3] = 'T';
                  setInfo[I_FORNITORE][4] = 'O';
                  setInfo[I_FORNITORE][5] = 'N';
         				  setInfo[I_FORNITORE][6] = '\0';
                  break;

                case 19:
            			setInfo[I_FORNITORE][0] = 'D';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'L';
                  setInfo[I_FORNITORE][3] = 'P';
                  setInfo[I_FORNITORE][4] = 'H';
                  setInfo[I_FORNITORE][5] = 'I';
         				  setInfo[I_FORNITORE][6] = '\0';
                  break;

                case 20:
            			setInfo[I_FORNITORE][0] = 'P';
                  setInfo[I_FORNITORE][1] = 'H';
                  setInfo[I_FORNITORE][2] = 'I';
                  setInfo[I_FORNITORE][3] = 'L';
                  setInfo[I_FORNITORE][4] = 'I';
                  setInfo[I_FORNITORE][5] = 'P';
                  setInfo[I_FORNITORE][6] = 'S';
         				  setInfo[I_FORNITORE][7] = '\0';
                  break;

                case 21:
            			setInfo[I_FORNITORE][0] = 'C';
                  setInfo[I_FORNITORE][1] = 'L';
                  setInfo[I_FORNITORE][2] = 'A';
                  setInfo[I_FORNITORE][3] = 'R';
                  setInfo[I_FORNITORE][4] = 'I';
                  setInfo[I_FORNITORE][5] = 'O';
                  setInfo[I_FORNITORE][6] = 'N';
         				  setInfo[I_FORNITORE][7] = '\0';
                  break;

                case 22:
            			setInfo[I_FORNITORE][0] = 'W';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'B';
                  setInfo[I_FORNITORE][3] = 'A';
                  setInfo[I_FORNITORE][4] = 'S';
                  setInfo[I_FORNITORE][5] = 'T';
                  setInfo[I_FORNITORE][6] = 'O';
         				  setInfo[I_FORNITORE][7] = '\0';
                  break;

                case 23:
            			setInfo[I_FORNITORE][0 ] = 'E';
                  setInfo[I_FORNITORE][1 ] = 'B';
                  setInfo[I_FORNITORE][2 ] = 'E';
                  setInfo[I_FORNITORE][3 ] = 'R';
                  setInfo[I_FORNITORE][4 ] = 'S';
                  setInfo[I_FORNITORE][5 ] = 'P';
                  setInfo[I_FORNITORE][6 ] = 'A';
            			setInfo[I_FORNITORE][7 ] = 'C';
                  setInfo[I_FORNITORE][8 ] = 'H';
                  setInfo[I_FORNITORE][9 ] = 'E';
                  setInfo[I_FORNITORE][10] = 'R';
         				  setInfo[I_FORNITORE][11] = '\0';
                  break;

            		case 24:
            			setInfo[I_FORNITORE][0] = 'I';
                  setInfo[I_FORNITORE][1] = 'T';
                  setInfo[I_FORNITORE][2] = 'T';
         				  setInfo[I_FORNITORE][3] = '\0';
                  break;

            		case 25:
            			setInfo[I_FORNITORE][0] = 'B';
                  setInfo[I_FORNITORE][1] = 'E';
                  setInfo[I_FORNITORE][2] = 'H';
                  setInfo[I_FORNITORE][3] = 'R';
         				  setInfo[I_FORNITORE][4] = '\0';
                  break;

                case 26:
            			setInfo[I_FORNITORE][0] = 'D';
                  setInfo[I_FORNITORE][1] = 'A';
                  setInfo[I_FORNITORE][2] = 'V';
                  setInfo[I_FORNITORE][3] = '/';
                  setInfo[I_FORNITORE][4] = 'B';
                  setInfo[I_FORNITORE][5] = 'R';
                  setInfo[I_FORNITORE][6] = 'C';
         				  setInfo[I_FORNITORE][7] = '\0';
                  break;

            		case 27:
            			setInfo[I_FORNITORE][0] = 'B';
                  setInfo[I_FORNITORE][1] = 'R';
                  setInfo[I_FORNITORE][2] = 'C';
         				  setInfo[I_FORNITORE][3] = '\0';
                  break;

            		case 28:
            			setInfo[I_FORNITORE][0] = 'H';
                  setInfo[I_FORNITORE][1] = 'P';
                  setInfo[I_FORNITORE][2] = 'I';
         				  setInfo[I_FORNITORE][3] = '\0';
                  break;

            		case 29:
                case 237:
            			setInfo[I_FORNITORE][0] = 'E';
                  setInfo[I_FORNITORE][1] = 'A';
                  setInfo[I_FORNITORE][2] = 'T';
                  setInfo[I_FORNITORE][3] = 'O';
                  setInfo[I_FORNITORE][4] = 'N';
         				  setInfo[I_FORNITORE][5] = '\0';
                  break;

            		case 30:
            			setInfo[I_FORNITORE][0] = 'S';
                  setInfo[I_FORNITORE][1] = 'C';
                  setInfo[I_FORNITORE][2] = '2';
                  setInfo[I_FORNITORE][3] = 'N';
         				  setInfo[I_FORNITORE][4] = '\0';
                  break;

                case 31:
            			setInfo[I_FORNITORE][0] = 'M';
                  setInfo[I_FORNITORE][1] = 'A';
                  setInfo[I_FORNITORE][2] = 'R';
                  setInfo[I_FORNITORE][3] = 'W';
                  setInfo[I_FORNITORE][4] = 'A';
                  setInfo[I_FORNITORE][5] = 'L';
         				  setInfo[I_FORNITORE][6] = '\0';
                  break;

                case 32:
            			setInfo[I_FORNITORE][0] = 'I';
                  setInfo[I_FORNITORE][1] = 'N';
                  setInfo[I_FORNITORE][2] = 'A';
                  setInfo[I_FORNITORE][3] = 'L';
                  setInfo[I_FORNITORE][4] = 'F';
                  setInfo[I_FORNITORE][5] = 'A';
         				  setInfo[I_FORNITORE][6] = '\0';
                  break;

                case 33:
            			setInfo[I_FORNITORE][0] = 'S';
                  setInfo[I_FORNITORE][1] = 'M';
                  setInfo[I_FORNITORE][2] = 'I';
                  setInfo[I_FORNITORE][3] = '_';
                  setInfo[I_FORNITORE][4] = 'K';
                  setInfo[I_FORNITORE][5] = 'O';
                  setInfo[I_FORNITORE][6] = 'Y';
                  setInfo[I_FORNITORE][7] = 'O';
         				  setInfo[I_FORNITORE][8] = '\0';
                  break;

                case 36:
            			setInfo[I_FORNITORE][0] = 'K';
                  setInfo[I_FORNITORE][1] = 'O';
                  setInfo[I_FORNITORE][2] = 'S';
                  setInfo[I_FORNITORE][3] = 'T';
                  setInfo[I_FORNITORE][4] = 'A';
                  setInfo[I_FORNITORE][5] = 'L';
         				  setInfo[I_FORNITORE][6] = '\0';
                  break;

                case 254:
            			setInfo[I_FORNITORE][0 ] = 'N';
                  setInfo[I_FORNITORE][1 ] = 'i';
                  setInfo[I_FORNITORE][2 ] = 'p';
                  setInfo[I_FORNITORE][3 ] = 'p';
                  setInfo[I_FORNITORE][4 ] = 'o';
                  setInfo[I_FORNITORE][5 ] = 'n';
                  setInfo[I_FORNITORE][6 ] = 'D';
            			setInfo[I_FORNITORE][7 ] = 'e';
                  setInfo[I_FORNITORE][8 ] = 'n';
                  setInfo[I_FORNITORE][9 ] = 's';
                  setInfo[I_FORNITORE][10] = 'o';
         				  setInfo[I_FORNITORE][11] = '\0';
                  break;

                  default:
         				    setInfo[I_FORNITORE][0] = '\0';
                  break;
            		}//switch
              }//else

 
 				 // Data 3
   				for (j=17,k=0; j<19; j++,k=k+2)
      				{
								setInfo[I_VERSIONE_SOFTWARE][k] = ConvertiCar((GetBytefromBuffer(KLINE,j) >> 4));
								setInfo[I_VERSIONE_SOFTWARE][k+1] = ConvertiCar((GetBytefromBuffer(KLINE,j) & 0x0f));
         			}
					setInfo[I_VERSIONE_SOFTWARE][k] = '\0';
					
					
				// Data 4
   				for (j=19,k=0; j<21; j++,k=k+2)
      				{
								setInfo[I_VERSIONE_CALIBRAZIONE][k] = ConvertiCar((GetBytefromBuffer(KLINE,j) >> 4));
								setInfo[I_VERSIONE_CALIBRAZIONE][k+1] = ConvertiCar((GetBytefromBuffer(KLINE,j) & 0x0f));
         			}
					setInfo[I_VERSIONE_SOFTWARE][k] = '\0';

	


 				 // Data 5
      				setInfo[I_VERSIONE_DIAGNOSTICA][0] = ConvertiCar((GetBytefromBuffer(KLINE,21) >> 4));
					setInfo[I_VERSIONE_DIAGNOSTICA][1] = ConvertiCar((GetBytefromBuffer(KLINE,21) & 0x0f));
					setInfo[I_VERSIONE_DIAGNOSTICA][2] = '\0';


      break;

////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
	/*case RICHIEDI_INFO2:
 				 // Data 1
   				for (j=5,k=0; j<10; j++,k=k+2)
      				{
								setInfo[I_RIFERIMENTO_PSA_SATELLITI][k] = ConvertiCar((GetBytefromBuffer(KLINE,j) >> 4));
								setInfo[I_RIFERIMENTO_PSA_SATELLITI][k+1] = ConvertiCar((GetBytefromBuffer(KLINE,j) & 0x0f));
         			}
					setInfo[I_RIFERIMENTO_PSA_SATELLITI][k] = '\0';


 				 // Data 2
     		if (GetBytefromBuffer(KLINE,10))
       		setInfo[I_FORNITORE_SATELLITI][0] = '\0';
         else
         	{
      		switch (GetBytefromBuffer(KLINE,11))
         		{

            		case 1:
            		  setInfo[I_FORNITORE][0] = 'P';
                  setInfo[I_FORNITORE_SATELLITI][1] = '.';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][3] = '.';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'A';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

								case 2:
            			setInfo[I_FORNITORE_SATELLITI][0 ] = 'M';
                  setInfo[I_FORNITORE_SATELLITI][1 ] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][2 ] = 'G';
                  setInfo[I_FORNITORE_SATELLITI][3 ] = 'N';
                  setInfo[I_FORNITORE_SATELLITI][4 ] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][5 ] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][6 ] = 'I';
            			setInfo[I_FORNITORE_SATELLITI][7 ] = '_';
                  setInfo[I_FORNITORE_SATELLITI][8 ] = 'M';
                  setInfo[I_FORNITORE_SATELLITI][9 ] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][10] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][11] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][12] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][13] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][14] = 'I';
         				  setInfo[I_FORNITORE][15] = '\0';
                  break;

                case 3:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'C';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'H';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

                case 4:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'M';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'N';
                  setInfo[I_FORNITORE_SATELLITI][6] = 'S';
         				  setInfo[I_FORNITORE_SATELLITI][7] = '\0';
                  break;

                case 5:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'G';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'M';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

                case 6:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'V';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'O';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

            		case 7:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'Z';
                  setInfo[I_FORNITORE_SATELLITI][1] = '.';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'F';
                  setInfo[I_FORNITORE_SATELLITI][3] = '.';
         				  setInfo[I_FORNITORE_SATELLITI][4] = '\0';
                  break;

                case 8:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'N';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'D';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'X';
         				  setInfo[I_FORNITORE_SATELLITI][6] = '\0';
                  break;

                case 9:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'V';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'S';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

                case 10:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'U';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'C';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'S';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

                case 11:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'H';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'A';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

                case 12:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'N';
         				  setInfo[I_FORNITORE_SATELLITI][6] = '\0';
                  break;

            		case 13:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'V';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'D';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'O';
         				  setInfo[I_FORNITORE_SATELLITI][3] = '\0';
                  break;

                case 14:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'U';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][6] = 'V';
         				  setInfo[I_FORNITORE_SATELLITI][7] = '\0';
                  break;

            		case 15:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'W';
         				  setInfo[I_FORNITORE_SATELLITI][3] = '\0';
                  break;

                case 16:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'M';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'C';
         				  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

                case 18:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'X';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'N';
         				  setInfo[I_FORNITORE_SATELLITI][6] = '\0';
                  break;

                case 19:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'D';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'P';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'H';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'I';
         				  setInfo[I_FORNITORE_SATELLITI][6] = '\0';
                  break;

                case 20:
            			setInfo[I_FORNITORE_SATELLITI][0] = 'P';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'H';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'P';
                  setInfo[I_FORNITORE_SATELLITI][6] = 'S';
         				  setInfo[I_FORNITORE_SATELLITI][7] = '\0';
                  break;

                case 21:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'C';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][6] = 'N';
         		  setInfo[I_FORNITORE_SATELLITI][7] = '\0';
                  break;

                case 22:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'W';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][6] = 'O';
         		  setInfo[I_FORNITORE_SATELLITI][7] = '\0';
                  break;

                case 23:
            	  setInfo[I_FORNITORE_SATELLITI][0 ] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][1 ] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][2 ] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][3 ] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][4 ] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][5 ] = 'P';
                  setInfo[I_FORNITORE_SATELLITI][6 ] = 'A';
            	  setInfo[I_FORNITORE_SATELLITI][7 ] = 'C';
                  setInfo[I_FORNITORE_SATELLITI][8 ] = 'H';
                  setInfo[I_FORNITORE_SATELLITI][9 ] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][10] = 'R';
         		  setInfo[I_FORNITORE_SATELLITI][11] = '\0';
                  break;

            		case 24:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'T';
         		  setInfo[I_FORNITORE_SATELLITI][3] = '\0';
                  break;

            		case 25:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'H';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'R';
         		  setInfo[I_FORNITORE_SATELLITI][4] = '\0';
                  break;

                case 26:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'D';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'V';
                  setInfo[I_FORNITORE_SATELLITI][3] = '/';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][6] = 'C';
         		  setInfo[I_FORNITORE_SATELLITI][7] = '\0';
                  break;

            		case 27:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'B';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'C';
         		  setInfo[I_FORNITORE_SATELLITI][3] = '\0';
                  break;

            		case 28:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'H';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'P';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'I';
         		  setInfo[I_FORNITORE_SATELLITI][3] = '\0';
                  break;

            		case 29:
                case 237:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'E';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'N';
         		  setInfo[I_FORNITORE_SATELLITI][5] = '\0';
                  break;

            		case 30:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'C';
                  setInfo[I_FORNITORE_SATELLITI][2] = '2';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'N';
         		  setInfo[I_FORNITORE_SATELLITI][4] = '\0';
                  break;

                case 31:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'M';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'R';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'W';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'L';
         		  setInfo[I_FORNITORE_SATELLITI][6] = '\0';
                  break;

                case 32:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'N';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'L';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'F';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'A';
         		  setInfo[I_FORNITORE_SATELLITI][6] = '\0';
                  break;

                case 33:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'M';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'I';
                  setInfo[I_FORNITORE_SATELLITI][3] = '_';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'K';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][6] = 'Y';
                  setInfo[I_FORNITORE_SATELLITI][7] = 'O';
         		  setInfo[I_FORNITORE_SATELLITI][8] = '\0';
                  break;

                case 36:
            	  setInfo[I_FORNITORE_SATELLITI][0] = 'K';
                  setInfo[I_FORNITORE_SATELLITI][1] = 'O';
                  setInfo[I_FORNITORE_SATELLITI][2] = 'S';
                  setInfo[I_FORNITORE_SATELLITI][3] = 'T';
                  setInfo[I_FORNITORE_SATELLITI][4] = 'A';
                  setInfo[I_FORNITORE_SATELLITI][5] = 'L';
         		  setInfo[I_FORNITORE_SATELLITI][6] = '\0';
                  break;

                case 254:
            	  setInfo[I_FORNITORE_SATELLITI][0 ] = 'N';
                  setInfo[I_FORNITORE_SATELLITI][1 ] = 'i';
                  setInfo[I_FORNITORE_SATELLITI][2 ] = 'p';
                  setInfo[I_FORNITORE_SATELLITI][3 ] = 'p';
                  setInfo[I_FORNITORE_SATELLITI][4 ] = 'o';
                  setInfo[I_FORNITORE_SATELLITI][5 ] = 'n';
                  setInfo[I_FORNITORE_SATELLITI][6 ] = 'D';
            	  setInfo[I_FORNITORE_SATELLITI][7 ] = 'e';
                  setInfo[I_FORNITORE_SATELLITI][8 ] = 'n';
                  setInfo[I_FORNITORE_SATELLITI][9 ] = 's';
                  setInfo[I_FORNITORE_SATELLITI][10] = 'o';
         		  setInfo[I_FORNITORE_SATELLITI][11] = '\0';
                  break;

                  default:
         				    setInfo[I_FORNITORE_SATELLITI][0] = '\0';
                  break;
            		}//switch
              }//else

 
 				 // Data 3
 				 
 				 	RISULTATO =(((int16_t)(unsigned)GetBytefromBuffer(KLINE,17)*256) + (int16_t)(unsigned)GetBytefromBuffer(KLINE,18));
   					setInfo[I_VERSIONE_CALIBRATURA_SATELLITI][0] = ConvertiCar(RISULTATO/10000);
					setInfo[I_VERSIONE_CALIBRATURA_SATELLITI][1] = ConvertiCar((RISULTATO/1000)%10);
					setInfo[I_VERSIONE_CALIBRATURA_SATELLITI][2] = ConvertiCar((RISULTATO/100)%10);
					setInfo[I_VERSIONE_CALIBRATURA_SATELLITI][3] = ConvertiCar((RISULTATO/10)%10);
					setInfo[I_VERSIONE_CALIBRATURA_SATELLITI][4] = ConvertiCar(RISULTATO%10);
			    	setInfo[I_VERSIONE_CALIBRATURA_SATELLITI][5] = '\0';
					
				// Data 4
   			
					setInfo[I_VERSIONE_PROGRAMMA_SATELLITI][0] = ConvertiCar((GetBytefromBuffer(KLINE,21) >> 4));
					setInfo[I_VERSIONE_PROGRAMMA_SATELLITI][1] = ConvertiCar((GetBytefromBuffer(KLINE,21) & 0x0f));
         			setInfo[I_VERSIONE_SOFTWARE][k] = '\0';

	


 				 // Data 5
      				setInfo[I_VERSIONE_MATERIALI_SATELLITI][0] = ConvertiCar((GetBytefromBuffer(KLINE,23) >> 4));
					setInfo[I_VERSIONE_MATERIALI_SATELLITI][1] = ConvertiCar((GetBytefromBuffer(KLINE,23) & 0x0f));
					setInfo[I_VERSIONE_MATERIALI_SATELLITI][2] = '\0';


      break;
*/

  
      default:
      break;
      }//switch(fase_comunicazione)


}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to disable all parameter and status contained
//                in a particular snap (PID).
// F/P CALLING:   GestioneErroreTX (sistema.c)
// F/P CALLING:   GestioneErroreRX (sistema.c)
// F/P CALLED:    DisabilitaSingoloParametro (SisPCIinterf.c)
// PARAMETER IN:  pid_attivo (the pid that must be disabled)
// PARAMETER OUT:
//------------------------------------------------------------------------------
void DisabilitaSingoloSnap(int16_t pid_attivo)
{

   switch (pid_attivo)
   	{
      				case 1: // "Snap_1" 0x81 
						DisabilitaSingoloStato(S_Controllo_Assistenza);		
						DisabilitaSingoloStato(S_Controllo_Officina);		
						DisabilitaSingoloStato(S_Controllo_Fornitore);	
						DisabilitaSingoloParametro(P_Controllo_Intervento);		
					break;
		
					case 2: // "Snap_2" 0xD0
						DisabilitaSingoloStato(S_Commutatore_Neutralizzazione);
						DisabilitaSingoloStato(S_Cinture_Pirotecniche_A);
						//DisabilitaSingoloStato(S_Cinture_Pirotecniche_P);
						DisabilitaSingoloStato(S_Airbag_Laterali_Anteriori);
						//DisabilitaSingoloStato(S_Tendine_Airbag_Laterali);
						DisabilitaSingoloStato(S_Copertura_Airbag_Laterali);
						DisabilitaSingoloStato(S_Airbag_Guida);
						DisabilitaSingoloStato(S_Airbag_Passeggero);
						DisabilitaSingoloStato(S_Satelliti);
					break;

					case 3: // "Snap_3" 0xC1
					 	DisabilitaSingoloStato(S_Stato_della_Scatola);
					break;
	
      		}

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to read, interpret and set the parameter
//                vector.
// F/P CALLING:   InterpretaRisposta (sistema.c)
// F/P CALLED:    GetBytefromBuffer (SisPCIinterf.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InterpretaParametriStati (void)
{
	if (GetBytefromBuffer(KLINE,3) == 0x7F)
   		DisabilitaSingoloSnap(pid_attivo);
	else
	{
	switch(pid_attivo)
	   	{
	   	
      				case 1: // "Snap" 0x81
    				
      					setStati[S_Controllo_Assistenza] = (uint32_t)((GetBytefromBuffer(KLINE,9)  & 0x04) ? ESEGUITO : NON_EFFETTUATO);
						setStati[S_Controllo_Officina]	 = (uint32_t)((GetBytefromBuffer(KLINE,9)  & 0x02) ? ESEGUITO : NON_EFFETTUATO);
						setStati[S_Controllo_Fornitore]  = (uint32_t)((GetBytefromBuffer(KLINE,9)  & 0x01) ? ESEGUITO : NON_EFFETTUATO);
						setParametri[P_Controllo_Intervento] = (float)((unsigned)GetBytefromBuffer(KLINE,10)) ;
					break;
		
					case 2: // "Snap" 0xD0
					

						setStati[S_Commutatore_Neutralizzazione]= (uint32_t)((GetBytefromBuffer(KLINE,8)  & 0x01) ? SI : NO);
						setStati[S_Cinture_Pirotecniche_A]=(uint32_t)((GetBytefromBuffer(KLINE,5)  & 0x02) ? SI : NO);
						//setStati[S_Cinture_Pirotecniche_P]= (uint32_t)((GetBytefromBuffer(KLINE,5)  & 0x08) ? SI : NO);
						setStati[S_Airbag_Laterali_Anteriori]= (uint32_t)((GetBytefromBuffer(KLINE,7)  & 0x01) ? SI : NO);
						//setStati[S_Tendine_Airbag_Laterali]= (uint32_t)((GetBytefromBuffer(KLINE,7)  & 0x10) ? SI : NO);
						setStati[S_Copertura_Airbag_Laterali]= (uint32_t)((GetBytefromBuffer(KLINE,7)  & 0x10) ? SI : NO);
						setStati[S_Airbag_Guida]=(uint32_t)((GetBytefromBuffer(KLINE,6)  & 0x01) ? SI : NO);
						setStati[S_Airbag_Passeggero]= (uint32_t)((GetBytefromBuffer(KLINE,6)  & 0x04) ? SI : NO);
						setStati[S_Satelliti]= (uint32_t)((GetBytefromBuffer(KLINE,9)  & 0x40) ? SI : NO);

					break;
					
					
					

					case 3: // "Snap" 0x83
					 	 
							switch (GetBytefromBuffer(KLINE,8))
							{
							
								case 0x06:
								setStati[S_Stato_della_Scatola] = (uint32_t)(Sbloccato);
								break;

								case 0x19:
								setStati[S_Stato_della_Scatola] = (uint32_t)(Bloccato);
								break;
							
								
								default:
								setStati[S_Stato_della_Scatola] = (uint32_t)(No_Defin);
								break;
							} 
						
					
					break;
			
	
      				
		}	// end switch()

	}//End IF
}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function cleans the error vector starting from a
//                particolar position.
// F/P CALLING:   InterpretaErrori (sistema.c)
//                CancError (sistema.c)
// F/P CALLED:
// PARAMETER IN:  _conta_mem (starting of cleaning position for stored errors)
// PARAMETER OUT: _conta_att (starting of cleaning position for active errors)
//------------------------------------------------------------------------------
__far void Azzera_errori (void)
{
int16_t i;

	for (i=conta_mem; i<TOTERRORI*4; i++)
		bufferErrori[i] = 0x00;
	for (i=conta_att; i<TOTERRORI*4; i++)
		bufErrAttivi[i] = 0x00;
			

//Compare *4 perch� su Amico gli errori vengono codificati su 4 byte, quindi lo spazio sui buffer 
//� maggiore.
 		
}
//------------------------------------------------------------------------------
// DESCRIPTION:   This function builds the Tester's error code.
// F/P CALLING:   InterpretaErrori (sistema.c)
// F/P CALLED:    GetBytefromBuffer (SisPCInterface.c)
// PARAMETER IN:  _NumErr (number of errors)
// PARAMETER OUT: 0/-1
//-----------------------------------------------------------------------------uint8_t DisponiErrori(void)
uint8_t DisponiErrori(void)
{
uint8_t _loop = 0;
uint8_t num_err = 0;
uint8_t pari_dispari = 0;

	// Azzero  il puntatore al buffer degli errori
	conta_att = 0;
	conta_mem = 0;
	
	//Leggo il primo byte della stringa errori e gli sottraggo c2 (che rappresenta l'assenda   
	//d'errori), ottengo quindi il numero totale dei byte su cui sono distribuiti gli errori
	//Lo divido per due perch� due byte portano un errore!!
	
	num_err =  (GetBytefromBuffer(KLINE,4));
	   
	   
	for (_loop=0; _loop < num_err; _loop++)         // composizione array degli errori
		{
	   	    if((GetBytefromBuffer(KLINE,5 + _loop*3)& 0xF0
	   	    ) == 0x10)	
	   	    //Facendo l'AND con 0x10 controllo se � un guasto permanente, 
	   	    //se non lo � significa che � fuggitivo.
		     {
      			// Evito l'overfow del buffer degli errori
      		   	if(conta_mem >= (TOTERRORI * 4 ))
			  	return (-1);

				if(conta_att >= (TOTERRORI * 4 ))
				return (-1);
         		
         		//metto dentro il secondo byte per intero
         		bufErrAttivi[conta_att++] = GetBytefromBuffer(KLINE,6 + _loop * 3);
		 		//metto dentro solo il secondo nibble del primo byte, facendo un'AND con 0f.
		 		bufErrAttivi[conta_att++] = (GetBytefromBuffer(KLINE,5 + _loop * 3) & 0x0F);
         		bufErrAttivi[conta_att++] = 0x14;
         		bufErrAttivi[conta_att++] = 0x01;
         		        				
        	}//Chiudo l'IF -Da qui discrimino i memorizzati
        	
        	
        	 else if (GetBytefromBuffer(KLINE,5 + _loop*3) !=0x01) 
        	//else degli errori memorizzati
      		{
     		 
     		 	// Evito l'overfow del buffer degli errori
   		    	if(conta_mem >= (TOTERRORI * 4 ))
         		return (-1);
   	         			
   	         		
 				//metto dentro il secondo byte per intero
         		bufferErrori[conta_mem++] = GetBytefromBuffer(KLINE,6 + _loop * 3);
		 		//metto dentro solo il secondo nibble del primo byte, facendo un'AND con 0f.
		 		bufferErrori[conta_mem++] = (GetBytefromBuffer(KLINE,5 + _loop * 3) & 0x0F);
         		bufferErrori[conta_mem++] = 0x14;
         		bufferErrori[conta_mem++] = 0x01;
         		       		
			}//CHIUDO L'ELSE DEI MEMORIZZATI
           
      	 
	}//END DEL FOR
return (0);
}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function builds the Tester's error code.
// F/P CALLING:   InterpretaRisposta (sistema.c)
// F/P CALLED:    GetBytefromBuffer (SisPCInterface.c)
//                DisponiErrori (sistema.c)
//                Azzera_errori (sistema.c)
// PARAMETER IN:
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void InterpretaErrori(void) 
{
// Controlla che nel buffer stia arrivando la stringa che contiene gli errori, la stringa 
// comincia con  33

if (GetBytefromBuffer(KLINE, 3) == 0x57)  //controllo solo in 33
		
		{
		// Azzero  il puntatore al buffer degli errori
		conta_att = 0;
		conta_mem = 0;
	
		 
		// Cerco gli errori
   		DisponiErrori(); 
   		
		// Azzero i buffer degli errori
		Azzera_errori();
		}
}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function manages the error deleting phases.
// F/P CALLING:   InterpretaRisposta (sistema.c)
// F/P CALLED:    GetBytefromBuffer (SisPCInterface.c)
//                RiempiFinestra (SisPCInterface.c)
//                Azzera_errori (sistema.c)
// PARAMETER IN:
// PARAMETER OUT:
//------------------------------------------------------------------------------

__far void CancErrori(void)
{


	if(stato_attivazione != ATT_ABORT)		// Controllo che ci sia ancora una cancellazione errori in corso
		{
		        stato_attivazione = DATANOTREADY;
            	if (GetBytefromBuffer(KLINE,3) == 0x7F)
           			{
 						fase_comunicazione = START_CANC_ERRORI;
 						Azzera_errori();             // Azzero i buffer degli errori
                		RiempiFinestra(1,6,4,5,0,0);	// Msg: att. in corso, att. prego
               		}
               	else if ((GetBytefromBuffer(KLINE,3) == 0x54))
                	{              	
            			stato_attivazione = END_ATT_OK; 
         				RiempiFinestra(1,2,0,0,0,0);
						attivazione_richiesta = 0;
    	       			//fase_comunicazione = NORMALE;
    	       		}
    	}
   		else
   		{
      		pid_attivo=0;
      		fase_comunicazione = NORMALE;
      	}
}








//------------------------------------------------------------------------------
// DESCRIPTION:   This function manages the active-tests phases.
// F/P CALLING:   InterpretaRisposta (sistema.c)
// F/P CALLED:    GetBytefromBuffer (SisPCInterface.c)
//                RiempiFinestra (SisPCInterface.c)
// PARAMETER IN:
// PARAMETER OUT:
//------------------------------------------------------------------------------
// Funzione per la gestione delle attivazioni
__far void InterpretaAttivazione(void)
{

#define MAX_CICLI_ATT_1    1
#define MAX_CICLI_ATT_2    1

static uint16_t _Cicli_Att;
static uint16_t _Max_Cicli_Att;

switch(fase_comunicazione)
{
	case START_ATTIVAZIONE:	// Start attivazione
      	 stato_attivazione=DATANOTREADY;
         _Cicli_Att=0;
         _Max_Cicli_Att=0; 
		 switch(attivazione_richiesta - 1)
         	{
	           	case ATT_BLOCCAGGIO:                
				case ATT_SBLOCCAGGIO:            
				_Max_Cicli_Att = MAX_CICLI_ATT_2;
            break;
            default:
            	_Max_Cicli_Att = MAX_CICLI_ATT_1;
            break;
            }
            
         fase_attivazione = INIZIO;
         fase_comunicazione = RUN_ATTIVAZIONE;
      break;

      case RUN_ATTIVAZIONE:	// Attivazione in corso
       	if (GetBytefromBuffer(KLINE,3) == 0x7B)
         	{
            stato_attivazione = END_ATT_OK;
            fase_comunicazione = NORMALE;
            attivazione_richiesta=0;
            pid_attivo=0;
            }
         else
         
         if (stato_attivazione == ATT_ABORT || _Cicli_Att >= _Max_Cicli_Att)
                fase_comunicazione = END_ATTIVAZIONE;
         else
            	{
               fase_comunicazione = RUN_ATTIVAZIONE;
               _Cicli_Att ++;
               }
         	fase_attivazione = IN_CORSO;
      break;

      case END_ATTIVAZIONE:	// Fine attivazione
      	fase_attivazione = FINE;
        fase_comunicazione = RUN_ATTIVAZIONE;
      break;

      default:
      break;
      }

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function manages the trasmission error.
// F/P CALLING:   SystemManager (sistema.c)
// F/P CALLED:    DisabilitaSingoloSnap (sistema.c)
//                RiempiFinestra (SisPCInterface.c)
// PARAMETER IN:  errore (error status)
//                Reset (boolean value to reset management)
// PARAMETER OUT: Phase of comunication
//------------------------------------------------------------------------------
__far uint8_t GestioneErroreTX(uint8_t errore,BOOL reset)
	{

	#define NUM_TX_SUC			3
	#define NUM_TX_BAD			3
	#define NUM_TENTATIVI_ABIL	3


	static uint8_t num_tentativi_attivazione;
	static uint8_t tx_bad;
	static uint8_t tx_suc;


	if (reset)
		{
		tx_bad = 0;
		tx_suc = 0;
		num_tentativi_attivazione = 0;
		} // end if to reset counters

	if ((errore == TOUT) ||	(errore == REQ_NOT_SUPPORTED) || (errore == WRONGSTEP))
		{

      if (fase_comunicazione == RICHIESTA_FAST || fase_comunicazione == FINE_COMUNICAZIONE_1)
         {
			SisStatus = DATANOTREADY;
			num_tentativi_attivazione++;
         if(num_tentativi_attivazione > NUM_TENTATIVI_ABIL)
            return NESSUNA_CENTRALINA;
			else
            return RIPROVA_ATTIVAZIONE;
         }

      if(attivazione_richiesta)
			{
			RiempiFinestra(1,6,4,42,3,0); // Message: see "Messag.txt" in Tester's compact flash
			fase_comunicazione = PARAMETRI_STATI;
			attivazione_richiesta = 0;
			pid_attivo = 0;
         return NUOVA_DOMANDA;
			} // end if answer error

		tx_bad++;
		
		//If the attempts exceed the available N� of RX the activation is started again  

      if (tx_suc >= NUM_TX_SUC)		
			{
			BlinkTime = 250;
			pid_attivo = 0;
			// Setting to 0 the tx_rx attempt counter
			tx_bad = 0;	
			// Setting to 0 the following attempt tx_rx counter		
			tx_suc = 0;	
			// Setting to 0 the tx_rx Reactivation attempt counter
			num_tentativi_attivazione = 0;			
         return RIPROVA_ATTIVAZIONE;
			}
		// If the attempt limit is not reach
		else  
			{
			DEBUG_LED = ~DEBUG_LED;
			// If the attempt limit is exceeded 
				if (tx_bad >= NUM_TX_BAD)				{
				tx_suc++;
				switch (fase_comunicazione)
					{
               case PARAMETRI_STATI:
               	// pid_attivo = 0 is the Normal Question
               	if(pid_attivo >= 1)		
               	    {
               		pid_abilitati[pid_attivo / 8] &=  ~(1 << (pid_attivo % 8));	// Reset
                     DisabilitaSingoloSnap(pid_attivo);
                     }
               	pid_attivo++;
               break;



					case START_ATTIVAZIONE:
						// Msg: Activation not available
						RiempiFinestra(1,6,4,42,3,0);
						fase_comunicazione = PARAMETRI_STATI;
						attivazione_richiesta = 0;
						pid_attivo=0;
						break;

					default:
						fase_comunicazione = PARAMETRI_STATI;
						attivazione_richiesta = 0;
						stato_attivazione = ATT_ABORT;
						pid_attivo = 0;
               break;
					}
				return NUOVA_DOMANDA;
				}	
			}  
		}	
	return ERRORE_SCONOSCIUTO;
	}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function manages the reception error.
// F/P CALLING:   SystemManager (sistema.c)
// F/P CALLED:    DisabilitaSingoloSnap (sistema.c)
//                RiempiFinestra (SisPCInterface.c)
// PARAMETER IN:  errore (error status)
//                Reset (boolean value to reset management)
// PARAMETER OUT: Phase of comunication
//------------------------------------------------------------------------------
__far uint8_t GestioneErroreRX(uint8_t errore,BOOL reset)
	{

	#define NUM_RX_SUC			3
	#define NUM_RX_BAD			3
	#define NUM_TENTATIVI_ABIL	3


	static uint8_t num_tentativi_attivazione;
	static uint8_t rx_bad;
	static uint8_t rx_suc;


	if (reset)
		{
		rx_bad = 0;
		rx_suc = 0;
		num_tentativi_attivazione = 0;
		} // end if to reset counters
	//IF the System is in Time Out or the question is not supported
	if ((errore == TOUT) ||	(errore == REQ_NOT_SUPPORTED) || (errore == WRONGSTEP))	
		{												

      if (fase_comunicazione == RICHIESTA_FAST || fase_comunicazione == FINE_COMUNICAZIONE_1)
         {
         	//Activation status on the Visualizator
			SisStatus = DATANOTREADY;
			//Number of Re-Activation increasing 							
			num_tentativi_attivazione++;
			//If the maximum number of Re-Activation is exceed					
         if(num_tentativi_attivazione > NUM_TENTATIVI_ABIL)	
         	//Back to the error condition
            return NESSUNA_CENTRALINA;						
			else
            return RIPROVA_ATTIVAZIONE;
         }

		
		 //If there are some errors in the answer the Activation is resetted
      if(attivazione_richiesta)
			{
			RiempiFinestra(1,6,4,42,3,0); // Message: see "Messag.txt" in Tester's compact flash
			fase_comunicazione = PARAMETRI_STATI;
			attivazione_richiesta = 0;
			pid_attivo = 0;
         return NUOVA_DOMANDA;
			} // end if answer error

		//If something wrong happen, the attempts are increased
		//If the attempts exceed the available rx attempts the
		//Activation is started again
		rx_bad++;											
														
      if (rx_suc >= NUM_RX_SUC)						
			{
			BlinkTime = 250;
			pid_attivo = 0;
			// Setting to 0 the tx_rx attempt counter
			rx_bad = 0;	
    		// Setting to 0 the following attempt tx_rx counter		
	    	rx_suc = 0;									
			// Setting to 0 the tx_rx Reactivation attempt counter
			num_tentativi_attivazione = 0;			
         return RIPROVA_ATTIVAZIONE;
			}
				// If the attempt limit is not reach
		else 											
			{
			DEBUG_LED = ~DEBUG_LED;
				// If the attempt limit is exceeded 
			if (rx_bad >= NUM_RX_BAD)					
				{
				rx_suc++;
				switch (fase_comunicazione)
					{
               case PARAMETRI_STATI:
               // pid_attivo = 0 is the Normal Question
               	if(pid_attivo >= 1)			
                     {
               		pid_abilitati[pid_attivo / 8] &=  ~(1 << (pid_attivo % 8));	// Reset
                     DisabilitaSingoloSnap(pid_attivo);
                     }
               	pid_attivo++;
               break;



					case START_ATTIVAZIONE:
						// Msg: Activation not available
						RiempiFinestra(1,6,4,42,3,0);
						fase_comunicazione = PARAMETRI_STATI;
						attivazione_richiesta = 0;
						pid_attivo=0;
						break;

					default:
						fase_comunicazione = PARAMETRI_STATI;
						attivazione_richiesta = 0;
						stato_attivazione = ATT_ABORT;
						pid_attivo = 0;
               break;
					}	// switch
				return NUOVA_DOMANDA;
				}	//if
			}  // else
		}	
	return ERRORE_SCONOSCIUTO;
	}

//------------------------------------------------------------------------------
// DESCRIPTION:   This function manages the different phases of ECU
//                initialization.
// F/P CALLING:   AttivaEcu (sistema.c)
// F/P CALLED:    ResetOrol (Time.c)
//                GetTime (Time.c)
// PARAMETER IN:  Reset (boolean value to reset management)
// PARAMETER OUT: Phase of comunication during ECU initialization
//------------------------------------------------------------------------------
__far uint8_t Attiva_Fast(BOOL Reset)
{


static _fase;
uint8_t Result=0;


if (Reset)
	{
	_fase  = IDLE;
	return IDLE;
	}


switch (_fase)
   {
   case IDLE:
		ResetOrol(&ltime);
		_fase=ATTIVA_FAST;
	break;

	case ATTIVA_FAST :
	
			SCR1_RXE = 0;
			SCR1_REC = 0;
			SMR1_SOE = 0;
			UMC0_SOE = 0;
			//PDR4 |= 0x20;
			//PDR4 |= 0x01;
			_fase++;
	
   break;

	case ATTIVA_FAST + 1:
		ResetOrol(&ltime);
		PDR4 &= 0xDf;
		PDR4 &= 0xfe;
		_fase++;
	break;

	case ATTIVA_FAST + 2:
		if (GetTime(&ltime) >= 25)
			{
			ResetOrol(&ltime);
			PDR4 |= 0x20;
			PDR4 |= 0x01;
			SMR1_SOE = 1;
			UMC0_SOE = 1;
			SCR1_RXE = 1;
			SCR1_REC = 1;
			_fase++;
			}
	break;

	case ATTIVA_FAST + 3:
//anto23032006		if (GetTime(&ltime) >= 24)
		if (GetTime(&ltime) >= 25)
      	return (ENDOK);
   break;

   default:
   break;
   }

return (RUNNING);

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function sends a byte on K and L lines at 5 baude without
//                stop bit.
//                initialization.
// F/P CALLING:   AttivaEcu (sistema.c)
// F/P CALLED:    ResetOrol (Time.c)
//                GetTime (Time.c)
// PARAMETER IN:  _send_byte (byte to transmit)
//                Reset (boolean value to reset management)
// PARAMETER OUT: Phase of comunication during 5-baude trasmission
//------------------------------------------------------------------------------
int16_t Send5Baud (uint8_t _send_byte, BOOL Reset)
{

// 5-baude trasmission phases
#define SEND_START		0x10
#define SPEDISCO_BIT	0x20
#define SEND_STOP			0x30

// Time in trasmission
#define WAIT_START_COM	2000	// Waiting time with line disabled
#define TEMPO_DI_BIT		200		// Slot at 5 baude

#define NUM_BIT_TX		8

// Variable declaration
static int16_t _fase;				    // 5 baude trasmission phase
static uint8_t _conta_bit;		  // Number of trasmitted bit counter
static uint8_t _byte_ricevuto;	// Byte to trasmit
static uint16_t _sh_Time;			  // Variable for time management

	if (Reset)
	{
		_fase = 0;
		_conta_bit = 0;
		return IDLE;
	}

	switch (_fase)
		{
   	case IDLE:
			_fase = SEND_START;
			_byte_ricevuto = _send_byte;
			_conta_bit = 0;
		break;

		case SEND_START:
			SCR1_RXE=0;			// Uart 1 disabled

			S0_TX = 1;			// Start setting on output line
			S1_TX = 1;

			PORT_S0_TX = 1;	// UART line in ouput mode
			PORT_S1_TX = 1;

			SMR1_SOE = 0;		// Uart 1 Pin of microcontroller in generic I/O mode
			UMC0_SOE = 0;		// Uart 0 Pin of microcontroller in generic I/O mode

			ResetOrol(&_sh_Time);

			_fase++;

		break;

		case SEND_START + 1:
			if (GetTime(&_sh_Time) >= WAIT_START_COM)	// Line disabled for 2 s
				{
				ResetOrol(&_sh_Time);
				S0_TX = 0;			// Value Setting on output line
				S1_TX = 0;
				_fase++;
				}
		break;

		case SEND_START + 2:		// Bit trasmission
			if (GetTime(&_sh_Time) >= TEMPO_DI_BIT)
				{
				ResetOrol(&_sh_Time);

				if(_conta_bit < NUM_BIT_TX)
					{
					if(_byte_ricevuto & 0x01)	// Less significative bit
						{
						S0_TX = 1;			// Value Setting on output line
						S1_TX = 1;
						}
					else
						{
						S0_TX = 0;			// Value Setting on output line
						S1_TX = 0;
						}

					// Next bit to trasmit
					_byte_ricevuto >>= 1;

					// Number of bits to trasmit
					_conta_bit ++;

					}
				else				    // Exit function after 8 bit trasmitted
					{
					S0_TX = 1;		// Value Setting on output line
					S1_TX = 1;

					SCR1_REC = 0;	// Possible error deleting on UART 1

					_fase = SEND_STOP;
					}
				}
      break;

		case SEND_STOP:				// ATTENTION: THE STOP BIT ISN'T TRASMITTED
			if (GetTime(&_sh_Time) >= 1)
				{
				SMR1_SOE = 1;		  //  UART 1 line in ouput mode
				UMC0_SOE = 1;		  //  UART 0 line in ouput mode

				SCR1_RXE = 1;		  // Uart 1 reception disabled

				UMC0_RFC = 0;		  // Possible error deleting on UART 0

				ResetOrol(&lTout);
				_fase = IDLE;
				}
		break;

		default:
			_fase = IDLE;
		break;
	}

	if (_fase != IDLE)
		return RUNNING;
	else
		return ENDOK;
}

//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to receive ISO code from ECU in "Slow"
//                initialization and to trasmit the complement of ISO last byte.
// F/P CALLING:   AttivaEcu (sistema.c)
// F/P CALLED:    Reset_rx (Serial.c)
//                BytesInReceiveBuffer (Serial.c)
//                PutByte (Serial.c)
//                GetByte (Serial.c)
//                Sveglia_tx (Serial.c)
//                GetTime (Time.c)
//                ResetOrol (Time.c)
// PARAMETER IN:  linea_utiliz (reception line)
//                Reset (boolean value to reset management)
// PARAMETER OUT: Phase of comunication during ISO code waiting
//----------------------------------------------------------------------------------------------
int16_t Wait_iso (uint8_t linea_utiliz, BOOL Reset)
{

// ISO code waiting trasmission phases
#define START_ISO			0
#define WAIT_COD_ISO	10
#define FINISH_ISO		20

// Byte length of ISO code
#define NUM_BYTE_ISO	3

// Timing
#define ISO_TOUT_RX		500	// Time between trasmission ECU address trasmission and ISO code reception
#define ISO_RX				100	// Time between ISO code reception and complement of last ISO byte trasmission


	static uint8_t _fase;

	if (Reset)
		{
		_fase = START_ISO;
		Reset_rx(linea_utiliz);
		return 0;
		}

	// Timeout management
	if ((GetTime(&lTout) > ISO_TOUT_RX) && (_fase > START_ISO))
		{
		_fase = START_ISO;
		return TOUT;
		}

	switch (_fase)
    {
		case START_ISO:
			Reset_rx(linea_utiliz);
			ResetOrol(&lTout);
			_fase = WAIT_COD_ISO;
		break;

		case WAIT_COD_ISO:		// 3rd ISO byte waiting
			if (BytesInReceiveBuffer(linea_utiliz))
				{
				ResetOrol(&lTout);

				// Reading of ISO code received from ECU
				if (com[linea_utiliz].rx_in>=NUM_BYTE_ISO)
					{
				/*	for (_i = 0; _i < NUM_BYTE_ISO; _i++)
						{
						// "3 * _i" is to let an empty space
						setInfo[I_CODICE_ISO][3 *_i] = ConvertiCar(GetBytefromBuffer(linea_utiliz,_i) >> 4);
						setInfo[I_CODICE_ISO][3 *_i + 1] = ConvertiCar(GetBytefromBuffer(linea_utiliz,_i) & 0x0f);
						}*/
					_fase++;
			return RUNNING;
					}
				}
		break;

		case WAIT_COD_ISO + 1:
			// ISO_RX waiting time to start the comunication
			if(GetTime(&lTout) >= ISO_RX)
				{
        // Complement of 3rd ISO code byte sending and reset of the trasmission buffer
				com[linea_utiliz].tx_out = 0;
				com[linea_utiliz].tx_in = 0;
				PutByte(linea_utiliz,(0xff - GetBytefromBuffer(linea_utiliz,2)));
				Sveglia_tx(linea_utiliz);

				_fase ++ ;
				}
		break;

		case WAIT_COD_ISO + 2:
			// Complement of 3rd ISO code byte waiting
			if (BytesInReceiveBuffer(linea_utiliz))
				{
				if(GetByte(linea_utiliz) == (0xff - CODICE_CENTRALINA))
				  {
					_fase = FINISH_ISO;
					}

/*
IMPORTANT: DELETE THE FOLLOWING "else" STATEMENT TO ENABLE "SLOW" INITIALIZATION
*/
				else 
					{
					_fase = START_ISO;
					return WRONGSTEP;
					}		
				}
      break;

		default:
      	_fase = START_ISO;
      break;
		}



	if (_fase != FINISH_ISO)
		{
		return RUNNING;
		}
	else 
		{
		_fase = START_ISO;
		return ENDOK;
		}

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to manage ECU initialization.
// F/P CALLING:   SystemManager (sistema.c)
// F/P CALLED:    Attiva_Fast (sistema.c)
//                SetBaudRate (sistema.c)
//                Send5Baud (sistema.c)
//                Wait_iso (sistema.c)
//                GestioneErroreRX (sistema.c)
// PARAMETER IN:  Reset (boolean value to reset management)
// PARAMETER OUT: Phase of comunication during ECU initialization
//------------------------------------------------------------------------------
__far uint8_t AttivaEcu(BOOL Reset)
{

static _fase;
static uint8_t _esito_rx;
uint8_t Result=0;


if (Reset)
	{
	_fase  = IDLE;
	return IDLE;
	}

switch(_fase)
	{
	case IDLE:
		SCR1_RXE=0;
		SMR1_SOE = 0;
		UMC0_SOE = 0;
		PDR4 |= 0x20;
		PDR4 |= 0x01;
/*
IMPORTANT: IN DOUBLE INITIALIZATION ("SLOW" AND THEN "FAST") DISABLE THE FOLLOWING
3 INSTRUCTIONS AND ENABLE THE LAST ONE. MODIFY "Wait_iso" AND "AttivaEcu" PROCEDURE ALSO.
*/
		Attiva_Fast(TRUE);
		_fase = ATTIVA_FAST;
    SetBaudRate(KLINE, 10400L);
//		_fase = ATTIVA_SLOW;
   break;


	case ATTIVA_SLOW:
		if (Send5Baud (CODICE_CENTRALINA, FALSE) == ENDOK)
			{
			// Baud rate setting
			SetBaudRate(KLINE, 10400L);
			Wait_iso(KLINE, TRUE);
			fase_comunicazione = WAIT_ISO;
			_fase = WAIT_ISO;
			}
   break;

	case WAIT_ISO:
   	{
		// Code ISO waiting
		_esito_rx = Wait_iso(KLINE, FALSE);

		if (_esito_rx == ENDOK)
		 	{
			fase_comunicazione = RICHIEDI_INFO1;
      return(ENDOK);
			}
		else if (_esito_rx == WRONGSTEP)
			{
			GestioneErroreRX(_esito_rx,FALSE);
			}

		else if (_esito_rx == TOUT)
			{
         Attiva_Fast(TRUE);
			_fase = ATTIVA_FAST;
			}

      }
   break;

	case ATTIVA_FAST:
   	if (Attiva_Fast(FALSE) == ENDOK)
    	{
      	fase_comunicazione = RICHIESTA_FAST;
				BlinkTime = 200;
				pid_attivo = 0;
      	return(ENDOK);
   		}
   break;

	default:
   break;
	}

return(RUNNING);
}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to re-activate comunication to ECU.
// F/P CALLING:   InterpretaRisposta (sistema.c)
// F/P CALLED:    RiempiFinestra (SisPCInterf.c)
//                ResetOrol (Time.c)
//                GetTime (Time.c)
// PARAMETER IN:
// PARAMETER OUT:
//------------------------------------------------------------------------------
//Riattiva la comunicazione con la centralina
__far void Riattiva(void)
{

	if(stato_attivazione != ATT_ABORT)		// Controllo che ci sia ancora una cancellazione errori in corso
	  	{
/* START PARTE ORIGINALE
      switch(fase_comunicazione)
         {

         case FINE_COMUNICAZIONE:
         	//Msg: Spegnere il quadro e premere F9 per continuare
            RiempiFinestra(1,0,4,145,0,0);
				valore_impostato = 0;
				fase_comunicazione = ATTESA_TASTO_1;
         break;

         case ATTESA_TASTO_1:
				if(valore_impostato == TASTO_F9)
					{
					//Msg: Attendere prego
					RiempiFinestra(1,6,4,5,0,0);
               fase_comunicazione = ATTESA;
               ResetOrol(&ltime);
               }
         break;

         case ATTESA:
				if (GetTime(&ltime) >= 12000)
               {
					//Msg: Accendere il quadro e premere F9 per continuare
					RiempiFinestra(1,0,4,41,0,0);
					valore_impostato = 0;
					fase_comunicazione = ATTESA_TASTO_2;
               }
         break;

         case ATTESA_TASTO_2:
				if(valore_impostato == TASTO_F9)
               {
            	//Msg: Accendere il quadro e premere F9 per continuare
					RiempiFinestra(1,2,4,41,0,0);
               stato_attivazione = END_ATT_OK;
               fase_comunicazione = RIATTIVA;
               valore_impostato == 0;
               }
         break;

         default:
         break;
         }
   STOP  PARTE ORIGINALE */

// START PARTE MODIFICATA
      switch(fase_comunicazione)
         {

         case FINE_COMUNICAZIONE:
				   valore_impostato = 0;
				   fase_comunicazione = ATTESA_TASTO_1;
         break;

         case ATTESA_TASTO_1:
           fase_comunicazione = ATTESA;
           ResetOrol(&ltime);
         break;

         case ATTESA:
				   if (GetTime(&ltime) >= 12000)
             {
					     valore_impostato = 0;
					     fase_comunicazione = ATTESA_TASTO_2;
             }
         break;

         case ATTESA_TASTO_2:
            // Messaggio "virtuale" per cancellare precedente finestra (di cancellazione in corso)
            RiempiFinestra(1,2,0,0,0,0);
           stato_attivazione = END_ATT_OK;
           fase_comunicazione = RIATTIVA;
           valore_impostato == 0;
         break;

         default:
         break;
         }
// STOP  PARTE MODIFICATA
      }
   else
   	{
      pid_attivo=0;
      fase_comunicazione = RIATTIVA;
      }
}

//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to compose the request for ECU and put
//                in trasmission buffer.
// F/P CALLING:   SequenzaDomande (sistema.c)
// F/P CALLED:
// PARAMETER IN:  _service (phase of comunication)
//                _pid (request identifier)
//                Stato (phase during active-test)
// PARAMETER OUT: 0/1 (depending if the procedure is executed)
//------------------------------------------------------------------------------
uint8_t ComponiDomanda (int16_t _service,int16_t _pid,uint8_t Stato)
{
// The global variable "len_tx" is the frame length without check-sum
uint8_t _Index = 0; // Counter for iterations
uint8_t _cksum = 0; // Check-sum
uint8_t _Len = 0;   // Data length (not frame length)

Stato = 0;
// Trasmission buffer reset
for (_Index=0; _Index < LUNGH_BUFFER_TX; _Index++)
	buffer_Tx[_Index]=0;

if (_service == VUOTA) return 0;

// Frame length (without check-sum) default: 3
len_tx = 1;
 
// "Header" building
_Index = 0;
buffer_Tx[_Index++] = 0x80;

switch (_service)
	{

//////////////////////////////////////
case FINE_COMUNICAZIONE_1 :
		{
      _Len= 0x03;
      	buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x82;
		len_tx = _Index;
  		}
	break;
	
	case FINE_COMUNICAZIONE_2 :
		{
      _Len= 0x03;
      	buffer_Tx[_Index++] = 0xD0;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x82;
		len_tx = _Index;
  		}
	break;

/////////////////////////////////////

	case RICHIESTA_FAST :
		{
      _Len= 0x03;
      	buffer_Tx[_Index++] = 0xD0;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x81;
		len_tx = _Index;
  		}
	break;

	case RICHIEDI_INFO1:	    // "Information 1" request
	//Sotto funzione Calcolatore, sono le Info_1
	
		{
		_Len = 0x04;
		buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x21;
		buffer_Tx[_Index++] = 0x80;
		len_tx = _Index;

		}
   break;

	/*case RICHIEDI_INFO2:	    // "Information 2" request
	//Sotto funzione Satelliti, sono le Info_2
		{
		_Len = 0x04;
		buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x21;
		buffer_Tx[_Index++] = 0xD1;
		len_tx = _Index;
		}
   break;
	*/
	case NORMALE:							// "Tester Present" 
		_Len = 0x03;
		buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = domanda[_pid];
		len_tx = _Index;
   break;

	case PARAMETRI_STATI:			// "Parameter/Status" request
		{
      switch (_pid)
			{
     		case 0://NORMAL
					_Len = 0x03;
					buffer_Tx[_Index++] = 0xB3;
					buffer_Tx[_Index++] = 0xF1;
					buffer_Tx[_Index++] = domanda[_pid];
					len_tx = _Index;
      		break;

      		case 1 ://STATUS_1 REQUEST
     				_Len = 0x04;
					buffer_Tx[_Index++] = 0xB3;
					buffer_Tx[_Index++] = 0xF1;
					buffer_Tx[_Index++] = 0x21;
					buffer_Tx[_Index++] = domanda[_pid];
					len_tx = _Index;
        	break;
        	
        	case 2 ://STATUS_2 REQUEST
     				_Len = 0x04;
					buffer_Tx[_Index++] = 0xB3;
					buffer_Tx[_Index++] = 0xF1;
					buffer_Tx[_Index++] = 0x21;
					buffer_Tx[_Index++] = domanda[_pid];
					len_tx = _Index;
        	break;
        	
        	case 3 ://STATUS_3 REQUEST
     			_Len = 0x04;
				buffer_Tx[_Index++] = 0xB3;
				buffer_Tx[_Index++] = 0xF1;
				buffer_Tx[_Index++] = 0x21;
				buffer_Tx[_Index++] = domanda[_pid];
				len_tx = _Index;
        	break;
        	
        	

	      	}
		}
   break;

	case START_ATTIVAZIONE:
	switch (_pid)
	{
		case 1:
			_Len = 0x04;
			buffer_Tx[_Index++] = 0xB3;
			buffer_Tx[_Index++] = 0xF1;
			buffer_Tx[_Index++] = 0x3B;
			buffer_Tx[_Index++] = domanda_att[_pid];
			len_tx = _Index;
		break;
		
		case 2:
			_Len = 0x04;
			buffer_Tx[_Index++] = 0xB3;
			buffer_Tx[_Index++] = 0xF1;
			buffer_Tx[_Index++] = 0x3B;
			buffer_Tx[_Index++] = domanda_att[_pid];
			len_tx = _Index;
		break;
	}
	break;
	
	case RUN_ATTIVAZIONE:							// Attivazione in corso
   	case END_ATTIVAZIONE:							//Fine Attivazione
   	switch(_pid) //Attivazioni
	{
		case 1:
			_Len = 0x04;
			buffer_Tx[_Index++] = 0xB3;
			buffer_Tx[_Index++] = 0xF1;
			buffer_Tx[_Index++] = 0x3B;
			buffer_Tx[_Index++] = domanda_att[_pid];
			len_tx = _Index;
		break;
		
		case 2:
			_Len = 0x04;
			buffer_Tx[_Index++] = 0xB3;
			buffer_Tx[_Index++] = 0xF1;
			buffer_Tx[_Index++] = 0x3B;
			buffer_Tx[_Index++] = domanda_att[_pid];
			len_tx = _Index;
		break;
	}
	break;
	


	case RICHIEDI_ERRORI:			// "Error reading" request
		_Len = 0x05;
		buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = domanda[_pid];
		buffer_Tx[_Index++] = 0xff;
		buffer_Tx[_Index++] = 0x00;
		len_tx = _Index;
   	break;


   case START_CANC_ERRORI:	// "Error deleting" starts 
	    _Len = 0x05;
		buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x14;
		buffer_Tx[_Index++] = 0xff;
		buffer_Tx[_Index++] = 0x00;
		len_tx = _Index;
   	break;
	

	case RUN_CANC_ERRORI:	// "Error deleting" starts 
	    _Len = 0x1A;
		buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x3B;
		buffer_Tx[_Index++] = 0xE3;
		buffer_Tx[_Index++] = 0x45;
		buffer_Tx[_Index++] = 0x78;
		buffer_Tx[_Index++] = 0x70;
		buffer_Tx[_Index++] = 0x65;
		buffer_Tx[_Index++] = 0x72;
		buffer_Tx[_Index++] = 0x74;
		buffer_Tx[_Index++] = 0x69;
		buffer_Tx[_Index++] = 0x73;
		buffer_Tx[_Index++] = 0x65;
		buffer_Tx[_Index++] = 0x41;
		buffer_Tx[_Index++] = 0x43;
		buffer_Tx[_Index++] = 0x55;
		buffer_Tx[_Index++] = 0x33;
		buffer_Tx[_Index++] = 0x4F;
		buffer_Tx[_Index++] = 0x6E;
		buffer_Tx[_Index++] = 0x2C;
		buffer_Tx[_Index++] = 0x65;
		buffer_Tx[_Index++] = 0x70;
		buffer_Tx[_Index++] = 0x63;
		buffer_Tx[_Index++] = 0x27;
		buffer_Tx[_Index++] = 0x74;
		buffer_Tx[_Index++] = 0x21;
		len_tx = _Index;
   	break;

	case END_CANC_ERRORI:	// "Error deleting" starts 
	    _Len = 0x04;
		buffer_Tx[_Index++] = 0xB3;
		buffer_Tx[_Index++] = 0xF1;
		buffer_Tx[_Index++] = 0x11;
		buffer_Tx[_Index++] = 0x81;
		len_tx = _Index;
   	break;


   

   

	default:
		return 0;
	}	// end switch (_service)


// Data length calculation
buffer_Tx[0] += (_Len - 2);

// Check-sum calculation
_cksum = 0;

for (_Index=0; _Index<len_tx; _Index++)
	_cksum += buffer_Tx[_Index];

buffer_Tx[len_tx] = _cksum;

return 1;
}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to manage the correct sequences of
//                request.
// F/P CALLING:   SystemManager (sistema.c)
// F/P CALLED:    ComponiDomanda (sistema.c)
// PARAMETER IN:  Reset (boolean value to reset management)
// PARAMETER OUT: waiting time
//------------------------------------------------------------------------------
uint16_t SequenzaDomande (BOOL Reset)
{

static int16_t _cicla;
static uint32_t attivazione;

uint8_t appoggio1,appoggio;



if (Reset)
	{
	return IDLE;
	}

switch (fase_comunicazione)
	{
	
	case FINE_COMUNICAZIONE_1:	// "End comunication" request
		ComponiDomanda(FINE_COMUNICAZIONE_1,0,0);
    return (WAIT_TIME_2);
	break;
	
	/*case FINE_COMUNICAZIONE_2:	// "End comunication" request
		ComponiDomanda(FINE_COMUNICAZIONE_2,0,0);
    return (WAIT_TIME_2);
    */
	
	
   case RICHIESTA_FAST:
  		ComponiDomanda(RICHIESTA_FAST,0,0);
   return (NO_WAIT);
   break;

	case RICHIEDI_INFO1:
		ComponiDomanda(RICHIEDI_INFO1,0,0);
   return (WAIT_TIME_1);
   break;

	case RICHIEDI_INFO2:
		ComponiDomanda(RICHIEDI_INFO2,0,0);
   return (WAIT_TIME_1);
   break;

	case NORMALE:				      // "Tester present"
		ComponiDomanda(NORMALE,0,0);
   return (WAIT_TIME_1);
   break;

	case PARAMETRI_STATI:
		if (pid_attivo!=0)
				{
			_cicla = 1;
			while(_cicla)
				{
				appoggio = pid_abilitati[pid_attivo / 8] & pid_richiesti[pid_attivo / 8];
				appoggio1 = (1 << ((pid_attivo % 8)));
        // Most significative bit of "appoggio" is "1" if PID is enabled
				if ((appoggio & appoggio1)||(pid_attivo>=tot_domande-1))
					_cicla = 0;
				else
					pid_attivo++;
				}


         if (pid_attivo>=(tot_domande - 1))	// At the end of "Parameter and Status" request
					{
				if (new_par == 2)
					{
					Aggiusta_valori();
					new_par = 0;
					}

				if (new_par == 1)
					new_par = 2;


				pid_attivo = 0;
				_cicla = 0;

				fase_comunicazione = RICHIEDI_ERRORI;

				ComponiDomanda(RICHIEDI_ERRORI,4,0);
   		    	return (WAIT_TIME_1);
				}

			}	// Chiusura if (!pid_attivo)
		

      if(fase_comunicazione == PARAMETRI_STATI)
      	ComponiDomanda(PARAMETRI_STATI,pid_attivo,0);
   return (WAIT_TIME_1);
   
   break;


	case RICHIEDI_ERRORI:
	case RICHIEDI_ERRORI_1:
	   	ComponiDomanda(RICHIEDI_ERRORI,4,0);
   return (WAIT_TIME_1);
   break;

	case START_CANC_ERRORI:		// "Error delete" starting request
      ComponiDomanda(START_CANC_ERRORI,0,0);
   return (WAIT_TIME_4);
   break;
   
   case RUN_CANC_ERRORI:		// "Error delete" starting request
      ComponiDomanda(RUN_CANC_ERRORI,0,0);
   return (WAIT_TIME_1);
   break;

	case FINE_COMUNICAZIONE:		// "Error delete" starting request
      ComponiDomanda(END_CANC_ERRORI,0,0);
   return (WAIT_TIME_1);
   break;

	
	case START_ATTIVAZIONE:		// Compongo la domanda per lo start attivazione
		attivazione = attivazione_richiesta;
      	ComponiDomanda(START_ATTIVAZIONE,attivazione-1,0);
   return (WAIT_TIME_1);
   break;

   case RUN_ATTIVAZIONE:		// Compongo la domanda per attivazione IN CORSO
		ComponiDomanda(RUN_ATTIVAZIONE,attivazione-1,0);
   		if (fase_attivazione==INIZIO)
        	return (WAIT_TIME_3);
      	else
         return (WAIT_TIME_1);
  break;

 	 case END_ATTIVAZIONE:		// Compongo la domanda per terminare l'attivazione
		ComponiDomanda(END_ATTIVAZIONE,attivazione-1,0);
   		return (WAIT_TIME_1);
  	break;
		
		
		case ATTESA_TASTO_1:
   		case ATTESA_TASTO_2:
   		case ATTESA:
			ComponiDomanda(VUOTA,0,0);
   			return (NO_WAIT);
   		break;


	default:
   return NO_WAIT;
	break;
	} // switch (fase_comunicazione)

return NO_WAIT;

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to trasmit frame of "Richiesta".
//                request.
// F/P CALLING:   SystemManager (sistema.c)
// F/P CALLED:    ResetOrol (Time.c)
//                GetTime (Time.c)
//                Tx_Empty (Serial.c)
//                PutByte (Serial.c)
//                Sveglia_tx (Serial.c)
//                ResetOrol (Time.c)
// PARAMETER IN:  K_l (trasmission line)
//                Wait_Time (waiting time)
//                Reset (boolean value to reset management)
// PARAMETER OUT: Exit code (x00 = Fine Ok; 0x21 = Running; 0x01 = Fine error)
//------------------------------------------------------------------------------
__far uint8_t Tx_Request(uint8_t K_l,uint16_t Wait_Time, BOOL Reset)
{
	#define TX_KL	10
	#define ERR		20

	#define TXDELAY					  4
	#define TXSAFETYDELAY			1	 // Waiting time to trasmission ending
  #define TXERROR					100  // Waiting time to go on error

// The global variable "len_tx" is the frame length without check-sum initialized in "Componi_Domanda"
	static uint8_t fase;
	static uint16_t TxByte;  // Number of tx byte in progress
	static uint16_t ldelay;



	if (Reset)
		{
		fase  = IDLE;
		return IDLE;
		}


   switch (fase)
		{
		case IDLE:
			ResetOrol(&ldelay); // Timer reset
			TxByte = 0;
			fase = TX_KL - 1;
		break;

		case TX_KL - 1:
        	if (GetTime(&ldelay) >= Wait_Time)
        		fase++;
		break;

		case TX_KL + 0: //Start transmission Tx byte until TotTxByte (end of frame)
			if ((Tx_Empty(K_l)) && (GetTime(&ldelay) >= TXDELAY )) // Witing empty buffer
				{
				// Byte to trasit in appropriate COM
				PutByte(K_l,buffer_Tx[TxByte++]);
				Sveglia_tx(K_l);		  // Start the trasmission
				ResetOrol(&ldelay);		// Timer reset

				// The next phase at the end of trasmission
				if (TxByte > len_tx)
					fase++;
				}

        	if (GetTime(&ldelay) > TXERROR)
				fase = ERR;
		break;

		case TX_KL + 1:
			// Waiting empty buffr before hearing "eco"
			if (Tx_Empty(K_l)==TRUE)
				{

				// Attendo che il dato sia stato caricato sullo shift register di uscita
				if ((SSR1 & BIT3))
					{
					ResetOrol(&ldelay); // Timer reset
					fase++;
					}

				// Timeout management
				if (GetTime(&ldelay) > TXERROR)
					fase = ERR;

   			}
      break;

		case TX_KL + 2:
			// TXSAFETYDELAY waiting before resetting trasmission buffer (it contains the "eco" of trasmission also)
			if (GetTime(&ldelay) > TXSAFETYDELAY )
				{
				Reset_rx(K_l);		// Buffer reset
				fase = IDLE;
				}
      break;

		default:
        	fase=IDLE;
			return WRONGSTEP;
		break;

		}

	//Exit code
	if (fase!=IDLE)
		return RUNNING;
	else
		return ENDOK;

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to check the frame received.
//                request.
// F/P CALLING:   RxAnswer (sistema.c)
// F/P CALLED:    GetBytefromBuffer (SisPCInterf.c)
// PARAMETER IN:  _com (reception line)
//                _byte_da_ricevere (byte read)
// PARAMETER OUT: 0/3 ("0" if check-sum is ok; "3" if check-sum is wrong)
//------------------------------------------------------------------------------
uint8_t RispostaOk (uint8_t _com, uint8_t _byte_da_ricevere)
{
uint8_t _i;
uint8_t _ck_calc;

_ck_calc = 0;


	// Calculate and check the check-sum
	for (_i = 0; _i < _byte_da_ricevere; _i++)
		_ck_calc += com[_com].rx_buf[_i];

	if(_ck_calc != GetBytefromBuffer(_com,_byte_da_ricevere))
		return (3);

	if	((GetBytefromBuffer(KLINE,1) != 0xF1) || ((GetBytefromBuffer(KLINE,2) != 0xD0)) && (GetBytefromBuffer(KLINE,2) != 0xB3))
   	return(1);

	return(0);
}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to manage the frame reception.
// F/P CALLING:   ObdSystem (main.c)
//                SystemManager (sistema.c)
// F/P CALLED:    GetTime (Time.c)
//                ResetOrol (Time.c)
//                BytesInReceiveBuffer (Serial.c)
//                GetByte (Serial.c)
// PARAMETER IN:  K_l (trasmission line)
//                Reset (boolean value to reset management)
// PARAMETER OUT: Exit code (IDLE in reset phase; TOUT in time-out phase;
//                RUNNING in running phase)
//------------------------------------------------------------------------------
__far uint8_t RxAnswer(uint8_t K_l, BOOL Reset)
{

	#define FRAMING_TIMEOUT_RX	1000

	// Phases in answer reception
	#define WAITLEN		10
	#define RXFRAME		30
	#define DECODE		40

	static uint8_t fase;					    // Variable for phase
	static uint8_t _byte_da_ricevere;	// Numero di byte da ricevere escluso checksum

	if (Reset)
		{
		fase = IDLE;
		pid_attivo = 0;
		return IDLE;
		}



	// Time-out checking if the reception isn'ended
	if (GetTime(&lTout) > FRAMING_TIMEOUT_RX)
		{
		fase = IDLE;
		return TOUT;		//Error timeout
		}


	switch (fase)
		{
		case IDLE:
			fase = WAITLEN;
			ResetOrol(&lTout);
			_byte_da_ricevere = 0;
		break;

		case WAITLEN: // Bytes waiting
			if (BytesInReceiveBuffer(K_l))	// Byte received?
				{
				GetByte(K_l);			// Take byte and add "com[K_l].rx_out" counter
				if(com[K_l].rx_in >= 1)
					{
					_byte_da_ricevere = com[K_l].rx_buf[0] - 0x80 + 3; // Calculate the frame length 
          // "_byte_da_ricevere" is the number of byte remaining to receive
          // 1st byte (stored in the buffer), ECU address, Tester address aren't included
   				// Data length is contained in the 1st byte (added with 0x80), ...
          // ... Total length = (1st byte stored in the buffer) Data length + check-sum
					fase++;
               }
				ResetOrol(&lTout);
				}
		break;


    // Check the byte received
		case WAITLEN + 1:
			if (BytesInReceiveBuffer(K_l))
				{
				GetByte(K_l);				// Take byte and add "com[K_l].rx_out" counter
				ResetOrol(&lTout);
				if(com[K_l].rx_in > _byte_da_ricevere)	// Wait all the bytes of frame
					{
					if(!RispostaOk(K_l,_byte_da_ricevere))
               	fase = IDLE;
					else
						{
						fase = IDLE;
               	return WRONGSTEP;
						}
					}
				}
		break;

		default:
			fase = IDLE;
			pid_attivo = 0;
			return WRONGSTEP;
		break;
		}

	//Exit code
	if(fase == IDLE)
		return ENDOK;
	else
		return RUNNING;

}





//------------------------------------------------------------------------------
// DESCRIPTION:   This function is used to decode the answers received and store
//                them in thecorrect structure.
// F/P CALLING:   SystemManager (sistema.c)
// F/P CALLED:    InterpretaInfo (sistema.c)
//                InterpretaParametriStati (sistema.c)
//                InterpretaErrori (sistema.c)
//                RiempiFinestra (SisPCInterf.c)
// PARAMETER IN:
// PARAMETER OUT: 
//------------------------------------------------------------------------------
void InterpretaRisposta(void)
{

	switch (fase_comunicazione)
		{



		case RICHIESTA_FAST:
		  fase_comunicazione = RICHIEDI_INFO1;
		  pid_attivo = 0;
      break;

		case RICHIEDI_INFO1:
			//Modifiche per la 206
			//case RICHIEDI_INFO2:
			// The information are decoded once
         	//Modifiche per la 206
			InterpretaInfo();
			//if (fase_comunicazione == RICHIEDI_INFO1)
			//fase_comunicazione = RICHIEDI_INFO2;
			//else
  			fase_comunicazione = NORMALE;
      break;

		case NORMALE:
			fase_comunicazione = PARAMETRI_STATI;
		   	
		   	pid_attivo++;
		break;

		case PARAMETRI_STATI:	// Parametri/Status/Tester present
			InterpretaParametriStati();
			pid_attivo++;
      break;

		case RICHIEDI_ERRORI:
        	InterpretaErrori();
			SisStatus = DATA_OK;
        	fase_comunicazione = NORMALE;
            pid_attivo = 0;

         if(attivazione_richiesta == 1)
         	{
            //RiempiFinestra(1,6,4,5,0,0);	// Message "Active-test running: please wait" (see "Messag.txt" in Tester's compact flash)
            RiempiFinestra(1,0,34,301,5,0);
            fase_comunicazione = START_CANC_ERRORI;
            //fase_comunicazione = END_CANC_ERRORI;
            }
         else
         	if(attivazione_richiesta > 1 && attivazione_richiesta <= TOTALEATTIVAZIONI)
            	{
               		RiempiFinestra(1,6,4,5,0,0);	// Message "Active-test running: please wait" (see "Messag.txt" in Tester's compact flash)
  					fase_comunicazione = START_ATTIVAZIONE;
                }
      break;
		
		case START_ATTIVAZIONE:
		case RUN_ATTIVAZIONE:
		case END_ATTIVAZIONE:
			InterpretaAttivazione();
      	break;
      	
      
//--------------------------------------------------------------------------------------//
		case START_CANC_ERRORI:
			CancErrori();
			fase_comunicazione = RICHIEDI_ERRORI_1;
		break;
      	
      	case RICHIEDI_ERRORI_1:
        	InterpretaErrori();
			SisStatus = DATA_OK;
        	fase_comunicazione = RUN_CANC_ERRORI;
            pid_attivo = 0;
		break;
      	
          	
      	case RUN_CANC_ERRORI:
            fase_comunicazione = FINE_COMUNICAZIONE;
        break;
		
		
		
		case FINE_COMUNICAZIONE:
    	case ATTESA_TASTO_1:
    	case ATTESA_TASTO_2:
    	case ATTESA:
     		Riattiva();
    	break;

		
     	
		default:
		break;
		} 

}


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is the main routine for every system. It is used
//                to manage all the phases of comunication ECU-Tester.
// F/P CALLING:   ObdSystem (main.c)
// F/P CALLED:    AttivaEcu (sistema.c)
//                SequenzaDomande (sistema.c)
//                Tx_Request (sistema.c)
//                GestioneErroreTX (sistema.c)
//                RxAnswer (sistema.c)
//                GestioneErroreRX (sistema.c)
//                Setta_mux (mux_low_level.c)
//                RxAnswer (sistema.c)
//                InterpretaRisposta (sistema.c)
//                AbilitaPid_Abilitati (Pid.c)
// PARAMETER IN:  Reset (boolean value to reset management)
// PARAMETER OUT: Exit code (0x00 end; 0xFF running; number of error
//------------------------------------------------------------------------------
__near uint8_t SystemManager(BOOL Reset)
{

	#define ATTIVAZIONE				10
	#define TX						20
	#define RX						30
    #define RIATTIVAZIONE			40
	#define TEST_MUX				60



	static uint8_t _fase;				// Phase of comunication

	static uint8_t _result;			// Tx/Rx result

   int16_t result_mux;

	if (Reset)
	{
		_fase = IDLE;
		SisStatus = INIT_WAIT;
		stato_attivazione = ATT_ABORT;
		BlinkTime = 1000;
      return IDLE;
	}


	switch (_fase)
	{
		case IDLE:
			// Interface data not ready
			if (SisStartCom & SISSTARTCOMM)
			{
				SisStartCom  = SisStartCom & (~SISSTARTCOMM);

				// Blink time for LED bicolor
				BlinkTime = 500;

				// Function initialization
				InitPid();
        AttivaEcu(TRUE);
				SequenzaDomande(TRUE);
				Tx_Request(KLINE,0,TRUE);
        GestioneErroreTX(0,TRUE);
				RxAnswer(KLINE, TRUE);
        GestioneErroreRX(0,TRUE);

				_fase = ATTIVAZIONE;

				// Phase of the visualizzator comunication
            SisStatus = DATANOTREADY;
			}
		break;


		case ATTIVAZIONE:
      	LED_BICOLOR1 = 0x00;
			_result = AttivaEcu(FALSE);
			if(_result == ENDOK)
    			{
      		stato_attivazione = END_ATT_OK;
      		_fase = TX;
      		}
		break;

		case TX:		// Building request (but not trasmission)
      	Wait_Time = SequenzaDomande(FALSE);
         _fase++;
      break;


		case TX + 1:		// Request trasmission

			// Reception buffer e K line reset
			Reset_rx(KLINE);

      	switch(fase_comunicazione)
         	{
            case ATTESA_TASTO_1:
   			case ATTESA_TASTO_2:
            case ATTESA:
            	_result=ENDOK;
            	break;

            default:
            	_result = Tx_Request(KLINE,Wait_Time,FALSE);
            }

			if(_result == ENDOK)
				{
				ResetOrol(&lTout); // Time-out reset
            GestioneErroreTX(0,TRUE);
				_fase = RX;
				}
			else
				{
				switch (GestioneErroreTX(_result,FALSE))
					{
					case NESSUNA_CENTRALINA:		// No comunication with ECU
            		if (!p_program_serial_port->mux_used)
							{
							SisStatus = ATT_ABORT;		//	Return to the IDLE phase on visualizzator
							SisStatus |= 0x00000100;
							_fase = IDLE;					    //	Waiting new active-test request
							BlinkTime = 1000;
							}
						else
							{
              Setta_mux(SM_NO_STANDARD, TRUE);
							_fase = TEST_MUX;
							}
               break;

					case RIPROVA_ATTIVAZIONE:	    // Comunication interrupted
                 _fase = RIATTIVAZIONE;	// ECU Re-activate attempting
               break;

					case NUOVA_DOMANDA:
					case ERRORE_SCONOSCIUTO:
						_fase = TX;
               break;
					default:
						_fase = IDLE;
					break;
					}	// end switch()
				}
		break;


		case RX:  // Reception phase
     	_result = RxAnswer(KLINE, FALSE);
            

			if(_result == RUNNING)
				break;

			if(_result == ENDOK) // For every correct answer received
				{
            GestioneErroreRX(0,TRUE);	// Parameter reset to manage the comunication error with ECU
            InterpretaRisposta();
						if (fase_comunicazione == RIATTIVA)
          		_fase = RIATTIVAZIONE;
            else
							_fase = TX;					// Trasmission of a new request
				}
			else
				{// Managing of answer differs from ENDOK and RUNNING
				switch (GestioneErroreRX(_result,FALSE))
					{
					case NESSUNA_CENTRALINA:		//	No comunication with ECU
            		if (!p_program_serial_port->mux_used)
							{
							SisStatus = ATT_ABORT;		//	Return to the IDLE phase on visualizzator
							SisStatus |= 0x00000100;
							_fase = IDLE;					    //	Waiting new active-test request
							BlinkTime = 1000;
							}
						else
							{
              Setta_mux(SM_NO_STANDARD, TRUE);
							_fase = TEST_MUX;
							}
               break;

					case RIPROVA_ATTIVAZIONE:	    // Comunication interrupted
                 _fase = RIATTIVAZIONE;	// ECU Re-activate attempting
               break;

					case ERRORE_SCONOSCIUTO:
					case NUOVA_DOMANDA:
						_fase = TX;
               break;

					default:
						_fase = IDLE;
					break;
					}	// End switch()
				}	// End else
		break; //End case RX

      case RIATTIVAZIONE:
      	// Function initialization
		 	AbilitaPid_Abilitati(ABILITA);
         	AttivaEcu(TRUE);
			SequenzaDomande(TRUE);
			Tx_Request(KLINE,0,TRUE);
			RxAnswer(KLINE, TRUE);
         // Return to the ECU initialization on the visualizzator
			SisStatus = DATANOTREADY;
         _fase = ATTIVAZIONE;
      break;

		case TEST_MUX:
			result_mux = Setta_mux(SM_NO_STANDARD,FALSE);

			if (result_mux != SM_RUNNING)
			{
				_fase = IDLE;
				SisStatus = result_mux;  // Comunication interrupted
				break;
			}
			else if(result_mux == WRONGSTEP)
			{
				_fase = IDLE;
				SisStatus = 0x81;
				break;
			}
		break;

		default:
			_fase = IDLE;
			return WRONGSTEP;
		break;
	}

		//Exit code
		if (_fase!=IDLE)
			return RUNNING;
		else
			return ENDOK;

}

