#include "stdint.h"
typedef struct
{
	uint8_t type;
	// KL ----------------------------------------
	uint32_t baud_rate;
	uint8_t start_bit;
	uint8_t stop_bit;
	uint8_t parity;
	uint8_t n_bit;
	uint8_t activation_type;
	uint8_t activation_address;
	uint8_t target_address;
	uint8_t source_address;
	uint16_t intrabyte_tx;
	uint16_t intrabyte_timeout_ecu;
	uint16_t timeout_frame;
	uint16_t timeout_ecu;
	uint16_t tester_present;
	//-----------------------------------------------------------------
	uint8_t SyncByte;
	uint8_t KeyByte1;
	uint8_t KeyByte2;
	//-----------------------------------------------------------------
	uint8_t attivata;  			// boolean: 1 se la ECU � attivata				 	
	uint8_t settata;				// boolean: 1 se � arrivata la Set_Protocol()
	uint8_t started;				// boolean: 1 se devo mandare il TesterPresent
	//-----------------------------------------------------------------           
	uint8_t buffer_tester_present[20];
	uint8_t quanti_tester_present;
	
	uint8_t buffer_risposta_tester_present[20];
	uint8_t quanti_risposta_tester_present;			
	//-----------------------------------------------------------------	

	// CAN -----------------------------------------------------	
	//uint32_t baud_rate;
	uint16_t id_length;
	//uint8_t target_address;
	//uint8_t source_address;
	uint32_t id_domanda;
	uint32_t id_risposta;
	uint8_t quanti_filters;
	uint32_t filters[4];
	//uint16_t timeout_frame;
	//uint16_t timeout_ecu;
	//uint16_t tester_present;	
	//uint8_t tester_present_required;	
	//uint8_t tipo_attivazione;	
} tipo_ECU;