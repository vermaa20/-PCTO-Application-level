#include "stdint.h"
//------------------------------------------------------------------------------
// HEADING

// PROJECT NAME:     Sis_NNN.prj/Sis_RAM_NNN.prj
// PROJECT RELEASE:  VIEW HEADING OF "sistema.c"
// FILE NAME:        HW.c
// FILE RELEASE:     1.0
// DATE:             February 2004
// FILE DESCRIPTION: HardWare inizialization function
// REVIEW  BY:       Ing. Andrea Acunzo - Ing. Diego Mainardi
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// FURTHER INFORMATIONS

//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// AVAILABLE PRCEDURE/FUNCTION
// __far void HwInit()
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// COMPILER DIRECTIVE

#define HW_C
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// INCLUDE HEADER LIST

#include "typedefs.h"
#include "hw.h"
#include "mux_low_level.h"
#include "vectors.h"
#include "sispcinterf.h"

#include "sistema.h"

#ifndef ACCEMIC_ON
 #ifdef	EMULATOR_ON
	#include "ram_code.h"
 #endif
#endif



//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set pin configuration of IN/OUT port
//                microcontroller.
// F/P CALLING:   main (main.c)
// F/P CALLED:
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void HwInit()
{
	//	The following statement is omitted because it is executed by the start.asm module during the startup
	//	
	//------------------------------------------------------------------------------
	// HACR+ECSR setup (external bus configuration)
	// bit 15 = 1 CKE
	// bit 14 = 0 RYE
	// bit 13 = 0 HDE
	// bit 12 = 0 IOBS
	// bit 11 = 0 HMBS      // area between 0x800000 a 0xffffff (1=8bit / 0=16bit)
	// bit 10 = 1 WRE
	// bit  9 = 1 LMBS      // area between 0x2000 a 0x7fffff (1=8bit / 0=16bit)
	// bit  8 = 0 NOT USED
	// bit  7 = 0 E23
	// bit  6 = 0 E22
	// bit  5 = 0 E21
	// bit  4 = 0 E20
	// bit  3 = 0 E19
	// bit  2 = 0 E18
	// bit  1 = 0 E17
	// bit  0 = 0 E16
	// *(uint16_t __far *)((uint32_t) 0xa6) = 0X8600;
	//------------------------------------------------------------------------------
	

#ifdef EMULATOR_ON
	// Hardware Version detect and setup
	PORT_HW7_DETECT = AS_INPUT;

	bbad_hw_version = (HW7_DETECT) ? HW_V7 : HW_V6;

	// ------------------------------- I/O PORT CFG ------------------------------------------------
	// MT011112 PULL-UP DISABLED
	PUCR0 = 0x00;		
	PUCR1 = 0x00;
	
	// port 0: bus ad0-ad7
	// port 1: bus ad8-ad15
	// port 2: bus a16-a23

	// port 3: strobe bus signal
	DDR3 = 0xEF; 	//  
								// .7= 1 CLK OUTPUT 
								// .6= 1 CMD_B
								// .5= 1 CMD_A
								// .4= 0 READYCF
								// .3= 1 -WRHX 
								// .2= 1 -WRLX 
								// .1= 1 -RD 
								// .0= 1 ALE
	// default value								
	PDR3 = 0X00;

	// port 4:
  	// init external interrupt2 
  	DDR4 = 0xE1; 
								// .7= 1 RESUART
								// .6= 1 EN_485								
								// .5= 1 S1_TX
								// .4= 0 INP SCK_EXT
								// .3= 0 S1_RX
								// .2= 0 S0_RX
								// .1= 0 INP SCK_EXT
								// .0= 1 S0_TX
								
	// default value
	PDR4 = 0XC0;
	
	// add
	PORT_MUX_CK_P = 1;					// output
	PORT_MUX_D_P = 0;					// input						


	// port 5:
	if (bbad_hw_version == HW_V6)
	{
		//  modify
  		DDR5 |= 0xC1; 
								// .7= 1 GBL_CLR_CPL
								// .6= 1 MUX_CK_P
								// .5= 1 MUX_D_P
								// .4= 0 INT7
								// .3= 0 INT6
								// .2= 0 INT5
								// .1= 0 INT4
								// .0= 1 MUX_RST

		// add
		MUX_D_P = 0;
		MUX_CK_P = 1;

		//  add
		// default value
		PDR5 |= 0X00;
	}
	else
	{
		// this section if for HW7
  		DDR5 = 0xE1; 
									// .7= 1 GBL_CLR_CPL
									// .6= 1 DRV_K_L_AMICO	(0=enabled; 1=disabled)
									// .5= 1 DRV_K_SP_ECU	(0=enabled; 1=disabled)
									// .4= 0 INT7
									// .3= 0 INT6
									// .2= 0 INT5
									// .1= 0 INT4
									// .0= 1 MUX_ENABLE		(0=enabled;	1=disabled)
									
		// default value
		PDR5 = 0X61;				// at bootstrap, mux and kl special function must be disabled
	}

    
	// port 6: 
	DDR6 = 0xF0;
								// .7= 1 CMD_E
								// .6= 1 CMD_F
								// .5= 1 CAN_STBY
								// .4= 1 CAN_SLOPE								
								// .3= 0 OBD AN
								// .2= 0 -CD2
								// .1= 0 -CD1
								// .0= 0 VBE_CHK

	// default value
	//PDR6 = 0X20;
	PDR6 = 0X30;				// CAN disabled

	
	
	ADER = 0x00;  // To use pin like IN/OUT = 0, to use like ANALOG IN = 1
	
	// port 7
	DDR7 = 0xFF;
								// .7= 1 CMD_C
								// .6= 1 CMD_D
								// .5= 1 -RST_CARD
								// .4= 1 TCK
								// .3= 1 TDI
								// .2= 1 TDO
								// .1= 1 TMS
								// .0= 1 TP7

	// default value
	PDR7 = 0X00;

	// port8 
	// port8 
	if (bbad_hw_version == HW_V6)
	{
		DDR8 = 0xFF;
								// .7= 1 LED_BICOLOR
								// .6= 1 LED_BICOLOR
								// .5= 1 STEP_DOWN_DISABLE
								// .4= 1 STEP_UP_DISABLE
								// .3= 1 MUX_EN_485
								// .2= 1 MUX_EN_CAN
								// .1= 1 MUX_EN_J1850
								// .0= 1 MUX_EN_KL
		// default value
		//PDR8 = 0X00;
		PDR8 |= 0X00;
	}
	else
	{
		// this section if for HW7
		DDR8 = 0xEF;
									// .7= 1 LED_BICOLOR
									// .6= 1 LED_BICOLOR
									// .5= 1 STEP_DOWN_DISABLE
									// .4= 0 HW7_DETECT
									// .3= 1 R_2R_D			(LSB)
									// .2= 1 R_2R_C
									// .1= 1 R_2R_B
									// .0= 1 R_2R_A			(MSB)
		// default value
		PDR8 = 0X0C;
	//PDR8 = 0X08;
	}
								
	// port9
	// port9
	if (bbad_hw_version == HW_V6)
	{
		DDR9 = 0xD8;
								// .7= 1 -AT_RST
								// .6= 1 USB_SUSPEND
								// .5= 0 CAN_RX
								// .4= 1 CAN_TX
								// .3= 1 TP8
								// .2= 0 INTUSB
								// .1= 0 INT2UART
								// .0= 0 INT1UART
									
		// default value
		PDR9 = 0X00;						
	}
	else
	{
		// this section if for HW7
		DDR9 = 0xD8;
									// .7= 1 COM_VOLT_SELECT  (0=24V; 1=12V)
									// .6= 1 USB_SUSPEND
									// .5= 0 CAN_RX
									// .4= 1 CAN_TX
									// .3= 1 TP8
									// .2= 0 INTUSB
									// .1= 0 INT2UART
									// .0= 0 INT1UART
										
		// default value
		PDR9 = 0X80;						
	}
							
	// Set port A (only 1 pin) like OUT for debug LED
	DDRA = 0x01;
#else
	//EMULATOR_ON disabled

#endif	


	__set_il(7);                // allow all levels
	__EI();                     // globaly enable interrupts

} // end HwInit procedure


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is for bicolor LED management.
// F/P CALLING:   ObdSystem (main.c)
// F/P CALLED:
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void Bicolor_led_manager(void)
{
	switch((BYTE)(SisStatus & 0x000000FFL))
   	{
      case 0:
      	LED_BICOLOR_RED = 0;
         LED_BICOLOR_GREEN = 0;
      break;

      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      		if(LED_BICOLOR_RED)
            	{
               LED_BICOLOR_RED = 0;
               LED_BICOLOR_GREEN = 1;
               }
            else
               {
            	LED_BICOLOR_RED = 1;
               LED_BICOLOR_GREEN = 0;
               }
      break;

      case 6:
      	LED_BICOLOR_RED = 0;
         LED_BICOLOR_GREEN = 1;
      break;

      default:
      	LED_BICOLOR_RED = 1;
         LED_BICOLOR_GREEN = 0;
      break;
      } // fine switch
}

