#include "stdint.h"
//------------------------------------------------------------------------------
// HEADING

// PROJECT NAME:     Sis_NNN.prj/Sis_RAM_NNN.prj
// PROJECT RELEASE:  VIEW HEADING OF "sistema.c"
// FILE NAME:        sistema.h
// PROJECT RELEASE:  VIEW HEADING OF "sistema.c"
// DATE:             February 2004
// FILE DESCRIPTION: This file is used to generate code for Emulator, Bootloader
//                   or RAM.
//                   In this file are also definited "Parameters/StatusActive Tests"
//                   Active Tests"(and their position in Tester) and comunication 
//                   phases.
// REVIEW  BY:       Ing. Andrea Acunzo - Ing. Diego Mainardi
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// FURTHER INFORMATIONS
// To build this code for EMULATOR
// ============================
// 0) Disable the "int16_t Result" in "main.c"
// 1) Enable the "#define EMULATOR_ON" directive in this file
// 2) Disable the "#define BOOTLOADER_ON" directive in this file
// 3) Disable the "#define MUX_ON" directive in this file
// 4) Use the "Sis_NNN.prj" instead of the "Sis_RAM_NNN.prj"
// 5) In the "Start.asm", section 4.9, file modify as follows:
//					#set      RESET_VECTOR   ON        ; <<< enable reset vector
//				 ;#set      RESET_VECTOR   OFF        ; <<< disable reset vector
//
// To build this code for BOOTLOADER
// ============================
// 0) Enable the "int16_t Result" in "main.c"
// 1) Enable the "#define EMULATOR_ON" directive in this file
// 2) Enable the "#define BOOTLOADER_ON" directive in this file
// 3) Disable the "#define MUX_ON" directive in this file
//		to test System on BBAD and "Visual PC" without connecting MUX
//		(enable "#define MUX_ON" to test with connecting MUX)
// 4) Use the "Sis_NNN.prj" instead of the Sis_RAM_NNN.prj
// 5) In the "Start.asm", section 4.9, file modify as follows:
//				 ;#set      RESET_VECTOR   ON        ; <<< enable reset vector
//					#set      RESET_VECTOR   OFF        ; <<< disable reset vector
//




//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------


// To build this code for RAM
// =============================
// 0) Disable the "int16_t Result" in "main.c"
// 1) Disable the "#define EMULATOR_ON" directive in this file with //
// 2) Disable the "#define BOOTLOADER_ON" directive in this file
// 3) Disable the "#define MUX_ON" directive in this file
// 4) Disable the "#define ACCEMIC_ON" directive in "main.c"
// 5) Do not include monitor.h nor MONITOR16LX.ASM
// 6) Use the "Sis_RAM_NNN.prj" instead of the "Sis_NNN.prj"


// To build this code for ACCEMIC MDE DEBUGGER
// =============================
// 0) Disable the "int16_t Result" in "main.c"
// 1) Enable the "#define EMULATOR_ON" directive in this file with //
// 2) Disable the "#define BOOTLOADER_ON" directive in this file
// 3) Enable the "#define ACCEMIC_ON" directive in "main.c"
// 4) Disable the "#define MUX_ON" directive in this file
// 5) Include monitor.h and MONITOR16LX.ASM
// 6) Use the "Sis_NNN.prj" 
// 7) REMEMBER TO USE L LINE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------






//------------------------------------------------------------------------------
// COMPILER DIRECTIVE

#ifndef SISTEMA_H            // To include this Header once and
#define SISTEMA_H            // avoiding extra compilation

//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// CODE

//#define EMULATOR_ON
//#define BOOTLOADER_ON
//#define MUX_ON

//-------------------------------------------------------
// Abilitare la define ACCEMIC_ON per l'uso col debugger ACCEMIC MDE
//#define ACCEMIC_ON

//-------------------------------------------------------

//------------------------------------------------------------------------------

#include "monitor.h"
//#include "monitor16lx.asm"
#include "typedefs.h"
#include "pid.h"



//------------------------------------------------------------------------------
// SYSTEM FEATURES
#define TOTALEPARAMETRI 		2
#define TOTALEATTIVAZIONI 		3
#define TOTALESTATI				(11 + 1) 	// Add 1 to Number of Status
#define POSSIBILISTATI			 8			// Don't add anything to Status Values
#define TOTALEINFO				 6			// Don't add anything to Informations
#define NUMINFOBYTE				 20			// THIS VALUE MUST BE ALWAYS 20 FOR DISPLAYER COMPATIBILITY
#define NUM_DOMANDE_INFO		 1			// Don't add anything to Number of Informations Questions
#define TOT_DOMANDE				 5			// Don't add anything to Number of Other Questions (Tester present, Parameters, Status, Error Reading)
#define TOTERRORI 				20			// THIS VALUE MUST BE ALWAYS 20 FOR DISPLAYER COMPATIBILITY

//------------------------------------------------------------------------------
// PARAMETER POSITIONS
#define P_Controllo_Intervento	1
// The numbers are the Parameters positions in Tester. The 1st position is 1.
// The MAX number displayed by Tester in one shot is 14.
//------------------------------------------------------------------------------
// "STATUS" POSITIONS


// The numbers are the Status positions in Tester. The 1st position is 1.
// The MAX number displayed by Tester in one shot is 6.

#define S_Stato_della_Scatola					1
#define S_Commutatore_Neutralizzazione			9
#define S_Cinture_Pirotecniche_A				8
//Per 206 #define S_Cinture_Pirotecniche_P				4
#define S_Airbag_Laterali_Anteriori				7
//Per 206 #define S_Tendine_Airbag_Laterali				6
#define S_Copertura_Airbag_Laterali				4
#define S_Airbag_Guida							5
#define S_Airbag_Passeggero						6
#define S_Satelliti							   11
#define S_Controllo_Assistenza				   10
#define S_Controllo_Officina                   2 							
#define S_Controllo_Fornitore				   3




//------------------------------------------------------------------------------
// "STATUS VALUES" POSITIONS

// The numbers are the Status Values. The 1st position is 1.
// In theese set the numbers doesnt indicate the positions (but only the index)
// because the status values could change during the diagnosis.
// The 1st index must be 0

#define NON_EFFETTUATO 		0
#define ESEGUITO			1
#define NO					2
#define SI					3
#define Sbloccato			4
#define Bloccato			5
#define OFF					6
#define No_Defin			7



//------------------------------------------------------------------------------
// "INFORMATIONS" POSITIONS

// The numbers are the Informations positions in Tester. The 1st position is 0.
// The MAX number displayed by Tester in one shot is 1.

#define I_FORNITORE									0
#define I_VERSIONE_SOFTWARE							1
#define I_RIFERIMENTO_PSA							2
#define I_VERSIONE_CALIBRAZIONE						3
#define I_VERSIONE_DIAGNOSTICA						4
#define I_NUMERO_PIANO_FUNZIONALE					5
/*
#define I_RIFERIMENTO_PSA_SATELLITI					5
#define I_FORNITORE_SATELLITI						6
#define I_VERSIONE_CALIBRATURA_SATELLITI			7
#define I_VERSIONE_PROGRAMMA_SATELLITI				8
#define I_VERSIONE_MATERIALI_SATELLITI				9
*/


//------------------------------------------------------------------------------
// "ACTIVE TESTS" POSITIONS

// The numbers are the Active Tests positions in Tester. The 1st position is 0 and
// must be "ERRORS DELETE".
// The MAX number displayed by Tester in one shot is 10.
#define ATT_CANCELLA_ERRORI		0
#define ATT_BLOCCAGGIO			1
#define	ATT_SBLOCCAGGIO			2


//------------------------------------------------------------------------------
// COMUNICATION PHASES

#define ATTIVA_SLOW				10	// Slow-activation of ECU
#define WAIT_ISO				20	// Wait ISO code
#define ATTIVA_FAST     		30	// Fast-activation of ECU
#define RICHIESTA_FAST			40	// Sending of start comunicazione frame in Fast activation mode
#define RICHIEDI_INFO1			50	// Information 1 request
#define RICHIEDI_INFO2			60	// Information 1 request
#define NORMALE					70	// Tester Present
#define PARAMETRI_STATI			80	// Parameter/Status request
#define RICHIEDI_ERRORI			90	// Error request
#define RICHIEDI_ERRORI_1		91	// Error request
#define START_CANC_ERRORI		100	// Start of error deleting
#define RUN_CANC_ERRORI			110	// Error deleting running
#define END_CANC_ERRORI			120	// End of error deleting
#define START_ATTIVAZIONE		130	// Start of active-test
#define RUN_ATTIVAZIONE			140	// Active-test running
#define END_ATTIVAZIONE			150	// End of Active-test
#define FINE_COMUNICAZIONE_1	160	// Fine comunicazione
#define FINE_COMUNICAZIONE_2	165	// Fine comunicazione
#define ATTESA_TASTO_1			170 // Waiting key-pressing
#define ATTESA					180 // Waiting phase
#define ATTESA_TASTO_2			190 // Waiting key-pressing
#define RIATTIVA				200	// New activation of ECU
#define FINE_COMUNICAZIONE		201
#define VUOTA					210 // AVAILABLE
#define NO_INS_STORICO 			220	// No new history inserting during error deleting
#define INS_STORICO 			230	// New history inserting during error deleting


//------------------------------------------------------------------------------
// POSSIBLE PHASES IN ACTIVE-TEST
#define INIZIO		10
#define IN_CORSO	20
#define FINE		30

//#define ATT_CANC_ERRORI 0

//------------------------------------------------------------------------------
// POSSIBLE VALUES RETURNED BY "RxAnswer" FUNCTION
#define REQ_NOT_SUPPORTED		50
#define NESSUNA_CENTRALINA		60
#define RIPROVA_ATTIVAZIONE		70
#define NUOVA_DOMANDA			80
#define ERRORE_SCONOSCIUTO		90


//------------------------------------------------------------------------------
// WAITING TIME FOR NEW REQUEST
#define NO_WAIT			0
#define WAIT_TIME_1		12
#define WAIT_TIME_2		150
#define WAIT_TIME_3		230
#define WAIT_TIME_4		3000
#define WAIT_TIME_5		12000


//------------------------------------------------------------------------------
#define LUNGH_BUFFER_TX		 	29	// TX-Buffer lenght (the value is the same of the longest request + 1)


// Key received from Visualizator
#define TASTO_F1	1
#define TASTO_F2	2
#define TASTO_F9	9	
#define KLINE		1  // Selecttion of the comunication line
#define LLINE		0
#define CODICE_CENTRALINA		0x10	// ECU address (read by oscilloscope)


//------------------------------------------------------------------------------
// SHAPING/SELECTION OF BITS
#define	BIT0					0x01
#define	BIT1					0x02
#define	BIT2					0x04
#define	BIT3					0x08
#define	BIT4					0x10
#define	BIT5					0x20
#define	BIT6					0x40
#define	BIT7					0x80
#define BIT4_5					0x30
#define BIT2_3					0x0c
#define BIT0_1					0x03
#define NIBBLE_ALTO				0xf0


// ------------------------------------------------------------------------
// FUNCTION PROTOTYPES

extern __far void InitVariante(void);
extern __far void InitIndexAtt (void);
extern __far void InitInfo (void);
extern __far void InitStati (void);
extern __far void InitParam (void);
extern __far void InitAtt(void);

 extern __far void InterpretaInfo (void);
 extern void DisabilitaSingoloSnap(int16_t);
 extern __far void InterpretaParametriStati (void);
 extern __far void Azzera_errori (void);
 extern uint8_t DisponiErrori(void);
 extern __far void InterpretaErrori(void);
 extern __far void CancErrori(void);
 extern __far void InterpretaAttivazione(void);
 extern __far uint8_t GestioneErroreTX(uint8_t,BOOL);
 extern __far uint8_t GestioneErroreRX(uint8_t,BOOL);
 extern __far uint8_t Attiva_Fast(BOOL);
 extern int16_t Send5Baud (uint8_t, BOOL);
 extern int16_t Wait_iso (uint8_t, BOOL);
 extern __far uint8_t AttivaEcu(BOOL);
 extern __far void Riattiva(void);
 extern uint8_t ComponiDomanda (int16_t,int16_t,uint8_t);
 extern uint16_t SequenzaDomande (BOOL);
 extern __far uint8_t Tx_Request(uint8_t,uint16_t, BOOL);
 extern uint8_t RispostaOk (uint8_t, uint8_t);
 extern __far uint8_t RxAnswer(uint8_t, BOOL);
 extern void InterpretaRisposta(void);
 extern __near uint8_t SystemManager(BOOL);


//------------------------------------------------------------------------------
// Variables declarations

extern float release_sw;		// Release SW

extern uint8_t param_abilitati[(TOTALEPARAMETRI / 8) + 1];  // Parameter enabled
extern uint8_t stati_abilitati[(TOTALESTATI / 8) + 1];      // Status enabled
extern l_word abilita_pid[TOT_DOMANDE];

extern uint32_t variante;
extern int16_t tot_parametri;
extern int16_t tot_stati;
extern int16_t tot_attivazioni;
extern int16_t tot_domande;
extern int16_t variante_ok;


// Array dimensions

extern uint8_t setInfo[TOTALEINFO][NUMINFOBYTE]; // Informations

extern float setParametri[TOTALEPARAMETRI];    // Parameters
 
extern uint32_t setStati[TOTALESTATI];           // Status

extern uint8_t bufferErrori[TOTERRORI*4];       // Stored Errors (4 bytes for every errors)
extern uint8_t bufErrAttivi[TOTERRORI*4];       // Active Errors (4 bytes for every errors)

extern uint32_t elencParam[TOTALEPARAMETRI];     // Parameters list
extern uint32_t umParam[TOTALEPARAMETRI];		    // Measure Unit list
extern uint32_t PrecParam[TOTALEPARAMETRI];
extern uint32_t HelpParam[TOTALEPARAMETRI];

extern uint32_t elencStati[TOTALESTATI];         // Status list
extern uint32_t possStati[POSSIBILISTATI];	      // Status Value list
extern uint32_t HelpStati[TOTALESTATI];

extern uint32_t elencInfo[TOTALEINFO];

extern uint32_t setHelpAttivazioni[TOTALEATTIVAZIONI]; // Active Test list
extern uint32_t elenc_attiv[TOTALEATTIVAZIONI];


//-----------------------------------------------------------------
extern uint8_t pid_richiesti[((TOT_DOMANDE) / 8) + 1]; // Request PID
extern uint8_t pid_abilitati[((TOT_DOMANDE) / 8) + 1]; // Enabled PID
extern uint16_t new_par;

extern int16_t fase_comunicazione;	// Phase of comunication
extern int16_t fase_attivazione;		// Phase of active-test
extern int16_t NumStorico;					// Number of stored historic

extern uint8_t buffer_Tx[LUNGH_BUFFER_TX];	// TX-Buffer for BBAD-Visualizator comunication

	// Vector of requests
extern uint8_t domanda[TOT_DOMANDE];
extern uint8_t domanda_att[TOTALEATTIVAZIONI];

extern int16_t pid_attivo;			// Active PID
extern uint8_t len_tx;				// frame length

extern uint16_t BlinkTime;		// LED blinking time
extern uint16_t BTime;				// Time-out management variables
extern uint16_t lTout;
extern uint16_t ltime;				// Message time-out
extern uint16_t Wait_Time;   // Waiting time for a new request

extern uint8_t conta_att;		// Number of active error
extern uint8_t conta_mem;		// Number of stored error
//------------------------------------------------------------------------------
#endif                                 // End "ifndef" including this Header once
