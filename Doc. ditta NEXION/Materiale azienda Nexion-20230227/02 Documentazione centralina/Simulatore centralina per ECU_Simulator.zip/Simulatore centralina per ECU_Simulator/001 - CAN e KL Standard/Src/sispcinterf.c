#include "stdint.h"
////////////////////////////////////////////////////////
// 			Interfaccia con PC per Sistemi			  //
//             01/03/02 "Sti Ciccioli"		  		  //
////////////////////////////////////////////////////////

#define SYSPCINTERF_C

#include "typedefs.h"
#include "sispcinterf.h"
#include "serial.h"
#include "sistema.h"




#pragma  section DATA=EXTRAMDATA, attr=DATA
#pragma  section FAR_DATA=EXTRAMDATA, attr=DATA

//Variabili globali per l'interfaccia PC
// Array per definire i parametri
uint32_t elencParam[TOTALEPARAMETRI]; // Elenco dei parametri
uint32_t umParam[TOTALEPARAMETRI];		 // Elenco unit� di misura
uint32_t PrecParam[TOTALEPARAMETRI];	 // Verificare normativa
uint32_t HelpParam[TOTALEPARAMETRI];


// Array per definire gli stati
uint32_t elencStati[TOTALESTATI];      // Elenco stati
uint32_t possStati[POSSIBILISTATI];	// Possibili stati
uint32_t HelpStati[TOTALESTATI];


// Array per definire le info
uint32_t elencInfo[TOTALEINFO];	//

// attivazioni
uint32_t setHelpAttivazioni[TOTALEATTIVAZIONI];
uint32_t elenc_attiv[TOTALEATTIVAZIONI];


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//						 FUNZIONI PER LA GESTIONE DEI BYTE RICEVUTI O INVIATI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
// gets a uint8_t from rx buffer and includes it in checksum calculation
__far uint8_t Get_and_ck(uint8_t _com)
{
	uint8_t car = GetByte(_com);
	com_struct_ptr[_com]->calc_ck += (uint32_t)car;
	return car;
}

//----------------------------------------------------------------------------------------------
// puts a uint8_t from rx buffer and includes it in checksum calculation
__far void Put_and_ck(uint8_t _com, uint8_t car)
{
	com_struct_ptr[_com]->tx_calc_ck += (uint32_t)car;
	PutByte(_com, car);
}

//----------------------------------------------------------------------------------------------
// Converte il valore del byte in un carattere
uint8_t ConvertiCar(BYTE car)
{
	if (( car >= 0) && (car <= 9))
   	car += 0x30;			// Se il byte passato � un numero, devo aggiungere 0x30,
  else								// aggiungendo lo 0x41 trasformo la lettera minuscola che mi � stata
   	car += (0x41-10);	// passata in una lettera maiuscola
return car;
}


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//						 CHIUSURA FUNZIONI PER LA GESTIONE DEI BYTE RICEVUTI O INVIATI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------





//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//								 FUNZIONI PER LA GESTIONE DELLE ATTIVAZIONI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------



// Riempie la finestra che contiene i messaggi da visualizzare, i messaggi sono diversi
// a seconda del service abilitato in quel momento
__far void RiempiFinestra(uint32_t tipo_fin, uint32_t tipo_mess, uint32_t id1, uint32_t id2, uint32_t id3, uint32_t id4)
{
	pacchetto_finestra.tipo_finestra = tipo_fin;
	pacchetto_finestra.tipo_messaggio = tipo_mess;
	pacchetto_finestra.id1 = id1;
	pacchetto_finestra.id2 = id2;
	pacchetto_finestra.id3 = id3;
	pacchetto_finestra.id4 = id4;

}	// Chiusura void RiempiFinestra(void)



// Spedisce il messaggio da visualizzare
int16_t SendVisualizza(uint8_t _com,BOOL Reset)
{

	#define SEND_HEADER 		10
	#define SEND_DATA	 		20
	#define SEND_CHK	 		30

	static int16_t fase;			// fase automa

    static int16_t num_loop;
    int16_t lunghezza;

	static uint8_t *scan_ptr;
	per_com static *com_ptr;	// Puntatore alla struttura di rx/tx delle seriali

	lunghezza = 0;
	
	if (Reset)
		{
		fase = 0;
		return RUNNING;
		}

	switch(fase)
	{
		case IDLE:				// Costruisco il pacchetto da tx
		{
			com_ptr = &com[_com];	// com_ptr contiene il puntatore alla struttura com[_com]
			fase = SEND_HEADER;
		}break;

		case SEND_HEADER: // header
		{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				com_ptr->tx_calc_ck = 0;
				// header
				Put_and_ck(_com, '[');
				Put_and_ck(_com,com_ptr->source);
				Put_and_ck(_com, 0x20);
				Put_and_ck(_com,com_ptr->frame_id);
				fase++;
	  			}
		}break;

		case SEND_HEADER + 1: // header
      	{// header 4 + lunghezza 2 + function 1 + service 2 + 2 chk + 4 byte * 6 pacchetti
			lunghezza = 4 + 2 + 1 + 2 + 2 + 4 * 6;
			Put_and_ck(_com,lunghezza / 0x100);
			Put_and_ck(_com,lunghezza % 0x100);
			Put_and_ck(_com,(com_ptr->function + 0x40)); // function
			Put_and_ck(_com,com_ptr->service);
			Put_and_ck(_com,com_ptr->service_type);
			num_loop = 0;
			fase = SEND_DATA;
         }break;

		case SEND_DATA:   //	Prepara il pacchetto da spedire
      	{
			scan_ptr = (uint8_t *)(&pacchetto_finestra);
			fase++;
         }break;

		case SEND_DATA + 1:
        {
         if(!BytesInTxBuffer( _com) == TRUE) // Se il buffer � vuoto, spedisce altri valori
	      	{
	        if( num_loop == 0 )	// Questo if permette di invertire i byte inviati
				scan_ptr += 4;
	        else
	         	scan_ptr += 8;

			Put_and_ck(_com,*(--scan_ptr));	// Spedisco 4 byte alla volta
			Put_and_ck(_com,*(--scan_ptr));
  			Put_and_ck(_com,*(--scan_ptr));
  			Put_and_ck(_com,*(--scan_ptr));

			num_loop++;

			if (num_loop > 5)							// Spedisco	6 pacchetti da 4 byte per cui
				fase = SEND_CHK;					// dummy va da 0 a 5
	        }	// Chiusura if(!BytesInTxBuffer( _com))

		}break;  /* Break SEND_DATA */

		case SEND_CHK:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				scan_ptr = (uint8_t *)(&com[_com].tx_calc_ck); // ...volendo posso usare scan_ptr di 'com[_com]'
				*scan_ptr++;
				PutByte(_com, *scan_ptr--);
				PutByte(_com, *scan_ptr);
				fase = IDLE;
				}
			} break;


		default:
			break;

	}	// Chiusura switch(fase)


	if(fase==IDLE)
  		return ENDOK;						// lo stato ENDOK se ho concluso la tx
    else
		return RUNNING;					// lo stato RUNNING in tutti gli altri casi

}	// Chiusura int16_t SendVisualizza(uint8_t _com,BOOL Reset)



// Spedisce i dati per il service 'Attivazione'
int16_t SendAttivazione(uint8_t _com,BOOL Reset)
{
#define SEND_HEADER 		10
#define SEND_DATA	 		20
#define SEND_CHK	 		30
#define SEND_ERRORE			40


#define TOTALEVALORI		5			// I possibili per l'attivazione sono 5
static uint32_t BufferAppoggio[TOTALEVALORI];

static int16_t num_loop;						// variabile di appoggio
static int16_t lunghezza;					// Lunghezza totale frame
static uint8_t fase;						// Fase automa
static uint8_t errore;					// Contiene un eventuale errore

static uint8_t *scan_ptr; 				// Necessario per inviare ck alla fine
static uint32_t *l_long;
per_com static *com_ptr;	// Puntatore alla struttura di rx/tx delle seriali

static uint32_t dato_richiesto;
uint8_t conta;

	if (Reset)
		{
		fase = 0;
		errore = 0;
		dato_richiesto = 0;
		return RUNNING;
		}


	switch (fase)
	{
	case IDLE:
		{
		fase = SEND_HEADER;
		com_ptr = &com[_com];		// com_ptr contiene il puntatore alla struttura com[_com]
		lunghezza = 0;
		num_loop = 0;
		}break;

	case SEND_HEADER: // header
		{
		if(!BytesInTxBuffer( _com) == TRUE)
		  	{
			com_ptr->tx_calc_ck = 0;
			// header
			Put_and_ck(_com, '[');
			Put_and_ck(_com,com_ptr->source);
			Put_and_ck(_com, 0x20);
			Put_and_ck(_com,com_ptr->frame_id);
			fase++;
			}
			}break;

	case SEND_HEADER + 1:
		{
		if(!BytesInTxBuffer( _com) == TRUE)
		  	{
			switch(com_ptr->service_type)
				{
				
				case 'V':	//  valori attivazione 
					{
					lunghezza = 4 + 2 + 1 + 2 + 2 + (TOTALEVALORI) * 4;
					errore = AFFERMATIVE_RESPONSE;
					fase = SEND_DATA;	// Spedisce 4 byte alla volta
               }break;			// Chiusura case 'V'

				case '0':
					{// header 4 + lunghezza 2 + function 1 + service 2 + 4* TOTALEATTIVAZIONI +2 chk
					 // 5 sono le possibili attivazioni
					lunghezza = 4 + 2 + 1 + 2 + 2 + 4 * (tot_attivazioni); //  Da mettere a posto ????????????
					errore = AFFERMATIVE_RESPONSE;		
					fase = SEND_DATA;
					}break;		// Chiusura case '0'
				
				case 'H':  // help attivazione
            		{
					lunghezza = 4 + 2 + 1 + 2 + 4 + 2;
               		errore = TYPE_SERVICE_NOT_SUPPORTED;
					fase = SEND_ERRORE;
	               }break;		// Chiusura case 'H'

				case 'Q':		// Fornisce i dati necessari per l'attivazione
  				{// header 4 + lunghezza 2 + function 1 + service 2 + data 4 + 2 chk
				for (conta = 0; conta < 4; conta++)
					{
					dato_richiesto <<= 8;
					dato_richiesto += com_ptr ->rx_buf[com_ptr->data_ptr++];

					// ricircolo del buffer
					if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
						com_ptr->data_ptr = 0;
					
					}

				valore_impostato = dato_richiesto;
				lunghezza = 4 + 2 + 1 + 2 + 2;
				errore = AFFERMATIVE_RESPONSE;
				fase = SEND_CHK;
				}break;


				case 'X':		// Richiesta attivazione service
  				{// header 4 + lunghezza 2 + function 1 + service 2 + data 4 + 2 chk
				// prelevo il dato richiesto
				stato_attivazione = 0x00;
				// In questo modo non faccio visualizzare niente a video
				RiempiFinestra(0x0000ffff,0x0000ffff,0x0000ffff,0x0000ffff,0x0000ffff,0x0000ffff);

				for (conta = 0; conta < 4; conta++)
					{
					dato_richiesto <<= 8;
					dato_richiesto += com_ptr ->rx_buf[com_ptr->data_ptr++];

					// ricircolo del buffer
					if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
						com_ptr->data_ptr = 0;	
					}
				
				if (dato_richiesto < tot_attivazioni)
					{
					lunghezza = 4 + 2 + 1 + 2 + 2;
					attivazione_richiesta = dato_richiesto + 1;
					errore = AFFERMATIVE_RESPONSE;
					fase = SEND_CHK;
					}
				else
					{
					lunghezza = 4 + 2 + 1 + 2 + 4 + 2;
					errore = DATA_NOT_SUPPORTED;
		            fase = SEND_ERRORE;
					}
				}break;		// Chiusura case 'X'

				case 'S':	//	Richiesta stato attivazione
            	{
				for (conta = 0; conta < 4; conta++)
					{
					dato_richiesto <<= 8;
					dato_richiesto += com_ptr ->rx_buf[com_ptr->data_ptr++];

					// ricircolo del buffer
					if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
						com_ptr->data_ptr = 0;
					
					}

				if(dato_richiesto == 0x00)	// Richiesta di stato attivazione
					{
					lunghezza = 4 + 2 + 1 + 2 + 2 + 4;			// Il + 4 finale � per i dati
					errore = AFFERMATIVE_RESPONSE;
					fase = SEND_ERRORE;
					}
			   else if(dato_richiesto == 0x80) 		// Richiesta di stop attivazione
               		{
					lunghezza = 4 + 2 + 1 + 2 + 2;				// Pongo a zero il service prima
					errore = AFFERMATIVE_RESPONSE;
					fase = SEND_CHK;
					stato_attivazione = 0x80;
					attivazione_richiesta = 0;
					}
				else
					{
					lunghezza = 4 + 2 + 1 + 2 + 2;
					errore = TYPE_SERVICE_NOT_SUPPORTED;
					fase = SEND_ERRORE;
					}
				}break;	//	Chiusura fase case 'S'

				default:		// Tipo_servizio non riconosciuto
					{// header 4 + lunghezza 2 + function 1 + service 2 + numero errore 4 +chk 2
					// Se non si � riconosciuto il tipo servizio
					lunghezza = 4 + 2 + 1 + 2 + 2 + 4;
					errore = TYPE_SERVICE_NOT_SUPPORTED;
					fase = SEND_ERRORE;
					}
				
				}//switch(com[_com].tipo_servizio)

				Put_and_ck(_com,lunghezza / 0x100);
				Put_and_ck(_com,lunghezza % 0x100);
				Put_and_ck(_com,(com_ptr->function + 0x40));		// function
				if (errore == 0)					// Se ho riscontrato degli errori, lo segnalo
 					Put_and_ck(_com,com_ptr->service);
  			 	else
					Put_and_ck(_com,0x7f);
				Put_and_ck(_com,com_ptr->service_type);
				num_loop = 0;
			} // Chiusura if(!BytesInTxBuffer( _com) == TRUE)
			}break;		// case SEND_HEADER + 1

		case SEND_ERRORE: // Spedisce 4 byte sulla seriale
			{
			if(!BytesInTxBuffer( _com) == TRUE)
		      	{
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);	
				if(com_ptr->service_type == 'S')	// Se ho richiesto lo stato dell'attivazione
					{
					Put_and_ck(_com,stato_attivazione);
					}	
				else					
					Put_and_ck(_com,(uint8_t) errore);
				fase = SEND_CHK;
				}
			}break;		// case SEND_ERRORE

		case SEND_DATA + 1: // Spedisce solo 4 byte di dati
			{
			if(!BytesInTxBuffer( _com) == TRUE)
		      	{
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));

				fase = SEND_CHK;
				}
			}break;		// case SEND_DATA + 1


		case SEND_DATA: // Spedisce dei dati con quartine alla volta
			{
			if (num_loop == 0)
				{
				switch(com_ptr->service_type)
					{
				
					case 'V':
						{
						l_long = BufferAppoggio;
						// Composizione frame da spedire, con le risposte
						*l_long++ = (uint32_t)attivazione_richiesta;
						*l_long++ = (uint32_t)att_umis;
						*l_long++ =  *((uint32_t *)&att_value);
						*l_long++ = *((uint32_t *)&att_min);
						*l_long =  *((uint32_t *)&att_max);
						scan_ptr = (uint8_t *)BufferAppoggio;
						}break;
					
					case '0':	//	Spedisce l'elenco delle attivazioni
						{
						scan_ptr = (uint8_t *)elenc_attiv;
						}break;

					} //switch(com[_com].tipo_servizio)
				}  // if (dummy == 0)


		// Controlla che il buffer in trasmissione sia vuoto
		if(!BytesInTxBuffer( _com) == TRUE)	// Se il buffer � vuoto, spedisce altri valori
      		{
			if( num_loop == 0 )		// Questo if permette di invertire i byte inviati
				scan_ptr += 4;
			else
         		scan_ptr += 8;

			Put_and_ck(_com,*(--scan_ptr));	// Spedisco 4 byte alla volta
			Put_and_ck(_com,*(--scan_ptr));
  			Put_and_ck(_com,*(--scan_ptr));
  			Put_and_ck(_com,*(--scan_ptr));

			num_loop++;

			if(com_ptr->service_type != '0')
				{
				if (num_loop > (TOTALEVALORI - 1))
					fase = SEND_CHK;
				}
			else
         		{
				if (num_loop > (tot_attivazioni - 1))	
					fase = SEND_CHK;
				}
			}	/* Chiusura if(!BytesInTxBuffer( _com))	*/

			} break;  /* Break SEND_DATA */


		case SEND_CHK:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				scan_ptr = (uint8_t *)(&com[_com].tx_calc_ck); // ...volendo posso usare scan_ptr di 'com[_com]'
				*scan_ptr++;
				PutByte(_com, *scan_ptr--);
				PutByte(_com, *scan_ptr);
				fase++;
				}
			}break;

		case SEND_CHK + 1:
			{
			fase = IDLE;
			}break;

		default:
			fase = IDLE;
	}

	if(fase==IDLE)
  		return ENDOK;					// lo stato ENDOK se ho concluso la tx
    else
		return RUNNING;					// lo stato RUNNING in tutti gli altri casi
}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//						 CHIUSURA FUNZIONI PER LA GESTIONE DELLE ATTIVAZIONI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//								 FUNZIONI PER LA GESTIONE DELLE INFO
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------




// Gestisce il pacchetto da spedire per le info
int16_t SendInfo(uint8_t _com, BOOL Reset)
{
#define SEND_HEADER 		10
#define SEND_DATA	 		20
#define SEND_CHK	 		30
#define SEND_ERRORE			40

static int16_t dummy;		// Variabile di appoggio
static uint8_t fase;		// Fase della tx
static uint8_t errore;	// Contiene un eventuale errore di tx

static uint32_t dato_richiesto;	// Queste variabili permettono la ricostruzione del dato
uint8_t conta;					// inviato dal visualizzatore


per_com static *com_ptr;	// Puntatore alla struttura di rx/tx delle seriali
static uint8_t *scan_ptr;		// Necessario per inviare ck alla fine



	if (Reset)
		{
		fase = 0;
		errore = 0;
		dato_richiesto = 0;
		return RUNNING;
		}


	switch (fase)
	{
		case IDLE:
			{
			fase = SEND_HEADER;
			com_ptr = &com[_com];
			}break;

		case SEND_HEADER: // header
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				com_ptr->tx_calc_ck = 0;
				// header
				Put_and_ck(_com, '[');
				Put_and_ck(_com,com_ptr->source);
				Put_and_ck(_com, 0x20);
				Put_and_ck(_com,com_ptr->frame_id);
				fase++;
				}
			}break;

		case SEND_HEADER + 1: // lenght
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				switch(com_ptr->service_type)
					{
					case '0':
						{// header 4 + lunghezza 2 + function 1 + service 2 + data TOTALEINFO * 4 + 2 chk
						dummy = 4 + 2 + 1 + 2 + (TOTALEINFO) * 4 + 2;
						errore = AFFERMATIVE_RESPONSE;
						fase = SEND_DATA;
						}break;

					case 'X':
						{// header 4 + lunghezza 2 + function 1 + service 2 + data 4 + 2 chk
						for (conta = 0; conta < 4; conta++)
							{
							dato_richiesto <<= 8;
							dato_richiesto += com_ptr ->rx_buf[com_ptr->data_ptr++];

							// ricircolo del buffer
							if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
								com_ptr->data_ptr = 0;
								
							}

						if(dato_richiesto <= (TOTALEINFO))
               				{
							dummy = 4 + 2 + 1 + 2 + 2 + (NUMINFOBYTE);
							errore = AFFERMATIVE_RESPONSE;
							fase = SEND_DATA + 1;
							}
						else
               				{
							dummy = 4 + 2 + 1 + 2 + 2 + 4;
							errore = DATA_NOT_SUPPORTED;
							fase = SEND_ERRORE;
							}
						}break;

					case 'H':
            			{
						dummy = 4 + 2 + 1 + 2 + 4 + 2;
               			errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
						}break;

					default:
						{// header 4 + lunghezza 2 + function 1 + service 2 + chk 2
						dummy = 4 + 2 + 1 + 2 + 2 + 4;
						errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
  						}
					}//switch(com[_com].tipo_servizio)
				
				Put_and_ck(_com,dummy / 0x100);
				Put_and_ck(_com,dummy % 0x100);
				Put_and_ck(_com,(com_ptr->function + 0x40)); // function

				if(errore == 0)
					Put_and_ck(_com,com_ptr->service);
				else
					Put_and_ck(_com,0x7f);

				Put_and_ck(_com,com_ptr->service_type);
				dummy = 0;
			} // Chiusura if(!BytesInTxBuffer( _com) == TRUE)
			} break;


		case SEND_ERRORE: // data per errori
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,errore);

				fase = SEND_CHK;
				}
			} break;


		case SEND_DATA: // data
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				if (dummy == 0)
					{
					switch(com_ptr->service_type)
						{
						case '0':
               			{
						scan_ptr = (uint8_t *)elencInfo;
						}break;

					default:
						break;
						} //switch(com[_com].tipo_servizio)
					} // Chiusura if(dummy == 0)

				if( dummy == 0 )	// Questo if permette di invertire i byte inviati
         			scan_ptr += 4;
				else
         			scan_ptr += 8;

				Put_and_ck(_com,*(--scan_ptr));	// Spedisco 4 byte alla volta
				Put_and_ck(_com,*(--scan_ptr));
  				Put_and_ck(_com,*(--scan_ptr));
  				Put_and_ck(_com,*(--scan_ptr));

				dummy++;

				if (dummy>(TOTALEINFO-1))		// Da mettere a posto
					fase = SEND_CHK;
				} // Chiusura if(!BytesInTxBuffer( _com) == TRUE)
			}break;

		case SEND_DATA + 1: // Dato singolo, � su 20 byte  
			{
			if ( dummy == 0 )
				{
				scan_ptr = (uint8_t *)setInfo;
				scan_ptr += (dato_richiesto) * NUMINFOBYTE;		// Punta al dato singolo
				}

			if(!BytesInTxBuffer( _com) == TRUE) // Se il buffer � vuoto, spedisce altri valori
	      		{
				Put_and_ck(_com,*scan_ptr++);
				Put_and_ck(_com,*scan_ptr++);
				Put_and_ck(_com,*scan_ptr++);
				Put_and_ck(_com,*scan_ptr++);

				dummy++;

				if(dummy > 4 )			// Spedendo 4 byte alla volta e dovendo spedire 20 byte, devo
					fase = SEND_CHK;	// fare 5 spedizioni
				}	/* Chiusura if(!BytesInTxBuffer( _com) == TRUE)	*/
			}break;


		case SEND_CHK:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				scan_ptr = (uint8_t *)(&com[_com].tx_calc_ck); // ...volendo posso usare scan_ptr di 'com[_com]'
				*scan_ptr++;
				PutByte(_com, *scan_ptr--);
				PutByte(_com, *scan_ptr);
				fase = IDLE;
				}
			} break;

		default:
			fase = IDLE;
	}

	if(fase==IDLE)
  		return ENDOK;					// lo stato ENDOK se ho concluso la tx
    else
		return RUNNING;					// lo stato RUNNING in tutti gli altri casi
}


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//							 CHIUSURA FUNZIONI PER LA GESTIONE DELLE INFO
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//								 FUNZIONI PER LA GESTIONE DEGLI ERRORI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


// Cerca il numero di errori presenti e lo restituisce al programma
int16_t TrovaErrore(void)
{

int16_t car;
int32_t *p_long;

car=0;

p_long = (int32_t *)bufferErrori;

// Cerco il numero di errori
for (car = 0; car < TOTERRORI; car++)
	{
   	if (*p_long++ == 0)
			return car;
    }

// Se sono qui vuol dire che non ci sono errori
return car;
}


// Trova gli errori attivi
int16_t TrovaAttivi(void)
{

int16_t car;
int32_t *p_long;

car=0;
p_long = (int32_t *)bufErrAttivi;

// Cerco il numero di errori
for (car = 0; car < TOTERRORI; car++)
	{
   	if (*p_long++ == 0)
			return car;
    }

// Se sono qui vuol dire che non ci sono errori
return car;
}


// Invio del pacchetto per gli errori
int16_t SendErrore(uint8_t _com,BOOL Reset)
{
#define SEND_HEADER 		10
#define SEND_DATA	 		20
#define SEND_CHK	 		30

static int16_t dummy;		// Variabile di appoggio
static uint8_t fase;		// Fase della tx
static int16_t car;			// Contiene il numero di errori
static int16_t car_1;		// Contiene il numero di errori attivi

static uint8_t errore;	// Contiene un eventuale errore

static uint8_t *scan_ptr; //Necessario per inviare ck alla fine
per_com static *com_ptr;	// Puntatore alla struttura di rx/tx delle seriali

	if (Reset)
		{
		fase = 0;
		errore = 0;
		return RUNNING;
		}


	switch (fase)
	{
		case IDLE:
			{
			fase = SEND_HEADER;
			com_ptr = &com[_com];
			}break;

		case SEND_HEADER: // header
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				com_ptr->tx_calc_ck = 0;
				// header
				Put_and_ck(_com, '[');
				Put_and_ck(_com,com_ptr->source);
				Put_and_ck(_com, 0x20);
				Put_and_ck(_com,com_ptr->frame_id);
				fase++;
				}
			}break;

		case SEND_HEADER + 1: // lenght
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				switch(com_ptr->service_type)
					{
					case 'U':	// Richiesta per elenco degli errori possibili, richiesta Help
					case 'H':	// Il servizio non � supportato
            			{
						dummy = 4 + 2 + 1 + 2 + 4 + 2;
               			errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
						}break;

					case 'V':
						{

						car = TrovaErrore();
						car_1 = TrovaAttivi();
						
						// Decido quanti e quali tipi di errore ho
						if ((car == 0) && (car_1 == 0))
									{
									fase = SEND_CHK;	// Se non sono stati trovati errori spedisce
									dummy = 4 + 2 + 1 + 2 + 2;	// un ack
									}

						if ((car != 0) && (car_1 == 0))  // Ho solo errori
									{
									fase = SEND_DATA + 1;
									dummy = 4 + 2 + 1 + 2 + 8 * car + 2;
									car--;
									}

						if ((car == 0) && (car_1 != 0))	// Ho solo errori attivi
									{
									fase = SEND_DATA + 2;
									dummy = 4 + 2 + 1 + 2 + 8 * car_1 + 2;
									car_1--;
									}

						if ((car != 0) && (car_1 != 0))	// Ho sia errori attivi che
									{                   // errori
									fase = SEND_DATA + 3;
									dummy = 4 + 2 + 1 + 2 + 8 * (car + car_1) + 2;
									car--;
									car_1--;
									}
						}break;  /* Chiusura case 'V' */

					default:
						{// header 4 + lunghezza 2 + function 1 + service 2 + chk 2
						dummy = 4 + 2 + 1 + 2 + 2 + 4;
						errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
						}break;

					}//switch(com[_com].tipo_servizio)
				
				Put_and_ck(_com,dummy / 0x100);
				Put_and_ck(_com,dummy % 0x100);
				Put_and_ck(_com, com_ptr->function + 0x40); // function
				
				if( errore == 0 )
					Put_and_ck(_com,com_ptr->service);
				else
					Put_and_ck(_com,0x7f);

					Put_and_ck(_com,com_ptr->service_type);
					dummy = 0;
				} // Chiusura if(!BytesInTxBuffer( _com) == TRUE)
			}break;


		case SEND_ERRORE: // data per errori
			{
			if(!BytesInTxBuffer( _com) == TRUE)
		  		{
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,(uint8_t) errore);

				fase = SEND_CHK;
				}
			}break;


		case SEND_DATA + 4: // data, sono 4 byte help
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));

				fase = SEND_CHK;
   				}
			}break;


		case SEND_DATA + 3:		// Trasmetto sia i byte di errori attivi
      		{							// che i byte totali
			if(!BytesInTxBuffer( _com) == TRUE) // Se il buffer � vuoto, spedisce altri valori
				{
				if( dummy == 0 )	// Questo if permette di invertire i byte inviati
					{
	  				scan_ptr = (uint8_t *)(bufferErrori);
					scan_ptr += 3;
					}
				else
					{
					scan_ptr += 8;
					}

				Put_and_ck(_com,*scan_ptr--);	// Spedisco 8 byte
				Put_and_ck(_com,*scan_ptr--);
	  			Put_and_ck(_com,*scan_ptr--);
	  			Put_and_ck(_com,*scan_ptr--);

				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
	  			Put_and_ck(_com,0x00);
	  			Put_and_ck(_com,0x01);

				dummy++;

				// Spedisco per primo gli errori
				if (dummy > car)	// Mi preparo ora a spedire i BufErrAttivi
            		{
					fase = SEND_DATA + 2;
					dummy = 0;
					}
        		} /* if(!BytesInTxBuffer(uint8_t _com) == TRUE) */
        }break;	/* Chiusura case SEND_DATA + 1 */



		case SEND_DATA + 2:		/* Trasmetto i byte */
      		{
			if(!BytesInTxBuffer( _com) == TRUE) /* Se il buffer � vuoto, spedisce altri valori */
		      	{
				if( dummy == 0 )	// Questo if permette di invertire i byte inviati
					{
	  				scan_ptr = (uint8_t *)(bufErrAttivi);
		         	scan_ptr += 3;
					}
				else
					{
		         	scan_ptr += 8;
					}

				Put_and_ck(_com,*scan_ptr--);	/* Spedisco 4 byte alla volta */
				Put_and_ck(_com,*scan_ptr--);
	  			Put_and_ck(_com,*scan_ptr--);
	  			Put_and_ck(_com,*scan_ptr--);

				Put_and_ck(_com,0x00);	/* Spedisco 4 byte alla volta */
				Put_and_ck(_com,0x00);
	  			Put_and_ck(_com,0x00);
	  			Put_and_ck(_com,0x02);

				dummy++;

				if (dummy > car_1)
					fase = SEND_CHK;
			} /* if(!BytesInTxBuffer(uint8_t _com) == TRUE) */

         }break;	/* Chiusura case SEND_DATA + 1 */


		case SEND_DATA + 1:		/* Trasmetto i byte */
      		{
			if(!BytesInTxBuffer( _com) == TRUE) /* Se il buffer � vuoto, spedisce altri valori */
		  		{
				if( dummy == 0 )	// Questo if permette di invertire i byte inviati
					{
	  				scan_ptr = (uint8_t *)(bufferErrori);
					scan_ptr += 3;
					}
				else
					scan_ptr += 8;

				Put_and_ck(_com,*scan_ptr--);	/* Spedisco 4 byte alla volta */
				Put_and_ck(_com,*scan_ptr--);
	  			Put_and_ck(_com,*scan_ptr--);
	  			Put_and_ck(_com,*scan_ptr--);

				Put_and_ck(_com,0x00);	/* Spedisco 4 byte alla volta */
				Put_and_ck(_com,0x00);
	  			Put_and_ck(_com,0x00);
	  			Put_and_ck(_com,0x01);

				dummy++;

				if ( dummy > car )
					fase = SEND_CHK;
        		} /* if(!BytesInTxBuffer( _com) == TRUE) */
			}break;	/* Chiusura case SEND_DATA + 1 */

		case SEND_CHK:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				scan_ptr = (uint8_t *)(&com[_com].tx_calc_ck); // ...volendo posso usare scan_ptr di 'com[_com]'
				*scan_ptr++;
				PutByte(_com, *scan_ptr--);
				PutByte(_com, *scan_ptr);
				fase++;
				}
			}break;

		case SEND_CHK + 1:
			{
			fase = IDLE;
			} break;

		default:
			fase = IDLE;
			break;
	}

	if(fase==IDLE)
  		return ENDOK;						// lo stato ENDOK se ho concluso la tx
    else
		return RUNNING;					// lo stato RUNNING in tutti gli altri casi
}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//							CHIUSURA FUNZIONI PER LA GESTIONE DEGLI ERRORI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------




//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//								 FUNZIONI PER LA GESTIONE DEGLI STATI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------




// Invio dei diversi pacchetti per lo stato
int16_t SendStato(uint8_t _com,BOOL Reset)
{
#define SEND_HEADER 		10
#define SEND_DATA	 		20
#define SEND_CHK	 		30
#define SEND_ERRORE			40


#define STATI				0


static int16_t dummy;			//	Variabili di appoggio
int16_t i;					

static uint8_t fase;			//	Fase dell' automa dirisposta
static uint8_t errore;		// POssibili errori

per_com static *com_ptr;	// Puntatore alla struttura di rx/tx delle seriali
static uint8_t *scan_ptr;		//	Puntatore di appoggio

static uint32_t dato_richiesto;	// Variabili necessarie per ricostruire il dato richiesto
uint8_t conta;

	if (Reset)
		{
		fase = 0;
		errore = 0;
		dato_richiesto = 0;
		return RUNNING;
		}


	switch (fase)
	{
	case IDLE:
		{
		fase = SEND_HEADER;
		com_ptr = &com[_com];
		if((com_ptr->service_type == 'X') || (com_ptr->service_type == 'A') || (com_ptr->service_type == 'B'))
			{
			for (conta = 0; conta < 4; conta++)
				{
				dato_richiesto <<= 8;
				dato_richiesto += com_ptr ->rx_buf[com_ptr->data_ptr++];

				// ricircolo del buffer
				if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
					com_ptr->data_ptr = 0;
					
				}
			}
		}break;
	case SEND_HEADER: // header
		{
		if(!BytesInTxBuffer( _com) == TRUE)
	     	{
			com_ptr->tx_calc_ck = 0;
			// header
			Put_and_ck(_com, '[');
			Put_and_ck(_com,com_ptr->source);
			Put_and_ck(_com, 0x20);
			Put_and_ck(_com,com_ptr->frame_id);
			fase++;
            }
		}break;

		case SEND_HEADER + 1: // lenght
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				switch(com_ptr->service_type)
					{
					case 'V':
					case '0':
						{// header 4 + lunghezza 2 + function 1 + service 2 + data (TOTALESTATI+1)*4 + 2 chk
						dummy = 4 + 2 + 1 + 2 + (tot_stati - 1) * 4 + 2;
						errore = AFFERMATIVE_RESPONSE;
						fase = SEND_DATA;
						} break;

					case 'U':
						{// header 4 + lunghezza 2 + function 1 + service 2 + data (TOTALESTATI+1)*4 + 2 chk
						dummy = 4 + 2 + 1 + 2 + (POSSIBILISTATI) * 4 + 2;
						errore = AFFERMATIVE_RESPONSE;
						fase = SEND_DATA;
						}break;
					
					case 'H':
            			{
						dummy = 4 + 2 + 1 + 2 + 4 + 2;
               			errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
						}break;

					case 'X':
						{// header 4 + lunghezza 2 + function 1 + service 2 + data 4 + 2 chk
						dummy = 4 + 2 + 1 + 2 + 4 + 2;
						tot_stati = TOTALESTATI;
						if(dato_richiesto < (tot_stati))
               				{
							scan_ptr = (uint8_t *) setStati;
							scan_ptr += (dato_richiesto + 1)*4;	// Punta al dato singolo
							scan_ptr +=4;									// richiesto	
							errore = AFFERMATIVE_RESPONSE;
							fase = SEND_DATA + 1;
							}
						else
               				{
               				errore = DATA_NOT_SUPPORTED;
							fase = SEND_ERRORE;
							}
						}break;


					case 'B':	//	Disabilitazione singola
		           		{
						if(dato_richiesto < (tot_stati))	// Controllo
		               		{										 	// sul dato
							AbilPid((dato_richiesto + 1),STATI,DISABILITA);
							dummy = 4 + 2 + 1 + 2 + 2;
							errore = AFFERMATIVE_RESPONSE;
							fase = SEND_CHK;
							}
						else			// Se il dato richiesto non ha senso, spedisco un errore
	              			{// header 4 + lunghezza 2 + function 1 + service 2 + data 4 + 2 chk
							dummy = 4 + 2 + 1 + 2 + 4 + 2 + 4;
							errore = DATA_NOT_SUPPORTED;
							fase = SEND_ERRORE;
							}
						}break;

					case 'A':	//Abilitazione singola
            			{
						if(dato_richiesto < (tot_stati))
               				{											// sul dato
							AbilPid((dato_richiesto + 1),STATI,ABILITA);
							dummy = 4 + 2 + 1 + 2 + 2;
							errore = AFFERMATIVE_RESPONSE;
							fase = SEND_CHK;
							}
						else			// Se il dato richiesto non ha senso, spedisco un errore
               				{// header 4 + lunghezza 2 + function 1 + service 2 + data 4 + 2 chk
							dummy = 4 + 2 + 1 + 2 + 4 + 2 + 4;
							errore = DATA_NOT_SUPPORTED;
							fase = SEND_ERRORE;
							}
						}break;

					case 'S':		// Elenco dei soli stati abilitati
						{// header 4 + lunghezza 2 + function 1 + service 2 + 2 chk
						dummy = 4 + 2 + 1 + 2 + 2 ;

						for (i = 0; i < (tot_stati); i++)	// Controllo tutti gli stati
						  	if(stati_abilitati[ i / 8] & (1 << (i % 8)))
			                 	dummy += 4;			// Quando si trova uno stato abilitato, viene
						fase = SEND_DATA;			// incrementata di 4 la lunghezza da spedire
						errore = AFFERMATIVE_RESPONSE;
						}break;


					case 'T':
						{
						AbilTutto(ABILITA,STATI);
						dummy = 4 + 2 + 1 + 2 + 2;
						errore = AFFERMATIVE_RESPONSE;
						fase = SEND_CHK;
						}break;

					case 'C':
						{// header 4 + lunghezza 2 + function 1 + service 2 + chk 2
						AbilTutto(DISABILITA,STATI);
						dummy = 4 + 2 + 1 + 2 + 2;
						errore = AFFERMATIVE_RESPONSE;
						fase = SEND_CHK;
						}break;

					default:
						{// header 4 + lunghezza 2 + function 1 + service 2 + chk 2
						dummy = 4 + 2 + 1 + 2 + 4 + 2;
              			errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
						}break;
					}//switch(com[_com].tipo_servizio)

					Put_and_ck(_com,dummy / 0x100);
					Put_and_ck(_com,dummy % 0x100);
					Put_and_ck(_com, 0x22 + 0x40);	// function

					if(errore == 0)
						Put_and_ck(_com,com_ptr->service);
					else
						Put_and_ck(_com,0x7f);

					Put_and_ck(_com,com_ptr->service_type);
					dummy = 0;
				} // Chiusura if(!BytesInTxBuffer( _com) == TRUE)
			}break;	/* case SEND_HEADER + 1 */


		case SEND_ERRORE: // data per errori
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,errore);

				fase = SEND_CHK;
		        }
			}break;

		case SEND_DATA: // data
			{
			if (dummy == 0)
				{
				switch(com_ptr->service_type)
					{
					case 'V':  // Valore dei diversi stati
						{
						scan_ptr = (uint8_t *)setStati;
						scan_ptr += 4;
						}break;

  					case 'S':	// Elenco dei valori dei soli stati abilitati, punta allo 
  						{		// allo stesso array dei valori solo che vengono prelevati
						scan_ptr = (uint8_t *)setStati;	// solo quelli che sono abilitati
		                scan_ptr += 4;
						}break;

					case '0': // Elenco dei diversi tipi di Stato
		              	{
						scan_ptr = (uint8_t *)elencStati;
						scan_ptr += 4;
						}break;

					case 'U':	// Richiesta di elenco stati possibili
		               	{
		                scan_ptr = (uint8_t *)possStati;
		                }break;

	                default:
						break;
					} //switch(com[_com].tipo_servizio)
				} // chiusura if (dummy == 0)

			// Controlla che il buffer in trasmissione sia vuoto
			if(!BytesInTxBuffer( _com) == TRUE)	// Se il buffer � vuoto, spedisce altri valori
				{
				if( dummy == 0 )	// Questo if permette di invertire le quartine di byte inviati
	         		scan_ptr += 4;
				else
	         		scan_ptr += 8;

				if(com_ptr->service_type == 'S')	// Se il servizio richiesto sono gli stati
					{									// abilitati...	
		  			if(stati_abilitati[ dummy / 8] & (1 << (dummy % 8)))	// Controllo se lo stato
						{												// � abilitato, in questo caso
						Put_and_ck(_com,*(--scan_ptr));				// l'invio, in caso contrario non
						Put_and_ck(_com,*(--scan_ptr));				// invio niente
	  					Put_and_ck(_com,*(--scan_ptr));
	  					Put_and_ck(_com,*(--scan_ptr));
						}
					}
				else		// Se il servizio richiesto non sono gli stati abilitati....
					{
					Put_and_ck(_com,*(--scan_ptr));	// Spedisco 4 byte alla volta
					Put_and_ck(_com,*(--scan_ptr));
	  				Put_and_ck(_com,*(--scan_ptr));
	  				Put_and_ck(_com,*(--scan_ptr));
					}

				dummy++;

				if(com_ptr->service_type == 'U')		// Se ho richiesto l'elenco dei soli
					{									// stati abilitati, il numero di quartine
					if (dummy> (POSSIBILISTATI - 1) )	// di byte da inviare cambiano
						fase = SEND_CHK;
					}
           		else									// Se � richiesto un invio dei valori o un elenco
					{									// occorre inviare tutti gli stati
					if (dummy>(tot_stati-2))			
						fase = SEND_CHK;
					}
				}	// Fine if(!BytesInTxBuffer( _com))
			}break;

		case SEND_DATA + 1: // data
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				fase = SEND_CHK;
				}
			}break;

		case SEND_CHK:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				scan_ptr = (uint8_t *)(&com[_com].tx_calc_ck); // ...volendo posso usare scan_ptr di 'com[_com]'
				*scan_ptr++;
				PutByte(_com, *scan_ptr--);
				PutByte(_com, *scan_ptr);
				fase = IDLE;
				}
			}break;

		default:
			fase = IDLE;
	}

	if(fase==IDLE)
  		return ENDOK;					// lo stato ENDOK se ho concluso la tx
    else
		return RUNNING;					// lo stato RUNNING in tutti gli altri casi
}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//							CHIUSURA FUNZIONI PER LA GESTIONE DEGLI STATI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------




//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//								 FUNZIONI PER LA GESTIONE DEI PARAMETRI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------



// Spedisce i dati per il service 'Parametri'
int16_t SendParametro(uint8_t _com,BOOL Reset)
{
#define SEND_HEADER 		10
#define SEND_DATA	 		20
#define SEND_CHK	 		30
#define SEND_ERRORE			40

#define PARAMETRI			1


static int16_t dummy;			//	Variabile di appoggio 
int16_t i;						//	Variabile di appoggio 				
static uint8_t errore;		//	Contiene un eventuale errore
static uint8_t fase;			//  Fase Automa

static uint8_t *scan_ptr; 	//	Puntatore di appoggio
per_com static *com_ptr;	// Puntatore alla struttura di rx/tx delle seriali

static uint32_t dato_richiesto;
uint8_t conta;

	if (Reset)
		{
		fase = 0;
		errore = 0;
		return RUNNING;
		}


	switch (fase)
		{
		case IDLE:
			{
			fase = SEND_HEADER;
			dummy = 0;
			com_ptr = &com[_com];
			if((com_ptr->service_type == 'X') || (com_ptr->service_type == 'A') || (com_ptr->service_type == 'B'))
				{
				dato_richiesto = 0;
				for (conta = 0; conta < 4; conta++)
					{
					dato_richiesto  = dato_richiesto << 8;
					dato_richiesto += com_ptr ->rx_buf[com_ptr->data_ptr++];

					// ricircolo del buffer
					if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
						com_ptr->data_ptr = 0;
					}
				}
			}break;

		case SEND_HEADER: // header
			{
			if(!BytesInTxBuffer( _com) == TRUE)
		      	{
				com_ptr->tx_calc_ck = 0;
				// header
				Put_and_ck(_com, '[');
				Put_and_ck(_com,com_ptr->source);
				Put_and_ck(_com, 0x20);
				Put_and_ck(_com,com_ptr->frame_id);
				fase++;
		        }
			}break;

		case SEND_HEADER + 1: // lenght
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				switch(com_ptr->service_type)
					{
					case 'V':
					case '0':
					case 'U':
					case 'D':
						{// header 4 + lunghezza 2 + function 1 + service 2 + data TOTALEPARAMETRI+1 *4 + 2 chk
						dummy = 4 + 2 + 1 + 2 + (tot_parametri - 1) * 4 + 2 ;	/* TOTALEPARAMETRI == 0x2c */
						fase = SEND_DATA;
						errore = AFFERMATIVE_RESPONSE;
						}break;

					case 'S':		// Elenco dei soli parametri abilitati
						{// header 4 + lunghezza 2 + function 1 + service 2 + data TOTALEPARAMETRI+1 *4 + 2 chk
						dummy = 4 + 2 + 1 + 2 + 2 ;	/* TOTALEPARAMETRI == 0x2c */
						for (i = 0; i < (tot_parametri); i++)	// Controllo solo i primi 45 parametri
					 		if(param_abilitati[ i / 8] & (1 << (i % 8)))	
                  				dummy += 4;			//	Ogni volta che trovo un parametro abilitato
													//	incremento di 4 la lunghezza
						fase = SEND_DATA;
						errore = AFFERMATIVE_RESPONSE;
						}break;

					case 'H':
            			{
						dummy = 4 + 2 + 1 + 2 + 4 + 2;
               			errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
						}break;

					case 'X':
  						{// header 4 + lunghezza 2 + function 1 + service 2 + data 4 + 2 chk
						dummy = 4 + 2 + 1 + 2 + 4 + 2;
						tot_parametri = TOTALEPARAMETRI;
						if(dato_richiesto < (tot_parametri))
               				{
				   			errore = AFFERMATIVE_RESPONSE;
							fase = SEND_DATA + 1;
							}
						else
		               		{
							errore = DATA_NOT_SUPPORTED;
							fase = SEND_ERRORE;
							}
					   }break;

					case 'B':	//	Disabilitazione singola
            			{
						if(dato_richiesto < (tot_parametri))	// Controllo
               				{												// sul dato
							AbilPid((dato_richiesto) + 1,PARAMETRI,DISABILITA);
							dummy = 4 + 2 + 1 + 2 + 2;
							errore = AFFERMATIVE_RESPONSE;
							fase = SEND_CHK;
							}
						else			// Se il dato richiesto non ha senso, spedisco un errore
               				{
							dummy = 4 + 2 + 1 + 2 + 4 + 2;
							errore = DATA_NOT_SUPPORTED;
							fase = SEND_ERRORE;
							}
						}break;

					case 'A':	//Abilitazione singola
            			{
						if(dato_richiesto < (tot_parametri))				// Controllo
	               			{																// sul dato
							AbilPid((dato_richiesto + 1),PARAMETRI,ABILITA);
							dummy = 4 + 2 + 1 + 2 + 2;
							errore = AFFERMATIVE_RESPONSE;
							fase = SEND_CHK;
							}
						else			// Se il dato richiesto non ha senso, spedisco un errore
               				{
							errore = DATA_NOT_SUPPORTED;
							dummy = 4 + 2 + 1 + 2 + 4 + 2;
							fase = SEND_ERRORE;
							}
						}break;

					case 'T':
						{
						AbilTutto(ABILITA,PARAMETRI);
						dummy = 4 + 2 + 1 + 2 + 2;
						errore = AFFERMATIVE_RESPONSE;
						fase = SEND_CHK;
						}break;

					case 'C':
						{// header 4 + lunghezza 2 + function 1 + service 2 + chk 2
						AbilTutto(DISABILITA,PARAMETRI);
						dummy = 4 + 2 + 1 + 2 + 2;
						errore = AFFERMATIVE_RESPONSE;
						fase = SEND_CHK;
						}break;

					default:		// Tipo_servizio non riconosciuto
						{// header 4 + lunghezza 2 + function 1 + service 2 + numero errore 4 +chk 2
						// Se non si � riconosciuto il tipo servizio				
						dummy = 4 + 2 + 1 + 2 + 2 + 4;
						errore = TYPE_SERVICE_NOT_SUPPORTED;
						fase = SEND_ERRORE;
						}
					}//switch(com[_com].tipo_servizio)

				Put_and_ck(_com,dummy / 0x100);		// Spedisco i 2 byte della lunghezza
				Put_and_ck(_com,dummy % 0x100);
				Put_and_ck(_com, 0x22 + 0x40);		// function
				
				if (errore == 0)					// Se ho riscontrato degli errori, lo segnalo
 					Put_and_ck(_com,com_ptr->service);
  			 	else
					Put_and_ck(_com,0x7f);
				Put_and_ck(_com,com_ptr->service_type);
				dummy = 0;							// Azzero la variabile di appoggio

				} // Chiusura if(!BytesInTxBuffer( _com) == TRUE)
			}break; // case SEND_HEADER + 1


		case SEND_ERRORE: // data
			{
			if(!BytesInTxBuffer( _com) == TRUE)
	      		{
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,0x00);
				Put_and_ck(_com,errore);
				fase = SEND_CHK;
				}
			}break;

		case SEND_DATA: // data
			{
			if(!BytesInTxBuffer( _com) == TRUE) //Se il buffer � vuoto, spedisce altri valori
	      		{
				if (dummy == 0)
					{
					switch(com_ptr->service_type)
						{
						case 'V':	// Elenco del valore dei parametri
							{
							scan_ptr = (uint8_t *)setParametri;	// Array del valore dei parametri
							scan_ptr +=4;
							}break;

						case '0': // Elenco dei diversi tipi di parametro
							{
							scan_ptr = (uint8_t *)elencParam;	// Array dell'elenco dei parametri
							scan_ptr +=4;
							}break;

						case 'U': // Unit� di misura dei parametri
               				{
 							scan_ptr = (uint8_t *)umParam;	// Punta all' array delle unit� di misura
							scan_ptr +=4;
							}break;

						case 'D': // Precisione decimale dei parametri
	              			{
							scan_ptr = (uint8_t *)PrecParam;
							scan_ptr +=4;
							}break;
  						
						case 'S':	// Elenco del valore dei soli parametri abilitati
  							{
							scan_ptr = (uint8_t *)setParametri;
							scan_ptr += 4;
							}break;
						default:
							break;
						} //switch(com[_com].tipo_servizio)
					}  /* if (dummy == 0) */

				// Controlla che il buffer in trasmissione sia vuoto
				if( dummy == 0 )	// Questo if permette di invertire le quartine di byte inviati
         			scan_ptr += 4;
				else
         			scan_ptr += 8;
			
				if (com_ptr->service_type == 'S')		// Se richiedo di spedire i soli parametri 
					{									// abilitati.....
					if(param_abilitati[dummy / 8] & (1 << (dummy % 8)))	// Controlla che il parametro
						{												// sia abilitato
						Put_and_ck(_com,*(--scan_ptr));					// prima di spedirlo, se non lo
						Put_and_ck(_com,*(--scan_ptr));					// �, non spedisce nulla	
	 					Put_and_ck(_com,*(--scan_ptr));
	 					Put_and_ck(_com,*(--scan_ptr));
						}
					}
				else		// Se il tipo di servizio non � la richiesta dei soli parametri abilitati...
					{		// Spedisce 4 byte							
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
	 				Put_and_ck(_com,*(--scan_ptr));
	 				Put_and_ck(_com,*(--scan_ptr));
					}
				
				dummy++;

				if (dummy>(tot_parametri-2))							// Spedisce tutti i parametri
					fase = SEND_CHK;

				}	/* Chiusura if(!BytesInTxBuffer( _com))	*/
			}break;  /* Break SEND_DATA */

		case SEND_DATA + 1: // data
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				scan_ptr = (uint8_t *) setParametri;
				scan_ptr += (dato_richiesto + 1) * 4;		// Punta al dato singolo
				scan_ptr +=4;										// richiesto
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				Put_and_ck(_com,*(--scan_ptr));
				fase = SEND_CHK;
		        }
			}break;

		case SEND_CHK:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				scan_ptr = (uint8_t *)(&com[_com].tx_calc_ck); // ...volendo posso usare scan_ptr di 'com[_com]'
				*scan_ptr++;
				PutByte(_com, *scan_ptr--);
				PutByte(_com, *scan_ptr);
				fase = IDLE;
				}
			}break;

		default:
			fase = IDLE;
	}

	if(fase==IDLE)
  		return ENDOK;					// lo stato ENDOK se ho concluso la tx
    else
		return RUNNING;					// lo stato RUNNING in tutti gli altri casi
}






//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//							CHIUSURA FUNZIONI PER LA GESTIONE DEI PARAMETRI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//								 FUNZIONI PER LA GESTIONE DEI PARAMETRI E STATI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

// Questa funzione trasforma i valori dei parametri/stati da 0xfefefefe a 0xffffffff
void Aggiusta_valori()
{

int16_t i;
uint32_t *l_ulong;


	l_ulong =(uint32_t *)setParametri;
	for (i = 0; i < tot_parametri; i++, l_ulong++)	// Inizializza l' array che contiene il valore
		{
		if (*l_ulong == 0xfefefefe)
			*l_ulong = 0xffffffff;
		}

	l_ulong =(uint32_t *)setStati;
	for (i = 0; i < tot_stati; i++, l_ulong++)	// Inizializza l' array che contiene il valore
		{
		if (*l_ulong == 0xfefefefe)
			*l_ulong = 0xffffffff;
		}
}



//----------------------------------------------------------------------------------------------
// Disabilito il singolo parametro
void DisabilitaSingoloParametro(uint8_t _point_value)
{
	uint32_t *l_ulong;
	uint16_t i;

	// Disabilito il parametro
	l_ulong =(uint32_t *)setParametri;
	for (i = 0; i < _point_value; i++, l_ulong++);	// Inizializza l' array che contiene il valore
//		*l_ulong = 0xfefefefe;
		*l_ulong = 0xffffffff;

}


//----------------------------------------------------------------------------------------------
// Disabilito il singolo stato
void DisabilitaSingoloStato(uint8_t _point_value)
{
	uint32_t *l_ulong;
	uint16_t i;

	// Disabilito lo stato
	l_ulong =(uint32_t *)setStati;
	for (i = 0; i < _point_value; i++, l_ulong++);	// Inizializza l' array che contiene il valore
	//	*l_ulong = 0xfefefefe;
    	*l_ulong = 0xffffffff;

}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//					CHIUSURA FUNZIONI PER LA GESTIONE DEI PARAMETRI E STATI
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//					FUNZIONE PER LA GESTIONE DELLE RISPOSTE SULLO STATO DEL SISTEMA
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

// Funzione che gestisce la risposta nel caso si informazioni sullo stato del sistema
int16_t SendStatus(uint8_t _com,BOOL Reset)
{
#define SEND 		10

static uint8_t fase;
uint8_t *scan_ptr; //Necessario per inviare ck alla fine
uint8_t _i;

per_com static *com_ptr;

	if (Reset)
		{
		fase = 0;
		return RUNNING;
		}


	switch (fase)
	{
		case IDLE:
			{
			fase = SEND;
			com_ptr = &com[_com];	
			}break;

		case SEND:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
				{
				com_ptr->tx_calc_ck = 0;
				// header
				Put_and_ck(_com, '[');
				Put_and_ck(_com,com_ptr->source);
				Put_and_ck(_com, 0x20);
				Put_and_ck(_com,com_ptr->frame_id);
				fase++;
				}
			}break;

		case SEND + 1:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				Put_and_ck(_com, 0x00);
  				
				// Spedisco la lunghezza del pacchetto
				switch(com_ptr->service_type)
					{
					case 0x00:
					case 0x20:
					case 'v':
						{
						Put_and_ck(_com, 0x0f);
						}break;

					case 'c':
						{
						// Conto il numero di centraline disponibili per spedire la lunghezza
						// opportuna
						for (_i = 0; _i < 16; _i++)
							{
							if (!centraline_disponibili[_i])
								break;
							}

						Put_and_ck(_com, 0x0b + _i * 4);
						}break;

					default:
						{
						Put_and_ck(_com, 0x0b);
						}break;
					} // Chiusura switch()

				Put_and_ck(_com, com_ptr->function + 0x40);

				if(	(com_ptr->service_type == 0x10) || (com_ptr->service_type == 0x00)
				  ||(com_ptr->service_type == 0x80) || (com_ptr->service_type == 0x20)
				  ||(com_ptr->service_type == 0xff) || (com_ptr->service_type == 'v' )
				  ||(com_ptr->service_type == 'm' ) || (com_ptr->service_type == 'M' )
				  ||(com_ptr->service_type == 'c' ) || (com_ptr->service_type == 'X' )
				  ||(com_ptr->service_type == 'N' ))
         			Put_and_ck(_com,0x3f);
				else
         			Put_and_ck(_com,0x7f);

				fase++;
				}
			}break;

		case SEND + 2:
			{
			if(!BytesInTxBuffer( _com) == TRUE)
      			{
				Put_and_ck(_com,com_ptr->service_type);
  				
				if(com_ptr->service_type == 0x00)
         			{
					scan_ptr = (uint8_t *) (&SisStatus);		// spedisco la release sw
					scan_ptr +=4;
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					}
				else if (com_ptr->service_type == 0x20)			// Release sw
	         		{
					scan_ptr = (uint8_t *) (&release_sw);		// spedisco la release sw
					scan_ptr +=4;
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					}
				else if (com_ptr->service_type == 'v')			// Release sw
	         		{
					scan_ptr = (uint8_t *) (&variante);		// spedisco la release sw
					scan_ptr +=4;
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					Put_and_ck(_com,*(--scan_ptr));
					}
				else if(com_ptr->service_type == 'c')
					{
					for (_i = 0; _i < 16; _i++)
						{
						if (!centraline_disponibili[_i])
							break;

						centralina = (uint32_t) centraline_disponibili[_i];
						scan_ptr = (uint8_t *) (&centralina);		// spedisco la release sw
						scan_ptr +=4;
						Put_and_ck(_com,*(--scan_ptr));
						Put_and_ck(_com,*(--scan_ptr));
						Put_and_ck(_com,*(--scan_ptr));
						Put_and_ck(_com,*(--scan_ptr));
						}
					}
				scan_ptr = (uint8_t *)(&com[_com].tx_calc_ck); // ...volendo posso usare scan_ptr di 'com[_com]'
				*scan_ptr++;
				PutByte(_com, *scan_ptr--);
				PutByte(_com, *scan_ptr);
				fase++;
				}
			}break;

		case SEND + 3:
			{
			fase = IDLE;
			} break;

		default:
			fase = IDLE;
			break;
	}

	if(fase==IDLE)
  		return ENDOK;					// lo stato ENDOK se ho concluso la tx
    else
		return RUNNING;					// lo stato RUNNING in tutti gli altri casi
}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//					FUNZIONE PER LA GESTIONE DELLE RISPOSTE SULLO STATO DEL SISTEMA
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


__far uint8_t MonitorManager(uint8_t ser_ut, BOOL Reset)
{

#define RX		10
#define TX		20
#define RX_TX	30

static uint8_t fase;

if (Reset)
	{
	if (!variante_ok)
	{
		InitVariante();
		InitParam();
		InitStati();
		InitIndexAtt();		// Inizializzazione Attivazioni
		InitInfo ();		// Inizializzazione Info

	}
	fase = 0;
	Pc_command_decode(ser_ut,Reset);
	return IDLE;
	}

	local_address = 0x20;

	Rx_tecnomotor_frame();
	Pc_command_decode(ser_ut,Reset);
	Unknown_frame_handler();

	return (0);
}


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//					FUNZIONE PER LA GESTIONE DEL RICONOSCIMENTO DELLE RICHIESTE
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


// tecnomotor standard protocol rx procedure
__far void Rx_tecnomotor_frame(void)
{
	#define RX_SOT						1
	#define RX_HEADER					2		// receive header
	#define RX_FRAME					10		// receive frame body
	#define FRAME_COMPLETED				20		// analyze frame
	#define FRAME_RECOGNIZE 			30		// waits for frame recognized
	#define FRAME_PROCESS				40		// waits for frame processed
	#define FRAME_TIMEOUT				50		// handles frame timeout
	#define FRAME_UNKNOWN_COMMAND		60		// sends function unknown

	// variables
	static uint8_t car_x;	
	per_com *com_ptr;		// pointers to previous structures



	com_ptr = com_struct_ptr[monitor_line];

	if((com_ptr->fase_rx > 1) && (com_ptr->fase_rx < FRAME_RECOGNIZE))
	{
		// checks for frame timeout
		if (GetTime(&(com_ptr->frame_time)) > FRAMING_TIMEOUT)
		{
			com_ptr->status = FRAME_STATUS_CLEAR;
			com_ptr->fase_rx = RX_SOT;					
		}
	}

	// Inizio della fase di riconoscimento 
	switch(com_ptr->fase_rx)
	{
		// reset state
		case 0:										//	reset state
			com_ptr->frame_act_length = 0;						
			com_ptr->data_length = 0x00;						
			com_ptr->calc_ck = 0;
			com_ptr->status = FRAME_STATUS_CLEAR;
			com_ptr->fase_rx++;
			break;	

		case RX_SOT:								//	waiting for SOT
			if (com_ptr->rx_in != com_ptr->rx_out)
			{
				if (GetByte(monitor_line) == SOT)				// SOT received
				{
					com_ptr->frame_act_length = 1;						
					com_ptr->calc_ck = SOT;   					
					com_ptr->fase_rx = RX_HEADER;					
				}
			}

			ResetOrol(&(com_ptr->frame_time));
			break;	

		// receives 1 by 1 all characters of the header
		// target
		case RX_HEADER: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->target = car_x;
				com_ptr->fase_rx++;					
			}
			break;

		// source
		case RX_HEADER+1: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->source = car_x;
				com_ptr->fase_rx++;					
			}
			break;

		// id frame
		case RX_HEADER+2: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->frame_id = car_x;
				com_ptr->fase_rx++;					
			}
			break;

		// MSB length
		case RX_HEADER+3: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->frame_length = (car_x << 8);
				com_ptr->fase_rx++;					
			}
			break;

		// LSB length
		case RX_HEADER+4: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->frame_length |= car_x;
				com_ptr->fase_rx++;					
			}
			break;

		// function
		case RX_HEADER+5: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->function = car_x;
				com_ptr->fase_rx++;
			}
			break;

		// service
		case RX_HEADER+6: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->service = car_x;
				com_ptr->fase_rx++;					
			}
			break;

		// service type
		case RX_HEADER+7: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						
				com_ptr->service_type = car_x;
				com_ptr->data_ptr = com_ptr->rx_out;
				com_ptr->fase_rx = RX_FRAME;					
			}
			break;

		// rest of frame
		case RX_FRAME: 							
			if (com_ptr->rx_in != com_ptr->rx_out)
      		{
				car_x = Get_and_ck(monitor_line);  
				com_ptr->frame_act_length++;						

				// MSB checksum
				if (com_ptr->frame_act_length == (com_ptr->frame_length - 1))
				{
					com_ptr->calc_ck -= car_x;
					com_ptr->rx_ck = (car_x << 8);  
				}

				// LSB checksum
				if (com_ptr->frame_act_length == com_ptr->frame_length)
				{
					com_ptr->calc_ck -= car_x;
					com_ptr->rx_ck |= car_x;
					com_ptr->fase_rx = FRAME_COMPLETED;
				}
			}
			break;

		// checks for frame integrity
 		case FRAME_COMPLETED:	
			// checks checksum
			if (com_ptr->calc_ck != com_ptr->rx_ck)
			{
				com_ptr->status = FRAME_STATUS_CKS_ERR;
				com_ptr->fase_rx = RX_SOT;				// reset rx fase
				break;
			}

			// checks target
			if (com_ptr->target != local_address)
			{
				com_ptr->status = FRAME_STATUS_CLEAR;
				com_ptr->fase_rx = RX_SOT;				// reset rx fase
				break;
			}

			com_ptr->data_length = com_ptr->frame_length - 11;				//
			com_ptr->status = FRAME_STATUS_OK;
			com_ptr->fase_rx = FRAME_RECOGNIZE;		
			break;

		// checks if frame process is started
		case FRAME_RECOGNIZE:
			if (!(com_ptr->status & (FRAME_STATUS_PROCESSING | FRAME_STATUS_PROCESSED)))
			{
				if (!(com_ptr->status & (FRAME_STATUS_SERV_ERR | FRAME_STATUS_TYPE_ERR)))
					com_ptr->status |= (FRAME_STATUS_PROCESSING | FRAME_STATUS_FUNC_ERR);
					
				if(com_ptr->status == FRAME_STATUS_FUNC_ERR)
					com_ptr->status = FRAME_STATUS_FUNC_ERR;

				com_ptr->status &= ~FRAME_STATUS_OK;
			}

			com_ptr->fase_rx = FRAME_PROCESS;		
			break;

		// checks if frame process is accomplished
		case FRAME_PROCESS:
			if (!(com_ptr->status & FRAME_STATUS_PROCESSED))
				break;

			com_ptr->status = FRAME_STATUS_CLEAR;
			com_ptr->fase_rx = RX_SOT;		
			break;

		// checks if frame process is accomplished
		case FRAME_TIMEOUT:
			com_ptr->fase_rx = RX_SOT;					
			break;

		default:
			break;
	} 
} 



//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//					CHIUSURA FUNZIONE PER LA GESTIONE DEL RICONOSCIMENTO DELLE RICHIESTE
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------





//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//						FUNZIONE PER LA GESTIONE DELLA RISPOSTA AL MICRO
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------


// Questa funzione controlla la coerenza delle domande poste dal visualizzatore
__far void Pc_command_decode(uint8_t _com,BOOL Reset)						
{
	// machine states
	#define PC_DECODE				0
	#define SPEDISCE_PARAMETRI		10
	#define SPEDISCE_STATI			20
	#define SPEDISCE_ERRORI			30
	#define SPEDISCE_ATTIVAZIONI	40
	#define SPEDISCE_INFO			50
	#define SPEDISCE_VISUALIZZA		60
	#define SPEDISCE_STATUS			70
	#define	PC_NOTIFY				80

	static uint16_t fase;
	static WORD dummy_w;				//dummy
	int16_t conta;
#ifdef	MULTI_CENTRALINA
	uint32_t _appoggio;
#endif
	per_com static *com_ptr;			// pointers to the com buffer structures


	if(Reset)
		{	
		SendAttivazione(_com,Reset);
		SendErrore(_com,Reset);
		SendInfo(_com,Reset);
		SendParametro(_com,Reset);
		SendStato(_com,Reset);
		SendStatus(_com,Reset);
		SendVisualizza(_com,Reset);
		fase = PC_DECODE;
		return;
		}

	// if no command received... returns
	if (!(com_struct_ptr[_com]->status & FRAME_STATUS_OK))
	{
		fase = PC_DECODE;
		return;
	}


	switch(fase)
	{
		// decodes pc commands
		case PC_DECODE:
			{
			com_ptr = com_struct_ptr[_com];

			switch(com_ptr->function)
				{
				// notify
				case NOTIFICA:
					com_ptr->status |= FRAME_STATUS_PROCESSING;
					fase = PC_NOTIFY;
					break;

				// richiesta dati
				case DATI:
					{
					switch(com_ptr->service)
						{
						case 'P': 	// Richiesta parametro
							{
							com_ptr->status |= FRAME_STATUS_PROCESSING;
							fase = SPEDISCE_PARAMETRI;
							}break;

						case 'S':	// Richiesta stati
							{   
							com_ptr->status |= FRAME_STATUS_PROCESSING;
							fase = SPEDISCE_STATI;
							}break;
						
						case 'E':	// Richiesta errori 
							{
							com_ptr->status |= FRAME_STATUS_PROCESSING;
							fase = SPEDISCE_ERRORI;
							}break;
	        			
						case 'A':	// Richiesta attivazione
							{
							com_ptr->status |= FRAME_STATUS_PROCESSING;
							fase = SPEDISCE_ATTIVAZIONI;
							}break;
	        		
						case 'I':	// Richiesta informazioni
							{
							com_ptr->status |= FRAME_STATUS_PROCESSING;
							fase = SPEDISCE_INFO;
							}break;

						case 0x00:	// Richiesta messaggi attivazioni
	           				{
							com_ptr->status |= FRAME_STATUS_PROCESSING;
							fase = SPEDISCE_VISUALIZZA;
							}break;

						case 0x3f:	// Richiesta di informazioni sullo stato del sistema
							{
							switch(com_ptr->service_type)
								{
								case 0x10:	// Richiesta di start comunicazione
									{
									SisStartCom = SISSTARTCOMM;		
									com_ptr->status |= FRAME_STATUS_PROCESSING;
									fase = SPEDISCE_STATUS;
									}break;
								
								case 0x80:	// Stop comunicazione
									{
									SisStartCom = SISSTOPCOMM;
									com_ptr->status |= FRAME_STATUS_PROCESSING;
									fase = SPEDISCE_STATUS;
									}break;

								case 0xff:	// Esci dal sistema
									{
									SisStartCom = SISSEXIT;
									com_ptr->status |= FRAME_STATUS_PROCESSING;
									fase = SPEDISCE_STATUS;
									}break;
								
								case 'v':
									variante = 0;
									for (conta = 0; conta < 4; conta++)
										{
										variante  = variante << 8;
										variante += com_ptr ->rx_buf[com_ptr->data_ptr++];

										// ricircolo del buffer
										if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
											com_ptr->data_ptr = 0;
										}

									InitVariante();								
									variante_ok= 0;
									InitParam();
									InitStati();
									InitIndexAtt();		// Inizializzazione Attivazioni
									InitInfo ();		// Inizializzazione Info
									com_ptr->status |= FRAME_STATUS_PROCESSING;
									fase = SPEDISCE_STATUS;
									break;

								case 0x00:	// Richiesta stato della comunicazione
								case 0x20:	// Richiesta stato della comunicazione
								case 'm':
								case 'M':
#ifdef	MULTI_CENTRALINA
								case 'c':	// MT021115LC Aggiunta gestione multi-centralina
#endif
									com_ptr->status |= FRAME_STATUS_PROCESSING;
									fase = SPEDISCE_STATUS;
									break;
#ifdef	MULTI_CENTRALINA
								case 'X':
									{
									_appoggio = 0;
									// Ricostruisco il dato
									for (conta = 0; conta < 4; conta++)
										{
										_appoggio  = _appoggio << 8;
										_appoggio += com_ptr ->rx_buf[com_ptr->data_ptr++];

										// ricircolo del buffer
										if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
											com_ptr->data_ptr = 0;
										}

									// Prelevo il byte meno significato della variabile _appoggio
									centralina_scelta = (uint8_t) (_appoggio % 0x100);
								
									// Prelevo il byte pi� significativo della variabile _appoggio
									protocollo_scelto = (uint8_t) (_appoggio / 0x1000000);

									com_ptr->status |= FRAME_STATUS_PROCESSING;
									fase = SPEDISCE_STATUS;
									}break;
									
								case 'N':
									{
									_appoggio = 0;
									// Ricostruisco il dato
									for (conta = 0; conta < 4; conta++)
										{
										_appoggio  = _appoggio << 8;
										_appoggio += com_ptr ->rx_buf[com_ptr->data_ptr++];

										// ricircolo del buffer
										if(com_ptr->data_ptr >= com_ptr->rx_buf_len)
											com_ptr->data_ptr = 0;
										}
									// Metto il dato ricostruito nella variabile corretta
									normativa = (uint8_t) _appoggio;

									com_ptr->status |= FRAME_STATUS_PROCESSING;
									fase = SPEDISCE_STATUS;
									}break;
#endif

								default:
									{
									com_ptr->status |= (FRAME_STATUS_TYPE_ERR);
									fase = PC_DECODE;
									}break;
								}	// Chiusura switch(com_ptr->service_type)
							}break;	// Chiusura case 0x3f

						default:
							{
							// service not supported
							com_ptr->status |= (FRAME_STATUS_SERV_ERR);
							fase = PC_DECODE;					
							}
						}	// Chiusura switch(com_ptr->service)
					}break;		// Chiusura case DATI

				}  // Chiusura switch (com_ptr->function)
			}break;	// Chiusura case PC_DECODE

		case PC_NOTIFY:
			dummy_w = 11 + 0;				// length of frame (11 + data lenght)

			com_ptr->tx_calc_ck = 0;
			Put_and_ck(_com, SOT);
			Put_and_ck(_com, com_ptr->source);
			Put_and_ck(_com, local_address);
			Put_and_ck(_com, com_ptr->frame_id);
			Put_and_ck(_com, (dummy_w >> 8));
			Put_and_ck(_com, (dummy_w & 0xff));
			Put_and_ck(_com, com_ptr->function + 0x40);
			Put_and_ck(_com, com_ptr->service);
			Put_and_ck(_com, com_ptr->service_type);
			PutByte(_com, (com_ptr->tx_calc_ck >> 8));			// MSB checksum
			PutByte(_com, (com_ptr->tx_calc_ck & 0xff));		// LSB checksum

			com_ptr->status |= FRAME_STATUS_PROCESSED;
			fase = PC_DECODE;
			break;

			
			case SPEDISCE_PARAMETRI:
				{
        	  	if(SendParametro(_com,Reset) == ENDOK)
					{
					com_ptr->status |= FRAME_STATUS_PROCESSED;
					fase = PC_DECODE;
					};
				}break;


			case SPEDISCE_STATI:
				{
        	  	if(SendStato(_com,Reset) == ENDOK)
					{
					com_ptr->status |= FRAME_STATUS_PROCESSED;
					fase = PC_DECODE;
					};
				}break;

			case SPEDISCE_ERRORI:
				{
        	  	if(SendErrore(_com,Reset) == ENDOK)
					{
					com_ptr->status |= FRAME_STATUS_PROCESSED;
					fase = PC_DECODE;
					};
				}break;

			case SPEDISCE_ATTIVAZIONI:
				{
        	  	if(SendAttivazione(_com,Reset) == ENDOK)
					{
					com_ptr->status |= FRAME_STATUS_PROCESSED;
					fase = PC_DECODE;
					};
				}break;

			case SPEDISCE_INFO:
				{
				if(SendInfo(_com,Reset) == ENDOK)
					{
					com_ptr->status |= FRAME_STATUS_PROCESSED;
					fase = PC_DECODE;
					};
				}break;

			case SPEDISCE_VISUALIZZA:
				{
				if(SendVisualizza(_com,Reset) == ENDOK)
					{
					com_ptr->status |= FRAME_STATUS_PROCESSED;
					fase = PC_DECODE;
					};
				}break;
				
			case SPEDISCE_STATUS:
				{
				if(SendStatus(_com,Reset) == ENDOK)
					{
					com_ptr->status |= FRAME_STATUS_PROCESSED;
					fase = PC_DECODE;
					};
				}break;
	}	// Chiusura switch(fase)	
}


//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//						CHIUSURA FUNZIONE PER LA GESTIONE DELLA RISPOSTA AL MICRO
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------



//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//				FUNZIONE PER LA GESTIONE DELLE RISPOSTE DI ERRORE
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------



// sends an answer for the wrong frames
__far void Unknown_frame_handler(void)
{
	WORD dummy_w;
	per_com static *com_ptr;			// pointers to the com buffer structures

	// if no errors received... returns
	if (!(com_struct_ptr[monitor_line]->status & (FRAME_STATUS_FUNC_ERR | FRAME_STATUS_SERV_ERR | FRAME_STATUS_TYPE_ERR)))
		return;

	// if still ok... returns
	if (com_struct_ptr[monitor_line]->status & FRAME_STATUS_OK)
		return;

	com_ptr = com_struct_ptr[monitor_line];
	dummy_w = 15;					// length of frame

	
	com_ptr->tx_calc_ck = 0;
	Put_and_ck(monitor_line, SOT);
	Put_and_ck(monitor_line, com_ptr->source);
	Put_and_ck(monitor_line, local_address);
	Put_and_ck(monitor_line, com_ptr->frame_id);
	Put_and_ck(monitor_line, (dummy_w >> 8));
	Put_and_ck(monitor_line, (dummy_w & 0xff));
	Put_and_ck(monitor_line, com_ptr->function + 0x40);
	Put_and_ck(monitor_line, NEGATIVE_RESPONSE);
	Put_and_ck(monitor_line, com_ptr->service_type);
	Put_and_ck(monitor_line, 0x00);
	Put_and_ck(monitor_line, 0x00);
	Put_and_ck(monitor_line, 0x00);
	

	if (com_ptr->status & FRAME_STATUS_FUNC_ERR)
		{
		Put_and_ck(monitor_line,FUNCTION_NOT_SUPPORTED);
		}
	else if (com_ptr->status & FRAME_STATUS_SERV_ERR)
		{
		Put_and_ck(monitor_line,SERVICE_NOT_SUPPORTED);
		}
	else if (com_ptr->status & FRAME_STATUS_TYPE_ERR)
		{
		Put_and_ck(monitor_line,TYPE_NOT_SUPPORTED);
		}


	PutByte(monitor_line, (com_ptr->tx_calc_ck >> 8));	// MSB checksum
	PutByte(monitor_line, (com_ptr->tx_calc_ck & 0xff));	// LSB checksum
	
	com_struct_ptr[monitor_line]->status |= FRAME_STATUS_PROCESSED;
}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//
//				CHIUSURA FUNZIONE PER LA GESTIONE DELLE RISPOSTE DI ERRORE
//
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
