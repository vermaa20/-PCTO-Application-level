#include "stdint.h"
// 
// usa per la generazione del tick il PPG0
//

#include "mb90540.h"

#include "typedefs.h"

#define TIME_C

#include "time.h"
#include "vectors.h"
#include "sistema.h"
#ifndef ACCEMIC_ON
 #ifdef	EMULATOR_ON
	#include "ram_code.h"
 #endif
#endif

#ifdef EMULATOR_ON

// ----------------------------------------------------------------------------
//								TIME HANDLER
// ----------------------------------------------------------------------------
// setups PPG0 hardware
__far void timer_init()
{
	// ------------------------------- T I M E R S  ------------------------------------------------
	// PPG0,1 clock select register
	// 7.PCS2	= count clock PPG0 selection bit
	// 6.PCS1	= count clock PPG0 selection bit
	// 5.PCS0	= count clock PPG0 selection bit
	// 4.PCM2	= count clock PPG1 selection bit
	// 3.PCM1	= count clock PPG1 selection bit
	// 2.PCM0	= count clock PPG1 selection bit
	// 1.---	= ---
	// 0.---	= ---
	//
	//	PCS2	PCS1	PCS0	Operation mode PPG0
	//	0		0		0		peripheral clock (62.5ns/16MHz)
	//	0		0		1		peripheral clock/2 (125ns/16MHz)
	//	0		1		0		peripheral clock/4 (250ns/16MHz)
	//	0		1		1		peripheral clock/8 (500ns/16MHz)
	//	1		0		0		peripheral clock/16 (1us/16MHz)
	//	1		1		1		clock input from time base timer(128us/4MHz)
	//
	//	PCM2	PCM1	PCM0	Operation mode PPG1 
	//	0		0		0		peripheral clock (62.5ns/16MHz)
	//	0		0		1		peripheral clock/2 (125ns/16MHz)
	//	0		1		0		peripheral clock/4 (250ns/16MHz)
	//	0		1		1		peripheral clock/8 (500ns/16MHz)
	//	1		0		0		peripheral clock/16 (1us/16MHz)
	//	1		1		1		clock input from time base timer(128us/4MHz)
	PPG01 = 0x90;		// PPG0=clk/16; PPG1=clk/16

	// reload value
	PRLL1 = 100 - 1; 			// 100us
	PRLH1 = 100 - 1; 			// 100us
	
	// pulse generator 0 : usato per base tempi 100us
	// reload value
	PRLL0 = 100 - 1; 			// 100us
	PRLH0 = 100 - 1; 			// 100us
	
	// PPGC1 operation mode control register
	// 7.PEN1	= PPG enable 0=stop; 1=enable
	// 6.--- 	= ---
	// 5.PE10	= PPG output enable 0=general purpose; 1=pulse out
	// 4.PIE1	= PPG irq enable 0=disabled; 1=enabled
	// 3.PUF1	= PPG counter underflow 1=detected
	// 2.MD1 	= PPG count mode
	// 1.MD0	= PPG count mode
	// 0.---	= ---
	//
	//	MD1		MD0		Operation mode PPG0
	//	0		0		8bit PPG 2ch independent mode
	//	0		1		8bit prescaler + 8bit PPG 1ch mode
	//	1		0		DO NOT USE!!!
	//	1		1		16bit PPG 1ch mode
	// (abbinato in HW a PPG0)
	PPGC1 = 0x00;		// 2ch independent; no out pin; no irq; PPG enabled

	// PPGC0 operation mode control register
	// 7.PEN0	= PPG enable 0=stop; 1=enable
	// 6.--- 	= ---
	// 5.PE00	= PPG output enable 0=general purpose; 1=pulse out
	// 4.PIE0	= PPG irq enable 0=disabled; 1=enabled
	// 3.PUF0	= PPG counter underflow 1=detected
	// 2.---	= ---
	// 1.---	= ---
	// 0.---	= DO NOT USE!!!
	PPGC0 = 0x90;		// PPG enabled; IRQ enabled; no out pin
}

// ----------------------------------------------------------------------------
//								GESTIONE TEMPO
// ----------------------------------------------------------------------------



__far void ResetOrol(uint16_t *_orol)
{
	*_orol = main_time;
}

__far uint16_t GetTime(uint16_t *_orol)
{
	return main_time - *_orol;
}

//__interrupt 
__far void PPG0_IRQHandler (void)
{
	static uint8_t fase = 0;
	
	PPGC0_PUF0 = 0;
//	PPGC1_PUF1 = 0; n.u. per ora
	
	switch(fase)
	{
		case 0:
		{
			main_time++;
	
			fase++;
		} break;
		case 1:
		{
			if (timing_10ms)
				timing_10ms--;
			fase++;
		} break;
		case 2:
		{
			if (timing_100ms)
				timing_100ms--;
			fase++;
		} break;
		case 3:
		{
			fase++;
		} break;
		case 4:
		{
			fase++;
		} break;
		case 5:
		{
			fase++;
		} break;
		case 6:
		{
			fase++;
		} break;
		case 7:
		{
			fase++;
		} break;
		case 8:
		{
			fase++;
		} break;
		case 9:
		default:
		{
			fase = 0;
		} break;
	} // switch(fase)
	
}
#else
	__far void ResetOrol(uint16_t *_orol)
	{
		((__far void (*)())vect250)(_orol,0);
	}
	 
	__far uint16_t GetTime(uint16_t *_orol)
	{
		 return ((__far uint16_t (*)())vect250)(_orol,1);
	}
	 
	__far void timer_init()
	{
		((__far void (*)())vect250)(0,2);
	}
#endif


