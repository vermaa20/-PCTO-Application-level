#include "stdint.h"
//------------------------------------------------------------------------------
// HEADING

// PROJECT NAME:     Sis_NNN.prj/Sis_RAM_NNN.prj
// PROJECT RELEASE:  VIEW HEADING OF "sistema.c"
// FILE NAME:        hw.h
// FILE RELEASE:     1.0
// DATE:             February 2004
// FILE DESCRIPTION: Micro-controller PIN-OUT configuration.
// REVIEW  BY:       Ing. Andrea Acunzo - Ing. Diego Mainardi
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// FURTHER INFORMATIONS
// Hardware5/Hardware6 IO defines (virtualized for hardware7)


//------------------------------------------------------------------------------
// COMPILER DIRECTIVE

#ifndef HW_H                     // To include this Header once and
#define HW_H                     // avoiding extra compilation
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// CODE

#define		AS_INPUT		0
#define		AS_OUTPUT		1


#define	ALE				PDR3_P30
#define	RD_				PDR3_P31
#define	WRL_			PDR3_P32
#define	WRH_			PDR3_P33
#define	READYCF		PDR3_P34
#define	CMD_A			PDR3_P35
#define	CMD_B			PDR3_P36
#define	CLK				PDR3_P37

#define	PORT_ALE			DDR3_D30
#define	PORT_RD_			DDR3_D31
#define	PORT_WRL_			DDR3_D32
#define	PORT_WRH_			DDR3_D33
#define	PORT_READYCF	DDR3_D34
#define	PORT_CMD_A		DDR3_D35
#define	PORT_CMD_B		DDR3_D36
#define	PORT_CLK			DDR3_D37

#define	S0_TX			PDR4_P40
#define	SCK_EXT0	PDR4_P41
#define	S0_RX			PDR4_P42
#define	S1_RX			PDR4_P43
#define	SCK_EXT1	PDR4_P44
#define	S1_TX			PDR4_P45
#define	EN_485		PDR4_P46
#define	RESUART		PDR4_P47

#define	PORT_S0_TX			DDR4_D40
#define	PORT_SCK_EXT0		DDR4_D41
#define	PORT_S0_RX			DDR4_D42
#define	PORT_S1_RX			DDR4_D43
#define	PORT_SCK_EXT1		DDR4_D44
#define	PORT_S1_TX			DDR4_D45
#define	PORT_EN_485			DDR4_D46
#define	PORT_RESUART		DDR4_D47

#define	MUX_RST		PDR5_P50
#define	INT4			PDR5_P51
#define	INT5			PDR5_P52
#define	INT6			PDR5_P53
#define	INT7			PDR5_P54

#define	MUX_D_P			PDR5_P55
#define	MUX_CK_P		PDR5_P56

#define	GLB_CLR_CPLD	PDR5_P57

#define	PORT_MUX_RST	DDR5_D50
#define	PORT_INT4			DDR5_D51
#define	PORT_INT5			DDR5_D52
#define	PORT_INT6			DDR5_D53
#define	PORT_INT7			DDR5_D54

#define	PORT_MUX_D_P		DDR5_D55
#define	PORT_MUX_CK_P		DDR5_D56

#define	PORT_GLB_CLR_CPLD	DDR5_D57

#define	VBE_CHK		PDR6_P60
#define	CD1_			PDR6_P61
#define	CD2_			PDR6_P62
#define	OBD_AN		PDR6_P63
#define	CAN_SLOPE	PDR6_P64
#define	CAN_STBY	PDR6_P65
#define	CMD_F			PDR6_P66
#define	CMD_E			PDR6_P67

#define	PORT_VBE_CHK		DDR6_D60
#define	PORT_CD1_				DDR6_D61
#define	PORT_CD2_				DDR6_D62
#define	PORT_OBD_AN			DDR6_D63
#define	PORT_CAN_SLOPE	DDR6_D64
#define	PORT_CAN_STBY		DDR6_D65
#define	PORT_CMD_F			DDR6_D66
#define	PORT_CMD_E			DDR6_D67

#define	TP7				PDR7_P70
#define	TMS				PDR7_P71
#define	TDO				PDR7_P72
#define	TDI				PDR7_P73
#define	TCK				PDR7_P74
#define	RST_CARD_	PDR7_P75
#define	CMD_D			PDR7_P76
#define	CMD_C			PDR7_P77

#define	PORT_TP7				DDR7_D70
#define	PORT_TMS				DDR7_D71
#define	PORT_TDO				DDR7_D72
#define	PORT_TDI				DDR7_D73
#define	PORT_TCK				DDR7_D74
#define	PORT_RST_CARD_	DDR7_D75
#define	PORT_CMD_D			DDR7_D76
#define	PORT_CMD_C			DDR7_D77

#define	MUX_EN_KL					PDR8_P80
#define	MUX_EN_J1850			PDR8_P81
#define	MUX_EN_CAN				PDR8_P82
#define	MUX_EN_485				PDR8_P83
#define	STEP_UP_DISABLE		PDR8_P84
#define	STEP_DOWN_DISABLE PDR8_P85
#define	LED_BICOLOR1			PDR8_P86
#define	LED_BICOLOR2			PDR8_P87

#define	PORT_MUX_EN_KL					DDR8_D80
#define	PORT_MUX_EN_J1850				DDR8_D81
#define	PORT_MUX_EN_CAN					DDR8_D82
#define	PORT_MUX_EN_485					DDR8_D83
#define	PORT_STEP_UP_DISABLE		DDR8_D84
#define	PORT_STEP_DOWN_DISABLE	DDR8_D85
#define	PORT_LED_BICOLOR1				DDR8_D86
#define	PORT_LED_BICOLOR2				DDR8_D87

#define	INT1UART		PDR9_P90
#define	INT2UART		PDR9_P91
#define	INTUSB			PDR9_P92
#define	TP8					PDR9_P93
#define	CAN_TX			PDR9_P94
#define	CAN_RX			PDR9_P95
#define	USB_SUSPEND	PDR9_P96
#define	AT_RST_			PDR9_P97

#define	PORT_INT1UART			DDR9_D90
#define	PORT_INT2UART			DDR9_D91
#define	PORT_INTUSB				DDR9_D92
#define	PORT_TP8					DDR9_D93
#define	PORT_CAN_TX				DDR9_D94
#define	PORT_CAN_RX				DDR9_D95
#define	PORT_USB_SUSPEND	DDR9_D96
#define	PORT_AT_RST_			DDR9_D97

#define		COM_ACT		PDRA_PA0
#define   DEBUG_LED PDRA_PA0

#define		PORT_COM_ACT	DDRA_DA0

// Hardware7 IO defines

#define	ALE			PDR3_P30
#define	RD_			PDR3_P31
#define	WRL_		PDR3_P32
#define	WRH_		PDR3_P33
#define	READYCF	PDR3_P34
#define	CMD_A		PDR3_P35
#define	CMD_B		PDR3_P36
#define	CLK			PDR3_P37

#define	PORT_ALE			DDR3_D30
#define	PORT_RD_			DDR3_D31
#define	PORT_WRL_			DDR3_D32
#define	PORT_WRH_			DDR3_D33
#define	PORT_READYCF	DDR3_D34
#define	PORT_CMD_A		DDR3_D35
#define	PORT_CMD_B		DDR3_D36
#define	PORT_CLK			DDR3_D37

#define	S0_TX			PDR4_P40
#define	SCK_EXT0	PDR4_P41
#define	S0_RX			PDR4_P42
#define	S1_RX			PDR4_P43
#define	SCK_EXT1	PDR4_P44
#define	S1_TX			PDR4_P45
#define	EN_485		PDR4_P46
#define	RESUART		PDR4_P47

#define	PORT_S0_TX		DDR4_D40
#define	PORT_SCK_EXT0	DDR4_D41
#define	PORT_S0_RX		DDR4_D42
#define	PORT_S1_RX		DDR4_D43
#define	PORT_SCK_EXT1	DDR4_D44
#define	PORT_S1_TX		DDR4_D45
#define	PORT_EN_485		DDR4_D46
#define	PORT_RESUART	DDR4_D47

#define	MUX_ENABLE	PDR5_P50
#define	INT4				PDR5_P51
#define	INT5				PDR5_P52
#define	INT6				PDR5_P53
#define	INT7				PDR5_P54

#define	DRV_K_SP_ECU	PDR5_P55
#define	DRV_K_L_AMICO	PDR5_P56

#define	GLB_CLR_CPLD	PDR5_P57

#define	PORT_MUX_ENABLE	DDR5_D50
#define	PORT_INT4				DDR5_D51
#define	PORT_INT5				DDR5_D52
#define	PORT_INT6				DDR5_D53
#define	PORT_INT7				DDR5_D54

#define	PORT_DRV_K_SP_ECU		DDR5_D55
#define	PORT_DRV_K_L_AMICO	DDR5_D56

#define	PORT_GLB_CLR_CPLD	DDR5_D57

#define	VBE_CHK		PDR6_P60
#define	CD1_			PDR6_P61
#define	CD2_			PDR6_P62
#define	OBD_AN		PDR6_P63
#define	CAN_SLOPE	PDR6_P64
#define	CAN_STBY	PDR6_P65
#define	CMD_F			PDR6_P66
#define	CMD_E			PDR6_P67

#define	PORT_VBE_CHK		DDR6_D60
#define	PORT_CD1_				DDR6_D61
#define	PORT_CD2_				DDR6_D62
#define	PORT_OBD_AN			DDR6_D63
#define	PORT_CAN_SLOPE	DDR6_D64
#define	PORT_CAN_STBY		DDR6_D65
#define	PORT_CMD_F			DDR6_D66
#define	PORT_CMD_E			DDR6_D67

#define	TP7				PDR7_P70
#define	TMS				PDR7_P71
#define	TDO				PDR7_P72
#define	TDI				PDR7_P73
#define	TCK				PDR7_P74
#define	RST_CARD_	PDR7_P75
#define	CMD_D			PDR7_P76
#define	CMD_C			PDR7_P77

#define	PORT_TP7				DDR7_D70
#define	PORT_TMS				DDR7_D71
#define	PORT_TDO				DDR7_D72
#define	PORT_TDI				DDR7_D73
#define	PORT_TCK				DDR7_D74
#define	PORT_RST_CARD_	DDR7_D75
#define	PORT_CMD_D			DDR7_D76
#define	PORT_CMD_C			DDR7_D77

#define	R_2R_A						PDR8_P80
#define	R_2R_B						PDR8_P81
#define	R_2R_C						PDR8_P82
#define	R_2R_D						PDR8_P83
#define	HW7_DETECT				PDR8_P84
#define	STEP_DOWN_DISABLE	PDR8_P85
#define	LED_BICOLOR1			PDR8_P86
#define	LED_BICOLOR2			PDR8_P87

#define	PORT_R_2R_A							DDR8_D80
#define	PORT_R_2R_B							DDR8_D81
#define	PORT_R_2R_C							DDR8_D82
#define	PORT_R_2R_D							DDR8_D83
#define	PORT_HW7_DETECT					DDR8_D84
#define	PORT_STEP_DOWN_DISABLE	DDR8_D85
#define	PORT_LED_BICOLOR1				DDR8_D86
#define	PORT_LED_BICOLOR2				DDR8_D87

#define	INT1UART				PDR9_P90
#define	INT2UART				PDR9_P91
#define	INTUSB					PDR9_P92
#define	TP8							PDR9_P93
#define	CAN_TX					PDR9_P94
#define	CAN_RX					PDR9_P95
#define	USB_SUSPEND			PDR9_P96
#define	COM_VOLT_SELECT	PDR9_P97

#define	PORT_INT1UART					DDR9_D90
#define	PORT_INT2UART					DDR9_D91
#define	PORT_INTUSB						DDR9_D92
#define	PORT_TP8							DDR9_D93
#define	PORT_CAN_TX						DDR9_D94
#define	PORT_CAN_RX						DDR9_D95
#define	PORT_USB_SUSPEND			DDR9_D96
#define	PORT_COM_VOLT_SELECT	DDR9_D97

#define	COM_ACT		PDRA_PA0
#define DEBUG_LED	PDRA_PA0

#define	PORT_COM_ACT	DDRA_DA0


#define LED_BICOLOR_RED 	LED_BICOLOR1
#define LED_BICOLOR_GREEN	LED_BICOLOR2


//------------------------------------------------------------------------------
// Prototypes

extern __far void HwInit();            // Written in "HW.c"
void Bicolor_led_manager(void);        // Written in "HW.c"


#endif                                 // End "ifndef" including this Header once
