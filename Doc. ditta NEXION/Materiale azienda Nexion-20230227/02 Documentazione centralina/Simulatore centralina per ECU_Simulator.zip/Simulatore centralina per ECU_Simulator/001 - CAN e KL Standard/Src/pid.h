#include "stdint.h"
//------------------------------------------------------------------------------
// HEADING

// PROJECT NAME:     Sis_NNN.prj/Sis_RAM_NNN.prj
// PROJECT RELEASE:  VIEW HEADING OF "sistema.c"
// FILE NAME:        pid.h
// FILE RELEASE:     1.0
// DATE:             February 2004
// FILE DESCRIPTION: In this file are defined the prototipe for the Prodedure focused 
//					 on the management of PID.	
//                   
// REVIEW  BY:       Ing. Andrea Acunzo - Ing. Diego Mainardi
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// FURTHER INFORMATIONS


//------------------------------------------------------------------------------
// COMPILER DIRECTIVE

#ifndef PID_H            // To include this Header once and
#define PID_H            // avoiding extra compilation
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// COMPILER DIRECTIVE

#include "sistema.h"

//------------------------------------------------------------------------------

// This Procedure initializate the PID setting the byte value that discriminate 
// the questions for Parameters/Status. 
extern __far void InitPid (void);


// This Procedure initializate the PIDs step by step 
extern __far void AbilPid(uint8_t _point_value,BOOL _param_stati, BOOL _en_dis);

//This Procedure initializate all the PIDs 
extern __far void AbilTutto(BOOL _en_dis,BOOL _param_stati);

// ** This Procedure initializate the PIDs step by step 
extern __far void AbilitaPid_Abilitati(BOOL _en_dis);

//extern int16_t tot_domande;


#endif // End "ifndef" including this Header once
