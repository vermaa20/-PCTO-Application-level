#include "stdint.h"

// ------------------------------------------------------------------------
//  MAIN.C
//  - description
//  - See README.TXT for project description and disclaimer.
//
// ------------------------------------------------------------------------



#include "typedefs.h"
#include "serial.h"
#include "hw.h"
#include "time.h"
#include "vectors.h"
#include "sispcinterf.h"
#include "mux_low_level.h"
// START DA SISTEMA.C
#include "sistema.h"
#include "types.h"

//#include "can.h"
// STOP  DA SISTEMA.C

#ifndef ACCEMIC_ON
	#ifdef	EMULATOR_ON
		#include "ram_code.h"
	#endif
#endif

// ------------------------------------------------------------------------
// FUNCTION PROTOTYPES
void ObdSystem (void);

extern __far void RxCan0(void); /* 11 CAN #0 (receive complete)    */
extern __far void TxCan0(void); /* 12 CAN #0 (Transmission complete)    */
// ---------------- DECLARATION AREA ----------------------------------------------


int16_t protocolLenghtType;

#define CRLF "\r\n"

program_serial_com_struct *p_program_serial_port;
//uint8_t monitor_line;

uint8_t analizza_risposta_from_ECU();
void InitCAN();

void wait(uint16_t time) // in msec
{
	uint16_t appo;

	ResetOrol(&appo);
	while (GetTime(&appo) < time);
}


// REDIRECTS IRQs AND FUNCTIONS
__far void init_function_table()
{
#ifdef EMULATOR_ON
	reset_function_table();														// resets all vecotrs
	redirect_function_table((int32_t)&vect022, (int32_t *)PPG0_IRQHandler);			// timer irq
#endif

	redirect_function_table((int32_t)&vect015, (int32_t *)Duart_1_2);					// Duart irq
//	redirect_function_table((int32_t)&vect022, (int32_t *)PPG0_IRQHandler);			// timer irq
	redirect_function_table((int32_t)&vect037, (int32_t *)RxSer0);					// s0rx irq
	redirect_function_table((int32_t)&vect038, (int32_t *)TxSer0);					// s0tx irq
	#ifndef ACCEMIC_ON
		redirect_function_table((int32_t)&vect039, (int32_t *)RxSer1);					// s1rx irq
		redirect_function_table((int32_t)&vect040, (int32_t *)TxSer1);					// s1tx irq
	#endif

	// Mt030107LC Aggiunti per gestione can
	redirect_function_table((int32_t)&vect011, (int32_t *)RxCan0);					// can
	redirect_function_table((int32_t)&vect012, (int32_t *)TxCan0);					// can
	// /Mt030107LC

}


// ********************************************
//
// ------------------------------------- M A I N -------------------------


//---------------------------------------------------------------


tipo_ECU ECU;
//---------------------------------------------------------------

uint8_t MsgBuf[32] = "-------";
uint8_t MsgBuf2[34];
uint8_t quanti_from_ECU;
uint16_t timer_generico;

//--------------------------------------------------------------------------------
// com_pc: - seriale di comunicazione col PC
uint8_t   rx_com_pc[200];
uint8_t   tx_com_pc[200];
uint8_t   eorx_com_pc;
uint8_t 	eotx_com_pc, indice_tx_com_pc;
uint16_t  timer_com_pc;
uint16_t  timeout_com_pc = 50;  // 20	// ms - rivedere con centinaia di usec per i 115200
//---------------------------------------------------------------------------------

//---------------------------------------------------------------------------------
// com_et: - seriale di comunicazione con la ECU per la linea K
uint8_t   rx_com_et[200];
uint8_t   tx_com_et[200];
uint8_t   eorx_com_et;
uint8_t 	eotx_com_et, indice_tx_com_et;
uint16_t  timer_rx_intrabyte_com_et;
uint16_t  timer_tx_intrabyte_com_et;
uint16_t	timer_rx_frame_com_et;
uint16_t  timer_attivazione;
uint16_t  timer_tester_present;


extern 	uint8_t can_pack_tx[8];
extern 	uint8_t can_pack_rx[8];
extern	uint8_t can_num;

#define LENGHT_RX_CAN_BUFFER 	160		//lunghezza del buffer di ricezione
extern uint8_t rx_can_buffer[LENGHT_RX_CAN_BUFFER];	//buffer in cui salvo tutte le risposte consecutive
												//per una stessa domanda, considero al massimo 20 consecutive
extern BYTE count_rx_buffer;	//contatore per il buffer di ricezione

//---------------------------------------------------------------------------------

//---------------------------------------------------------------------------------


#define NULL 			0

#define NIENTE_DA_FARE 	0
#define SET_PROTOCOL 	1
#define START_STOP 		2
#define TX_FRAME		3
#define RESET 			4

#define OK				0x80
#define NON_OK			0x7F
#define TIMEOUT			0x81

#define START			0x01
#define STOP			0x00

#define WAIT			0x00
#define DONT_WAIT		0x01

#define KEYWORD_2000_KL		0x00
#define KEYWORD_2000_CAN	0x01
#define FAST				0x00
#define SLOW				0x01
//-----------------------------------------------------------------
#define debug_led PDRA_PA0

#define DUART_THRE_2_EMPTY			0x20
#define DUART_TEMT_2_EMPTY			0x40

//-----------------------------------------------------------------
void abilita_tx_com_pc(void)
{
		DUART_FIFOCTRL_1 = 0x00;
		DUART_IRQENABLE_1 = 0x03;
		ENIR_EN0 = 1;
}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
void abilita_tx_com_et(void)
{
	#ifdef ACCEMIC_ON
	    DUART_FIFOCTRL_2 = 0x00;
		DUART_IRQENABLE_2 = 0x03;
		ENIR_EN1 = 1;
	#else
	    SCR1_TXE = 1;	// tx enable
		SCR1_RXE = 1;	// tx enable
		SSR1_RIE = 1;	// rx int16_t. enable
		SSR1_TIE = 1;	// tx int16_t. enable
	#endif
}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
void azzera_CAN_pack_tx()
{
	uint8_t index;
	for (index = 0; index < 8; index++)
	{
		can_pack_tx[index] = 0x00;
	}
}
//-----------------------------------------------------------------



void risposta_com_pc(uint8_t tipo)
{
   uint8_t cksum, indice;

   //-----------------------------------------------------
   eotx_com_pc 	    = 0;
   indice_tx_com_pc  = 0;
   //-----------------------------------------------------

   //-----------------------------------------------------
   tx_com_pc[eotx_com_pc++] = 0x5B;
   tx_com_pc[eotx_com_pc++] = 0x00;
   tx_com_pc[eotx_com_pc++] = 0x07;
   tx_com_pc[eotx_com_pc++] = rx_com_pc[3];
   tx_com_pc[eotx_com_pc++] = rx_com_pc[4] + 0x40;
   tx_com_pc[eotx_com_pc++] = tipo;
   //-----------------------------------------------------

   //-----------------------------------------------------
   if (quanti_from_ECU != 0)
   {

   //anto
   	  if (ECU.type == 0)
   	  {
      		if (protocolLenghtType == 0)
      		{
      			indice = 4;
      		}
      		else
      		{
      			indice = 3;
      		}
   	  }
   	  else
   	  {
   	  		indice = 0;
   	  }
      while (quanti_from_ECU-- > 0)
   	     tx_com_pc[eotx_com_pc++] = rx_com_et[indice++];
   }
   //-----------------------------------------------------

   tx_com_pc[2] = eotx_com_pc + 1;

   //-----------------------------------------------------
   cksum = 0;
   for (indice = 0; indice < eotx_com_pc; indice++)
   {
      cksum ^= tx_com_pc[indice];
   }
   tx_com_pc[eotx_com_pc++] = cksum;
   //-----------------------------------------------------


   //-----------------------------------------------------
   while (indice_tx_com_pc != eotx_com_pc)
   {
   		abilita_tx_com_pc();

   }
   //-----------------------------------------------------
}
//-----------------------------------------------------------------


void risposta_com_pc_CAN(uint8_t tipo)
{
   uint8_t cksum, indice = 0;

   //-----------------------------------------------------
   eotx_com_pc 	    = 0;
   indice_tx_com_pc  = 0;
   //-----------------------------------------------------

   //-----------------------------------------------------
   tx_com_pc[eotx_com_pc++] = 0x5B;
   tx_com_pc[eotx_com_pc++] = 0x00;
   tx_com_pc[eotx_com_pc++] = 0x07;
   tx_com_pc[eotx_com_pc++] = 0xA5;
   tx_com_pc[eotx_com_pc++] = 0x5A;
   tx_com_pc[eotx_com_pc++] = OK;

   //-----------------------------------------------------

   //-----------------------------------------------------
   if (quanti_from_ECU != 0)
   {
      while (quanti_from_ECU-- > 0)
   	     tx_com_pc[eotx_com_pc++] = rx_com_et[indice++];
   }
   //-----------------------------------------------------

   tx_com_pc[2] = eotx_com_pc + 1;

   //-----------------------------------------------------
   cksum = 0;
   for (indice = 0; indice < eotx_com_pc; indice++)
   {
      cksum ^= tx_com_pc[indice];
   }
   tx_com_pc[eotx_com_pc++] = cksum;
   //-----------------------------------------------------


   //-----------------------------------------------------
   while (indice_tx_com_pc != eotx_com_pc)
   {
   		abilita_tx_com_pc();

   }
   //-----------------------------------------------------
}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
//M.M.
//invia un dato ricevuto al pc come se fosse una risposta al comando TxFrame
void invia_pacchetto_pc(uint8_t* buf, int16_t buf_len)
{
   uint8_t cksum, indice;

   //-----------------------------------------------------
   eotx_com_pc 	    = 0;
   indice_tx_com_pc  = 0;
   //-----------------------------------------------------


   //-----------------------------------------------------
   tx_com_pc[eotx_com_pc++] = 0x5B;
   tx_com_pc[eotx_com_pc++] = 0;
   tx_com_pc[eotx_com_pc++] = buf_len & 0x00FF;
   tx_com_pc[eotx_com_pc++] = 0x30;
   tx_com_pc[eotx_com_pc++] = 0x32 + 0x40;
   tx_com_pc[eotx_com_pc++] = OK;
   //-----------------------------------------------------

   //-----------------------------------------------------

	 indice = 0;
	 while (buf_len-- > 0)
	 		tx_com_pc[eotx_com_pc++] = buf[indice++];

   //-----------------------------------------------------
   //LEN L
   
   tx_com_pc[1] = ((eotx_com_pc + 1)&0x00FF00)>>8;
   tx_com_pc[2] = (eotx_com_pc + 1)&0x00FF;

   //-----------------------------------------------------
   cksum = 0;
   for (indice = 0; indice < eotx_com_pc; indice++)
   {
      cksum ^= tx_com_pc[indice];
   }
   tx_com_pc[eotx_com_pc++] = cksum;
   //-----------------------------------------------------

   //-----------------------------------------------------
   while (indice_tx_com_pc != eotx_com_pc)
   		abilita_tx_com_pc();
   //-----------------------------------------------------
}
//-----------------------------------------------------------------
uint8_t attivazione(void)
{
	uint16_t ActTimeout;
	uint8_t result;
	uint8_t cksum;
	uint8_t indice;
	static int16_t fase_act;
	result = OK;
	quanti_from_ECU = 0;


	if (ECU.type == 0)
	// KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL
	{
		wait (300);

		if (ECU.activation_type == FAST)
		// attivazione FAST
		{
			//SetBaudRate(1, ECU.baud_rate);	
			return OK;
			/*
			#ifdef ACCEMIC_ON
	   			SetBaudRate(3, 361);		// 361
	   		
	    		indice_tx_com_et = 0;
	    		eotx_com_et 		= 1;
	    		tx_com_et[0] = 0x00;        // 0x00;
				while (indice_tx_com_et != eotx_com_et)
   					abilita_tx_com_et();
   				while (!(DUART_LINESTATUS_2 & DUART_TEMT_2_EMPTY));
   				wait(20);
   				
				SetBaudRate(3, ECU.baud_rate);
	    	#else
	    	
				Attiva_Fast(1);
				
				while (Attiva_Fast(0) != ENDOK);
				SetBaudRate(1, ECU.baud_rate);
				
			#endif

			eotx_com_et = 0;

			tx_com_et[eotx_com_et++] 	= 0x81;//0b10000000;		//format byte												//indirizzi fisici												//byte di lunghezza
			tx_com_et[eotx_com_et++]	= ECU.activation_address;
			tx_com_et[eotx_com_et++]  = ECU.source_address;
			tx_com_et[eotx_com_et++]  = 0x81;

			cksum = 0;
			for (indice = 0; indice < eotx_com_et; indice++)
				cksum += tx_com_et[indice];
			tx_com_et[eotx_com_et++]  = cksum;

			indice_tx_com_et = 0;
			while (indice_tx_com_et != eotx_com_et)
   				abilita_tx_com_et();

        	#ifdef ACCEMIC_ON
  	    		while (!(DUART_LINESTATUS_2 & DUART_TEMT_2_EMPTY));
        	#endif

			wait (5);

			eorx_com_et = 0; //cancello l'echo!
			ResetOrol (&timer_rx_frame_com_et);
			ResetOrol (&timer_rx_intrabyte_com_et);
			while (eorx_com_et == 0)
			{
				if (GetTime(&timer_rx_frame_com_et) > ECU.timeout_frame)
				{
					quanti_from_ECU = 0;
					return NON_OK;
				}
			}
			while (1)
			{
				if (eorx_com_et > 3)
				{
					if (eorx_com_et == 7)
					{
						result = analizza_risposta_from_ECU();
						if (result == OK)
						{
							ECU.KeyByte1 = rx_com_et[5];
							ECU.KeyByte2 = rx_com_et[6];
						}
						return result;
					}
				}
				if (GetTime(&timer_rx_intrabyte_com_et) > ECU.intrabyte_timeout_ecu)
				{
					return NON_OK;
				}
			}*/
		}
		else
		// attivazione SLOW
		{
			SetBaudRate(1, 5);
			eotx_com_et 		= 0;
      indice_tx_com_et = 0;
      
      ResetOrol(&ActTimeout);
	    //eorx_com_et =0;
	    
	    while(GetTime(&ActTimeout)<250)
	    	if(eorx_com_et>0) break;
			
			if(eorx_com_et == 1)
			{
				debug_led = 0x00;	
				eorx_com_et=0;
				if(rx_com_et[0]==ECU.activation_address)
				//if(1)
				{
					//ricevuto indirizzo
					SetBaudRate(1, ECU.baud_rate);	
					
					tx_com_et[eotx_com_et++] = ECU.SyncByte;
					tx_com_et[eotx_com_et++] = ECU.KeyByte1;
					tx_com_et[eotx_com_et++] = ECU.KeyByte2;
					ResetOrol(&timer_tx_intrabyte_com_et);
					while (indice_tx_com_et != eotx_com_et)
   		      abilita_tx_com_et();
   		    
   		    //aspetto KB2 complementato 
   		    eorx_com_et-=eotx_com_et;
   		    
   		    wait(30);
   		    
   		    ResetOrol(&ActTimeout);
   		    while(GetTime(&ActTimeout)<30)
   		    	if(eorx_com_et>0) break;
   		    
   		    if(eorx_com_et==0) return NON_OK;
   		    
   		    //ricevuto KB2 complementato
   		    if(rx_com_et[0] != (0xff-ECU.KeyByte2)) return NON_OK;
   		    
   		    eorx_com_et =0;
   		    
   		    eotx_com_et 		= 0;
     			indice_tx_com_et = 0;
   		    tx_com_et[eotx_com_et++] = (0xff - ECU.activation_address);
					ResetOrol(&timer_tx_intrabyte_com_et);
					while (indice_tx_com_et != eotx_com_et)
   		      abilita_tx_com_et();
   		      
   		    eorx_com_et-=eotx_com_et; 
   		    return OK;
				}			
			}
			return NON_OK;
		}
	}
	// KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL
	else
	// CAN CAN  CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN
	{
		result = OK;
	}
	// CAN CAN  CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN

	return result;
}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
uint8_t analizza_risposta_from_ECU()
{
    uint8_t cksum;
    uint8_t result;
    uint8_t indice;

    cksum = 0;
	for (indice = 0; indice < eorx_com_et - 1; indice++)
	{
		cksum = cksum + rx_com_et[indice];
	}

	if (cksum != rx_com_et[eorx_com_et - 1])
		return NON_OK;
	else
		return OK;
}
//-----------------------------------------------------------------
//verifica la presenza di un dato e lo inoltra al PC
//ritorna OK se ha ricevuto, NON_OK altrimenti
//M.M.
int16_t rx_frame()
{

	if (ECU.type == 0)
		return Rx_KL();
	else
		return Rx_CAN();
}

//verifica la presenza di un dato da KL e lo inoltra al PC
//ritorna OK se ha ricevuto, NON_OK altrimenti
//M.M.
int16_t Rx_KL()
{
	uint8_t old_eorx_com_et=0;
	uint16_t timer_rx_kl=0;
	//eorx_com_et = 0;

	ResetOrol (&timer_rx_frame_com_et);
	ResetOrol (&timer_rx_intrabyte_com_et);
	//controllo timeout risposta


	if (eorx_com_et > 0)
	{
		ResetOrol(&timer_rx_kl);
		debug_led = ~debug_led;
		do{
			if(old_eorx_com_et < eorx_com_et) //ricevuto qualcolsa
			{
				old_eorx_com_et = eorx_com_et;
				ResetOrol(&timer_rx_kl);
				}
			}
		while(GetTime(&timer_rx_kl) < ECU.intrabyte_timeout_ecu);

		quanti_from_ECU = eorx_com_et;
		if(eorx_com_et>1)
			invia_pacchetto_pc(rx_com_et,eorx_com_et);
		eorx_com_et =0;
		return OK;
	}
	return NON_OK;
}

//-----------------------------------------------------------------
//verifica la presenza di un pacchetto da CAN e lo inoltra al PC
//ritorna OK se ha ricevuto, NON_OK altrimenti
//M.M.
int16_t Rx_CAN()
{
	int16_t indice, result = OK;
	
  //ResetRx();

  ResetOrol (&timer_rx_frame_com_et);
  // qui debbo analizzare la risposta e metterla nel pacchetto verso il PC

 	 if (can_num != 0)
  {
    //invio al PC
    eorx_com_et = 0;

   	invia_pacchetto_pc(rx_can_buffer,count_rx_buffer);
        
    ResetRx();
  	return OK;
	}
  return NON_OK;
}


//-----------------------------------------------------------------

//invia il dato sulla linea approppriata
//M.M.
uint8_t trasmissione_ECU()
{
	uint8_t result, indice, cksum, sn, prima, appoggio_can_num, quanti, indice_2, n_byte;
	int16_t indiceAnto, indice_can_rx;
	int16_t ll;
	result = OK;
	cksum  = 0;


	if (ECU.type == 0)
	// KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL
	{
		// composizione della domanda alla ECU
		eotx_com_et   			= 0;

	// invio il pacchetto ricevuto dal pc
		//tx_com_et[eotx_com_et++] 	= 0x80;//0b10000000;		//format byte														//indirizzi fisici												//byte di lunghezza
		//tx_com_et[eotx_com_et++]	= ECU.target_address;
		//tx_com_et[eotx_com_et++]  = ECU.source_address;
		//tx_com_et[eotx_com_et++]  = 0;						// length da mettere a posto

		for (indice = 6; indice < eorx_com_pc - 1; indice++)
				tx_com_et[eotx_com_et++]  =  rx_com_pc[indice];

		//tx_com_et[3]  = eotx_com_et + 1 - 5;

		cksum = 0;
		//for (indice = 0; indice < eotx_com_et; indice++)
			//	cksum += tx_com_et[indice];
		//tx_com_et[eotx_com_et++]  = cksum;

		// fine composizione della domanda alla ECU

		// trasmissione della domanda alla ECU
		eorx_com_et=0;
		indice_tx_com_et = 0;
		while (indice_tx_com_et != eotx_com_et)
   			abilita_tx_com_et();
   		// fine trasmissione della domanda alla ECU
   		
   	//elimino "l'eco"	
   	eorx_com_et-=eotx_com_et;

		#ifdef ACCEMIC_ON
    		while (!(DUART_LINESTATUS_2 & DUART_TEMT_2_EMPTY));
    	#endif

		//wait (2);

		//acc_MessageBox(( uint8_t*)"HO TRASMESSO!!!!",MB_OKCANCEL,MsgBuf);

		quanti_from_ECU = 0;


		{
			quanti_from_ECU = 0;
			result = OK;
		}
	// KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL
	}
	else
	// CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN
	{
			quanti = eorx_com_pc - 7 - 4 -1; //5 header + 2 cks + 4 byte ID-CAN + byte da trasmettere
			
			n_byte = rx_com_pc[10];
			
			//if(quanti>8)
				//return NON_OK;
			/*	
			ECU.id_domanda = 0;
			
			for(indice_can_rx = 6, indice =0;indice < 4;indice++, indice_can_rx++)
			{
				ECU.id_domanda<<=8;	
				//ECU.id_domanda |= rx_com_pc[6+indice];
				ECU.id_domanda |= rx_com_pc[indice_can_rx];
			}
			*/
			ECU.id_domanda = 0;
			ECU.id_domanda = (uint32_t)((uint32_t)rx_com_pc[6  ] << 24 ) |
						       (uint32_t)((uint32_t)rx_com_pc[7 ] << 16 ) |
						       (uint32_t)((uint32_t)rx_com_pc[8 ] << 8  ) |
						       (uint32_t)((uint32_t)rx_com_pc[9 ]       );
			
			//imposto il nuovo ID di trasmissione
			CAN0_buffer6();
		
		
			for (indice_can_rx = 6+4+1, indice = 0; indice < quanti; indice++, indice_can_rx++)
				//can_pack_tx[indice] = rx_com_pc[6 + 4 + indice];
				can_pack_tx[indice] = rx_com_pc[indice_can_rx];
				
			for(;indice<8;indice++)
				can_pack_tx[indice]=0;	

			PutPackCan(n_byte);
			}
	
	// CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN CAN
	return result;
}


//-----------------------------------------------------------------

//-----------------------------------------------------------------
void set_protocol(void)
{
	uint8_t indice;
	uint8_t result;

	uint8_t app1,app2,app3,app4;//anto
	// qui va fatta l'analisi del pacchetto dati contenente le informazioni
	// sul protocollo verso la ECU
	//-----------------------------------------------------------------

	result = OK;

	ECU.type 		= rx_com_pc[5 + 0];
	if (ECU.type == 0)
	// KWP2000 - KL  -------------------------------------------------------------
	{
		ECU.baud_rate 	= (rx_com_pc[5 + 1] << 24) |
						  (rx_com_pc[5 + 2] << 16) |
						  (rx_com_pc[5 + 3] << 8 ) |
						  (rx_com_pc[5 + 4]      );
		ECU.start_bit = rx_com_pc[5 + 5];
		ECU.stop_bit  = rx_com_pc[5 + 6];
		ECU.parity    = rx_com_pc[5 + 7];
		ECU.n_bit 	  = rx_com_pc[5 + 8];
    ECU.activation_type = rx_com_pc[5 + 9];
    ECU.activation_address = rx_com_pc[5 + 10];
		ECU.target_address  = rx_com_pc[5 + 11];
		ECU.source_address  = rx_com_pc[5 + 12];
		ECU.intrabyte_tx    = (rx_com_pc[5 + 13] << 8) |
							  (rx_com_pc[5 + 14]);
		ECU.intrabyte_timeout_ecu    =  (rx_com_pc[5 + 15] << 8) |
							  			(rx_com_pc[5 + 16]);
		ECU.timeout_frame    		 =  (rx_com_pc[5 + 17] << 8) |
							            (rx_com_pc[5 + 18]);
		ECU.timeout_ecu    			 =  (rx_com_pc[5 + 19] << 8) |
							  			(rx_com_pc[5 + 20]);
		// tester present pari a 3/4 del timeout?
		ECU.tester_present = (ECU.timeout_ecu * 3) / 4;

		ECU.SyncByte = rx_com_pc[5 + 21];
		ECU.KeyByte1 = rx_com_pc[5 + 22];
		ECU.KeyByte2 = rx_com_pc[5 + 23];
		
		//----------------------------------------------------------------
		ECU.quanti_tester_present = rx_com_pc[5+50+1];
		for (indice = 0; indice < ECU.quanti_tester_present; indice++)
			ECU.buffer_tester_present[indice] = rx_com_pc[5+51 + indice + 1];
		//----------------------------------------------------------------

		//----------------------------------------------------------------
		ECU.quanti_risposta_tester_present = rx_com_pc[5+71 + 1];
		for (indice = 0; indice < ECU.quanti_risposta_tester_present; indice++)
			ECU.buffer_risposta_tester_present[indice] = rx_com_pc[5+72 + indice + 1];
		
		
		if(ECU.activation_type == FAST)
			SetBaudRate(1, ECU.baud_rate);
		else
			SetBaudRate(1, 5);
		
		
		//-----------------------------------------------------------------

		//-----------------------------------------------------------------
		//-----------------------------------------------------------------
	}
	//---------------------------------------------------------------------
	else
	// KWP2000 - CAN  ------------------------------------------------------------
	{
		ECU.baud_rate 		= ((uint32_t)((uint32_t)rx_com_pc[5 + 1] << 24)) +
						  	  ((uint32_t)((uint32_t)rx_com_pc[5 + 2] << 16)) +
						  	  ((uint32_t)((uint32_t)rx_com_pc[5 + 3] << 8 )) +
						      ((uint32_t)((uint32_t)rx_com_pc[5 + 4]      ));

		if (ECU.baud_rate != 20000)
		 if (ECU.baud_rate != 25000)
		  if (ECU.baud_rate != 30000)
		   if (ECU.baud_rate != 33000)
		    if (ECU.baud_rate != 33300)
		     if (ECU.baud_rate != 50000)
		      if (ECU.baud_rate != 83300)
		       if (ECU.baud_rate != 95000)
		        if (ECU.baud_rate != 100000)
		         if (ECU.baud_rate != 125000)
		          if (ECU.baud_rate != 200000)
		           if (ECU.baud_rate != 250000)
		            if (ECU.baud_rate != 333300)
		             if (ECU.baud_rate != 500000)
		              if (ECU.baud_rate != 1000000)
		              	result = NON_OK;




		ECU.id_length 		=  rx_com_pc[5 + 6];
		ECU.source_address 	=  rx_com_pc[5 + 7];
		ECU.target_address 	=  rx_com_pc[5 + 8];

		ECU.id_domanda 		=  (uint32_t)((uint32_t)rx_com_pc[5 + 9  ] << 24 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 10 ] << 16 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 11 ] << 8  ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 12 ]       );


		ECU.id_risposta		=  (uint32_t)((uint32_t)rx_com_pc[5 + 13 ] << 24 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 14 ] << 16 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 15 ] << 8  ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 16 ]       );
		
		ECU.quanti_filters  =  rx_com_pc[5 + 17];

		ECU.filters[0]		=  (uint32_t)((uint32_t)rx_com_pc[5 + 18 ] << 24 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 19 ] << 16 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 20 ] << 8  ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 21 ]       );

		ECU.filters[1]		=  (uint32_t)((uint32_t)rx_com_pc[5 + 22 ] << 24 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 23 ] << 16 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 24 ] << 8  ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 25 ]       );

		ECU.filters[2]		=  (uint32_t)((uint32_t)rx_com_pc[5 + 26 ] << 24 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 27 ] << 16 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 28 ] << 8  ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 29 ]       );

		ECU.filters[3]		=  (uint32_t)((uint32_t)rx_com_pc[5 + 30 ] << 24 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 31 ] << 16 ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 32 ] << 8  ) |
						       (uint32_t)((uint32_t)rx_com_pc[5 + 33 ]       );


		ECU.timeout_frame    		 =  (rx_com_pc[5 + 34] << 8) |
							            (rx_com_pc[5 + 35]);
		ECU.timeout_ecu    			 =  (rx_com_pc[5 + 36] << 8) |
							  			(rx_com_pc[5 + 37]);

		ECU.tester_present = (ECU.timeout_ecu * 3) / 4;
		ECU.quanti_tester_present = rx_com_pc[5+1+50];
		for (indice = 0; indice < ECU.quanti_tester_present; indice++)
			ECU.buffer_tester_present[indice] = rx_com_pc[5+1+50 + indice + 1];
		//----------------------------------------------------------------
	
		//----------------------------------------------------------------
		ECU.quanti_risposta_tester_present = rx_com_pc[5+1+70  +1];
		for (indice = 0; indice < ECU.quanti_risposta_tester_present; indice++)
			ECU.buffer_risposta_tester_present[indice] = rx_com_pc[5+1+70   +1 + indice + 1];
	//-----------------------------------------------------------------

		//----------------------------------------------------------------
		
		#ifdef ACCEMIC_ON
			imposta_mux(1);			// per il CAN
		#endif

		if (result == OK)
			{
			InitCAN();
			ResetRx();
		}
	}
	

	//---------------------------------------------------------------------

	//-----------------------------------------------------------------
	ECU.settata 		= 1;
	ECU.attivata 		= 0;
	ECU.started			= 0;
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------
	// qui inizializzo la seriale per la comunicazione con la ECU
	/*
	#ifdef ACCEMIC_ON
		SetBaudRate(3, ECU.baud_rate);
	#else
		SetBaudRate(1, ECU.baud_rate);
	#endif
	*/
	//-----------------------------------------------------------------

	//-----------------------------------------------------------------
	quanti_from_ECU = 0;
	risposta_com_pc(result);
	//-----------------------------------------------------------------
}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
void start_stop(void)
{
	uint8_t result;
	int16_t ctAnto;

	result = OK;
	//-----------------------------------------------------------------
	if (ECU.settata != 1)
	// NON FATTA LA SET PROTOCOL
	{
		result = NON_OK;
	}
	//-----------------------------------------------------------------
	//-----------------------------------------------------------------
	else
	{
	// FATTA LA SET PROTOCOL
		
		//-----------------------------------------------------------------
		if (rx_com_pc[5] == START)
		// COMANDO DI START
		{
			ResetOrol (&timer_attivazione);
			ResetOrol (&timer_tester_present);
			
			if (ECU.type == 1)
			{
				//CAN
				ECU.attivata = 1;
				ECU.started  = 1;
			}
			else
			{
				//KL
				eorx_com_et = 0;
				ECU.started  = 1;
				ECU.attivata = 0;
				/*
					result = attivazione();

					ctAnto=1;
					while ((result != OK)&&(ctAnto<8))
						{
						ctAnto++;
				    	ResetOrol (&timer_tester_present);

						while(GetTime(&timer_tester_present)<500);
						result = attivazione();
						}


					if(result==OK)
						{
						ResetOrol (&timer_attivazione);
				    	ResetOrol (&timer_tester_present);
						ECU.attivata = 1;
						ECU.started  = 1;
						}
					else ECU.started  = 0;

			  */
		   }
	   }
	    
		//-----------------------------------------------------------------
		else if (rx_com_pc[5] == STOP)
		// COMANDO DI STOP
		{
		    if (ECU.type == 0x01)
		    // CAN CAN CAN
		    {
				ECU.started = 0;
				ECU.attivata = 0;
		    }
		    else
		    // KL KL KL
		    {
		    	ECU.started = 0;
		    	ECU.attivata = 0;
		    }
		}
	}
	//-----------------------------------------------------------------
	quanti_from_ECU = 0;
	risposta_com_pc(result);
}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
void tx_frame(void)
{
	uint8_t result;
	result = OK;

	//-----------------------------------------------------------------
	if (ECU.settata != 1)
	// NON FATTA LA SET PROTOCOL
	{
		result = NON_OK;
	}
	//-----------------------------------------------------------------
	//-----------------------------------------------------------------
	else
	{
		//-----------------------------------------------------------------
		if (ECU.attivata != 1)
		{
			result = NON_OK;
		}
		//-----------------------------------------------------------------
		//-----------------------------------------------------------------
		else
		{
			//ECU.started = 1;	// FORZO LO STARTED

			result = trasmissione_ECU();
		}
		//-----------------------------------------------------------------
	}
	//-----------------------------------------------------------------
	//quanti_from_ECU = 0;
	//risposta_com_pc(result);
}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
void reset(void)
{
	eotx_com_pc = 0;

	tx_com_pc[eotx_com_pc++] = 0x5B;   	//0
	tx_com_pc[eotx_com_pc++] = 0x01;	//1
	tx_com_pc[eotx_com_pc++] = 0x20;	//2
	tx_com_pc[eotx_com_pc++] = 0x00;	//3
	tx_com_pc[eotx_com_pc++] = 0x00;	//4
	tx_com_pc[eotx_com_pc++] = 0x0B;	//5
	tx_com_pc[eotx_com_pc++] = 0x62;	//6
	tx_com_pc[eotx_com_pc++] = 0x3F;	//7
	tx_com_pc[eotx_com_pc++] = 0xFF;	//8
	tx_com_pc[eotx_com_pc++] = 0x02;	//9
	tx_com_pc[eotx_com_pc++] = 0x27;	//10

    indice_tx_com_pc = 0;
	while (indice_tx_com_pc != eotx_com_pc)
   		abilita_tx_com_pc();

   wait (50);

   #define FIRMWARE_START_ADDRESS 0x00FE0010L

   	redirect_function_table((int32_t)&vect255, (int32_t *)FIRMWARE_START_ADDRESS);
		((__far void (*)())vect255)();

}
//-----------------------------------------------------------------

//-----------------------------------------------------------------
uint8_t analizza_domanda_com_pc(void)
{
    uint8_t cksum, indice;

    //-----------------------------------------------------------
	if (rx_com_pc[0] != 0x5B)
		return NIENTE_DA_FARE;
    //-----------------------------------------------------------

	//-----------------------------------------------------------
	cksum = 0;
	for (indice = 0; indice < eorx_com_pc - 1; indice++)
	{
		cksum = cksum ^ rx_com_pc[indice];
	}

	if (cksum != rx_com_pc[eorx_com_pc -1])
		return NIENTE_DA_FARE;
    //-----------------------------------------------------------

	//-----------------------------------------------------------
	if (rx_com_pc[3] == 0x30)
	{
		if (rx_com_pc[4] == 0x30)
			return SET_PROTOCOL;
		else if (rx_com_pc[4] == 0x31)
			return START_STOP;
		else if (rx_com_pc[4] == 0x32)
			return TX_FRAME;
		else if (rx_com_pc[4] == 0x33)
			return RESET;
	}
	return NIENTE_DA_FARE;
	//-----------------------------------------------------------
}
//-----------------------------------------------------------------

uint8_t tester_present()
{
    uint8_t indice, eof;
    uint8_t cksum;
    uint8_t result;

    if (ECU.type == 0)
    {
    	eotx_com_et = 0;

		tx_com_et[eotx_com_et++] 	= 0x80;//0b10000000;		//format byte														//indirizzi fisici												//byte di lunghezza
		tx_com_et[eotx_com_et++]	= ECU.target_address;
		tx_com_et[eotx_com_et++]  = ECU.source_address;
		tx_com_et[eotx_com_et++]  = 0;						// length da mettere a posto

    	for (indice = 0; indice < ECU.quanti_tester_present; indice++)
    	{
    		tx_com_et[eotx_com_et++] = ECU.buffer_tester_present[indice];
    	}

		tx_com_et[3]  = eotx_com_et + 1 - 5;

		cksum = 0;

		for (indice = 0; indice < eotx_com_et; indice++)
			cksum += tx_com_et[indice];

		tx_com_et[eotx_com_et++]  = cksum;

		// trasmissione della domanda alla ECU
		indice_tx_com_et = 0;
		while (indice_tx_com_et != eotx_com_et)
   			abilita_tx_com_et();


   		wait (2);


   		//-------------------------------------------
   			if (ECU.quanti_risposta_tester_present == 0)
   				return OK;

   			eorx_com_et = 0;
			ResetOrol (&timer_rx_frame_com_et);
			ResetOrol (&timer_rx_intrabyte_com_et);
			while (eorx_com_et == 0)
			{
				if (GetTime(&timer_rx_frame_com_et) > ECU.timeout_frame)
				{
					return NON_OK;
				}
			}
			while (1)
			{
				if (eorx_com_et > 0)
				{
					if (eorx_com_et == (rx_com_et[0] & 0x7F) + 4)
					{
						result = analizza_risposta_from_ECU();
						if (result == NON_OK)
							return NON_OK;

						for (indice = 0; indice < ECU.quanti_risposta_tester_present; indice++)
						{
							if (rx_com_et[indice + 3] != ECU.buffer_risposta_tester_present[indice])
					  			return NON_OK;
						}
						return OK;
					}
				}
				if (GetTime(&timer_rx_intrabyte_com_et) > ECU.intrabyte_timeout_ecu)
				{
					return NON_OK;
				}
			}
   		//-------------------------------------------
   }
   else
   {
   		if (ECU.id_length == 0)
   		// 11 bit
   		{
   			//--------------------------------------------------------
   			azzera_CAN_pack_tx();
			can_pack_tx[0] = ECU.target_address;
			eof = 1;
			can_pack_tx[eof++] = ECU.quanti_tester_present;
			for (indice = 0; indice < ECU.quanti_tester_present; indice++)
				can_pack_tx[eof++] = ECU.buffer_tester_present[indice];
			//--------------------------------------------------------

			//--------------------------------------------------------
			PutPackCan();
			ResetRx();
			ResetOrol (&timer_rx_frame_com_et);
			while (  ( can_num == 0 ) && ( GetTime(&timer_rx_frame_com_et) <  ECU.timeout_frame)  );
			//--------------------------------------------------------------------

			//--------------------------------------------------------------------
			for (indice = 0; indice < ECU.quanti_risposta_tester_present; indice++)
			{
				if (rx_can_buffer[indice + 2] != ECU.buffer_risposta_tester_present[indice])
					  return NON_OK;
			}
			return OK;
			//--------------------------------------------------------------------
		}
		// 11 bit
		else
		// 29 bit
		{
			//------------------------------------------------------------
   			azzera_CAN_pack_tx();
   			eof = 0;
			can_pack_tx[eof++] = ECU.quanti_tester_present;
			for (indice = 0; indice < ECU.quanti_tester_present; indice++)
				can_pack_tx[eof++] = ECU.buffer_tester_present[indice];
			//--------------------------------------------------------

   			//--------------------------------------------------------
			PutPackCan();
			ResetRx();
			ResetOrol (&timer_rx_frame_com_et);
			while (  ( can_num == 0 ) && ( GetTime(&timer_rx_frame_com_et) <  ECU.timeout_frame)  );
			//--------------------------------------------------------------------

			//--------------------------------------------------------------------
			for (indice = 0; indice < ECU.quanti_risposta_tester_present; indice++)
			{
				if (rx_can_buffer[indice + 1] != ECU.buffer_risposta_tester_present[indice])
					  return NON_OK;
			}
			return OK;
			//--------------------------------------------------------------------
		}
		// 29 bit
   	}
}

//-----------------------------------------------------------------
//M.M.
void ciclo_principale(void)
{
    uint8_t result;
    uint16_t BTime;

    ResetOrol(&BTime);

    eorx_com_pc = 0;
    eotx_com_pc = 0;
    ECU.started = 0;
    ECU.attivata = 0;
    ECU.settata = 0;
    
    debug_led = 0xff;

    for(;;)
    {/*
        if (GetTime(&BTime) > 500)
			{
		    debug_led = ~debug_led; // blink il led vita
		    ResetOrol(&BTime);
			}
*/
				// --------- Controllo ricezione ----------------------------------

				//se ricevo, invio sulla seriale
				//M.M.

				if(ECU.started)
				{
					switch (ECU.type)
					{
						case 0:
							if(ECU.attivata)
								Rx_KL();
							else
								ECU.attivata = (attivazione()==OK)?1:0;						
							break;
						case 1:
							//Rx_CAN();
							if(can_num)
							{
								//quando entra qua can_num � sempre 1!
								can_num =0;	
								while (indice_tx_com_pc != eotx_com_pc)
   								abilita_tx_com_pc();	
							}
							break;
					}
				}
				


        // --------- Controllo caratteri ricevuti dal PC ----------------------------------
    	if (eorx_com_pc)
    	{
    		if(eorx_com_pc == 11 && rx_com_pc[1] == 0x20)
							reset();
							
    		if (rx_com_pc[3] == 0x30)
				{
					switch(rx_com_pc[4])
					{
						case 0x32:
							if (ECU.attivata)
								trasmissione_ECU();
							//tx_frame();
							break;
						case 0x30:
							set_protocol();
							break;
						case 0x31:
							start_stop();
							break;
						case 0x33:
							reset();
							break;
					}
				}				
							
				eorx_com_pc =0;
				
			}
							
		
    		#ifdef NULLITA
    		if (eorx_com_pc > 2)
    		{
    	       if (rx_com_pc[1] == 0x20)
    	       {
    	       	  if (eorx_com_pc == 11)
    	       	  	 if ( (rx_com_pc[5] == 0x0B) && (rx_com_pc[6] == 0x22) && (rx_com_pc[7] == 0x3F) && (rx_com_pc[8] == 0xFF) && (rx_com_pc[9] == 0x01) && (rx_com_pc[10] == 0xE7))
    	       	  	 //if ( (rx_com_pc[9] == 0x01)  )
    	       	  	 {
    	       	  	 	reset();
    	       	  	 }
    	       }
 			   			else
 			   		{

    	          if (eorx_com_pc == /* rx_com_pc[2] */ (  (rx_com_pc[1] << 8) | rx_com_pc[2])     )
    	          {
    	    	  	result = analizza_domanda_com_pc();
    	    	  
    	    	  switch(result)
    	    	  {
    	    			case TX_FRAME:
	    	    			tx_frame();
	    	    			break;
    	    	  	case SET_PROTOCOL:
    	    	  		set_protocol();
    	    	  		break;
    	    			case START_STOP:
    	    				start_stop();
    	    				break;
    	    			case RESET:
    	    				reset();
    	    				break;
    	          }
    	          eorx_com_pc = 0;
               }
			}
    	    if (GetTime(&timer_com_pc) > timeout_com_pc)
    	    {
    	    	eorx_com_pc = 0;
    	    }
    	}
    	#endif
    	//---------------------------------------------------------------------------------
		
   }
}
//-----------------------------------------------------------------

#ifdef ACCEMIC_ON
void imposta_mux(uint8_t tipo)
{
    uint16_t	as_word_a;
	uint16_t	as_word_b;
	uint16_t	dummy_w;
	uint32_t 	mux_ext_cfg;
	uint8_t ind = 0;

	if (tipo == 0)
	{
		// KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL
		const uint16_t	hw7_eobd_pin[16] = {0x0001, 0x0002, 0x0004, 0x0000, 0x0000, 0x0008, 0x0010, 0x0020,
	   								    	0x0040, 0x0080, 0x0100, 0x0200, 0x0400, 0x1000, 0x0800, 0x0000};

		// the following tables are used to set the internal mux in HW7
		// the latches setup is different for BUS+ and BUS-
		const uint16_t	hw7_protocols_a[8] = {0x2000, 0x8000, 0x4000, 0x4000, 0x0000, 0x0000, 0x0000, 0x0000};
		const uint16_t	hw7_protocols_b[8] = {0x2000, 0x0000, 0x0000, 0x0000, 0x4000, 0x0000, 0x8000, 0x0000};
		//----------------------------------------------------------------

    	#define HW7_WRITE_SWITCH_A(_value) (*(WORD __far *)(0xE00000) = (_value))
		#define HW7_WRITE_SWITCH_B(_value) (*(WORD __far *)(0xE40000) = (_value))

		#define		DRV_K_SP_ECU	PDR5_P55

		// MUX Latches status
		#define HW7_MUX_ON		0
		#define HW7_MUX_OFF		1

		#define		HW7_SETUP_KL 		0
		#define		MUX_ENABLE		PDR5_P50

		#define HW7_EXT_MUX_PIN_7		0x40
		#define HW_7_EXT_MUX_PIN_15		0x2000

		// disables the MUX and all the special lines from the CPU
		MUX_ENABLE		= HW7_MUX_OFF;
		DRV_K_SP_ECU	= HW7_MUX_OFF;

		// **************************
		// sets mux for internal BUS+/- to EOBD connector pins
    	mux_ext_cfg = HW7_EXT_MUX_PIN_7 << 16 | HW_7_EXT_MUX_PIN_15;

		// prepares word for switches latch A (BUS+)
		as_word_a = 0x0000;
		for (ind = 0, dummy_w = 0x0001; ind < 16; ind++, dummy_w <<= 1)
		{
			if (dummy_w & (WORD)((mux_ext_cfg >> 16) & 0xFFFFL))
				as_word_a |= hw7_eobd_pin[ind];
		}

		// prepares word for switches latch B
		as_word_b = 0x0000;
		for (ind = 0, dummy_w = 0x0001; ind < 16; ind++, dummy_w <<= 1)
		{
			if (dummy_w & (WORD)(mux_ext_cfg & 0xFFFFL))
				as_word_b |= hw7_eobd_pin[ind];
		}
		// **************************
		as_word_a |= hw7_protocols_a[HW7_SETUP_KL];
		as_word_b |= hw7_protocols_b[HW7_SETUP_KL];

		HW7_WRITE_SWITCH_A(as_word_a ^ 0xFFFF);
		HW7_WRITE_SWITCH_B(as_word_b ^ 0xFFFF);

		// enables the MUX
		MUX_ENABLE = HW7_MUX_ON;
    	//----------------------------------------------------------------
    	// KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL KL
	}
	else
	{
		MUX_ENABLE		= HW7_MUX_OFF;

		DRV_K_SP_ECU	= HW7_MUX_OFF;
									// MSB			   LSB
		as_word_a = 0x8008;  		// 1000 0000 0000 1000
		as_word_b = 0x0800;  		// 0000 1000 0000 0000

		HW7_WRITE_SWITCH_A(as_word_a ^ 0xFFFF);
		HW7_WRITE_SWITCH_B(as_word_b ^ 0xFFFF);

		MUX_ENABLE = HW7_MUX_ON;
	}
}
#endif

void InitCAN()
{
		PDR6 = 0X00;		   // abilitazione CAN
		CAN0_init();			//Inizializzazione CAN0
		CAN0_buffer6();		//Inizializzazione Can0 Buffer6 di trasmissione
		CAN0_buffer1();		//Inizializzazione Can0 Buffer1 di ricezione
}

void main (void)
{
	// local vars
	uint8_t scritto = 0;
	uint8_t letto = 0;
	uint8_t errori = 0;
	uint8_t ind = 0;
	uint8_t dummy_b = 0;
	uint16_t ind_s = 0x00;
	uint16_t loop_delay;
 	//int16_t Result=0;

	init_function_table();

	InitIrqLevels();

	HwInit();

	DEBUG_LED = 0xff;
	duart_init();

	timer_init();
	DuartReset();
	ComInit();

    #ifndef ACCEMIC_ON
	   #ifdef MUX_ON
			mux_init();
			mux_lines_reset();
			while (1)
			{
				Result = Setta_mux(SM_K_L_K2000,FALSE);
				if (Result == ENDOK)
					break;
			}
	   #endif
	#endif

/*
	p_program_serial_port = (program_serial_com_struct *)vect254;

	if (!p_program_serial_port->mux_used)
		PDR8 = 0X00;
*/


	#ifndef ACCEMIC_ON
    	usa_mux();
    #endif

    #ifdef ACCEMIC_ON
     	monitor_line = 2; // porta seriale COM2 (UART esterna) [COM0, COM1, COM2, COM3]
    	SetMatrice(SERIAL_MATRIX_S1_232B | SERIAL_MATRIX_S0_KECU, SERIAL_MATRIX_UART1_232A | SERIAL_MATRIX_UART2_LECU);
		SetBaudRate(monitor_line, (int32_t)115200 /*(int32_t)p_program_serial_port->baud_rate*/);
	#else

	  #ifdef EMULATOR_ON
		monitor_line = 2;
		SetMatrice(SERIAL_MATRIX_S1_KECU | SERIAL_MATRIX_S0_LECU, SERIAL_MATRIX_UART1_232A | SERIAL_MATRIX_UART2_232B);
		SetBaudRate(monitor_line, (int32_t)38400);
	  #else
		switch(p_program_serial_port->line)
		{
			case CONNECTOR_4_232_USER:
				monitor_line = 2;
				SetMatrice(SERIAL_MATRIX_S1_KECU | SERIAL_MATRIX_S0_LECU, SERIAL_MATRIX_UART1_232A | SERIAL_MATRIX_UART2_232B);
				SetBaudRate(monitor_line, (int32_t)p_program_serial_port->baud_rate);
				break;

			case CONNECTOR_5_232_PROG:
				monitor_line = 3;
				SetMatrice(SERIAL_MATRIX_S1_KECU | SERIAL_MATRIX_S0_LECU, SERIAL_MATRIX_UART1_232A | SERIAL_MATRIX_UART2_232B);
				SetBaudRate(monitor_line, (int32_t)p_program_serial_port->baud_rate);
				break;

			case CONNECTOR_2_KPC:
				monitor_line = 2;
				SetMatrice(SERIAL_MATRIX_S1_KECU | SERIAL_MATRIX_S0_LECU, SERIAL_MATRIX_UART1_KPC | SERIAL_MATRIX_UART2_232B);
				SetBaudRate(monitor_line, (int32_t)p_program_serial_port->baud_rate);
				break;

			case CONNECTOR_2_LPC:
				monitor_line = 3;
				SetMatrice(SERIAL_MATRIX_S1_KECU | SERIAL_MATRIX_S0_LECU, SERIAL_MATRIX_UART1_232A | SERIAL_MATRIX_UART2_LPC);
				SetBaudRate(monitor_line, (int32_t)p_program_serial_port->baud_rate);
				break;

			default:
				monitor_line = 2;
				SetMatrice(SERIAL_MATRIX_S1_KECU | SERIAL_MATRIX_S0_LECU, SERIAL_MATRIX_UART1_232A | SERIAL_MATRIX_UART2_232B);
				SetBaudRate(monitor_line, (int32_t)38400);
		}
	  #endif
	#endif

	DEBUG_LED = 0x00; // spengo il led vita

	ind_s=0;
	loop_delay = 10; // imposta cadenza loop a 10ms

	//SetBaudRate(monitor_line, (int32_t)115200);

	eotx_com_pc = 0;
	eorx_com_pc = 0;
	ECU.settata = 0;

	#ifndef ACCEMIC_ON
		SMR1_SOE = 1;
		UMC0_SOE = 1;
		SCR1_RXE = 1;
		SCR1_REC = 1;
		UMC0_RFC = 0;
	#endif

	/*
	ECU.baud_rate = 50000;
	ECU.id_length = 0;
	ECU.id_domanda   = 0x00F6;
	ECU.id_risposta  = 0x40F9;
	*/
	/*
	ResetRx();

	for(;;)

	{
	azzera_CAN_pack_tx();
	can_pack_tx[0] = 0x08;
	can_pack_tx[1] = 0x02;
	can_pack_tx[2] = 0x21;//0x21;
	can_pack_tx[3] = 0x20;//0x20;

	if (TxEmptyCan())
	{
		PutPackCan();
	}

    while (can_num == 0);


    ResetRx();
	}
	*/

	ciclo_principale();

	// ------------------------------ the main loop ----------------------------
	//ObdSystem();

}


//----------------------------------------------------------------------------------------------
void ObdSystem (void)
{
#define SISIDLE	0
#define SISFASE	10
#define SISSTOP	90

BOOL loop; //Se vero continuo a ciclare il sistema
uint8_t faseSistema; //fase del ciclo principale


//Inizializzazione variabili globali e funzioni a stati finiti************
loop = TRUE;
faseSistema = SISIDLE;

// resetto le funzioni per prepararle per la comunicazione
SystemManager(TRUE);
Tx_Request(KLINE,0,TRUE);
RxAnswer(KLINE, TRUE);
MonitorManager(monitor_line, TRUE);
//Setta_mux(NO_STANDARD,TRUE);
Reset_rx(KLINE);


// inizializzo le variabili per la comunicazione
faseSistema = 0;




//*************************************************************************/

//Ciclo principale
	while (loop)
	{
		//Gestione Sistema //////////////////////////
		switch (faseSistema)
		{
			case SISIDLE:
				//Preparo orologio per blink vita
				ResetOrol(&BTime);
				//Parte la gesione del sistema
				faseSistema = SISFASE;
			break;

			case SISFASE + 0:
         	//SisStartCom = SISSTARTCOMM;  // era 0
            SisStartCom = 0;
				faseSistema++;
			break;

			case SISFASE + 1:

				//Micro - ECU
				SystemManager(FALSE);

				//Gestione Interfaccia PC - Micro
				MonitorManager(monitor_line, FALSE);


				//Qui se comando fine break solo se sono nella fase con sistema inizializzato
				//Per terminare la com � il comando di caricamento sistema

				if (SisStartCom == SISSTOPCOMM)
					SystemManager(TRUE);

				if (SisStartCom == SISSEXIT) // verifico la richiesta di uscita
				{
					SisStartCom  = 0x00;
					faseSistema = SISSTOP;
				}

			break;

			case SISSTOP + 0:
				MonitorManager(monitor_line, FALSE);
				ResetOrol(&ltime);
				faseSistema++;
			break;

			case SISSTOP + 1:
				MonitorManager(monitor_line, FALSE);
				if (GetTime(&ltime) > 100)
				{
					SystemManager(TRUE);

					//Tx_Request(KLINE, TRUE);
					//RxAnswer(KLINE, RICNONE, TRUE);


					Reset_rx(KLINE);
					//Esco dal sistema torno l'applicazione al firmware
					faseSistema = SISIDLE;
					loop = FALSE;
				}
			break;


			default:
				faseSistema = SISIDLE;
			break;
		}
		//Fine Gestione Sistema //////////////////////////


		//Led vita di debug
		if (GetTime(&BTime) > BlinkTime)
		{
			DEBUG_LED = ~DEBUG_LED; // blink il led vita
			ResetOrol(&BTime);
		}

// Comandi per il led bi-color
//			LED_BICOLOR1 = 1;
//			LED_BICOLOR2 = 0;



		//Svegliamo i dispositivi di comunicazione (tx)
		//Comandi via seriale
		//Linea K con ECU
		// MT021014LC La sveglia della linea K avviene nella Tx_request
//		Sveglia_tx(0);
//		Sveglia_tx(2);  // uart canale 1
		Sveglia_tx(monitor_line);	// Linea di comunicazione con il visualizzatore
		Bicolor_led_manager();
		//-----------------------------------------
	}//Fine while (1)
}
