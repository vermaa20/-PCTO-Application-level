#include "stdint.h"
#define SERIAL_C				// used to enable variable generation in serial.h

#include "sistema.h"
#include "types.h"

#ifndef ACCEMIC_ON
	#ifdef	EMULATOR_ON
		#include "ram_code.h"
	#endif
#endif

#include "serial.h"
#include "hw.h"
//-------------------------------------------------------------------
//-------- dichiarazioni EXTERN -------------------------------------



extern uint8_t rx_com_pc[100];
extern uint8_t tx_com_pc[100];
extern uint8_t rx_com_et[100];
extern uint8_t tx_com_et[100];
extern uint8_t indice_tx_com_pc;
extern uint8_t eotx_com_pc;
extern uint8_t eorx_com_pc;
extern uint16_t  timer_com_pc;
extern uint8_t eorx_com_et;
extern uint8_t eotx_com_et;
extern uint16_t timer_rx_intrabyte_com_et;
extern uint16_t timer_tx_intrabyte_com_et;
extern uint8_t indice_tx_com_et;
extern uint16_t timer_rx_frame_com_et;
extern uint16_t timer_attivazione;
extern tipo_ECU ECU;
extern uint16_t timer_tester_present;


//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------
// setup of UART0/1 hardware
__far void HwComInit()
{
	// setup UART0
	// ----------------- UART0
	// STATUS REGISTER 
	// 7.RDRF	= rx data register full
	// 6.ORFE	= over-run/framing error
	// 5.PE		= parity error
	// 4.TDRE	= tx data register empty
	// 3.RIE	= rx irq enable
	// 2.TIE	= tx irq enable
	// 1.RBF	= rx busy flag
	// 0.TBF	= tx busy flag
	USR0 = 0x00;				// disable rx & tx irq
	
	// UMC = MODE CONTROL
	// 7.PEN 	= parity enable
	// 6.SBL 	= stop bit length
	// 5.MC1	= mode control
	// 4.MC0 	= mode control
	// 3.SMDE	= synchro mode enable
	// 2.RCF	= rx flag clear
	// 1.SCKE	= SCLK enable
	// 0.SOE	= serial output enable
	//
	//	MC1		MC0 		Data length  
	//	0		0			7 (6)
	//	0		1			8 (7)
	//	1		0			8 + 1
	//	1		1			9 (8)
	// between () length with parity
	UMC0 = 0x19;					// N,8,1; async. enable outpin
	
	// PORT0 RATE REGISTER
	// 7.BCH 	= baud rate clock change
	// 6.RC3 	= rate control
	// 5.RC2	= rate control
	// 4.RC1 	= rate control
	// 3.RC0 	= rate control
	// 2.BCH0	= baud rate clock change
	// 1.P   	= sets 0=even/1=odd parity
	// 0.D8 	= data bit8 if data bit =9
	//
	//	BCH		BCH0		Divider ratio
	//	0		0			---
	//	0		1			/4
	//	1		0			/3
	//	1		1			/5
	//
	//	RC3 to RC0			Clock input
	//	0000 to 1011		dedicated baud rate generator
	//	1101				16bit reload timer
	//	1111				external clock
	//	1100				DO NOT USE
	//	1110				DO NOT USE
	//
	//  BAUD RATE TABLE with PLL*4=16MHz:
	//	0x0C		= 38400bps
	//	0x2C		= 19230bps
	//	0x34		= 10417bps
	//	0x3C		= 9615bps
	//	0x4C		= 4808bps
	URD0 = 0x3C;					// Ratio=/4; Dedicated baud rate: 9600bps
	
	// disable IRQs
	//USR0_RIE = 0; // rx int16_t. disable 
	//USR0_TIE = 0; // tx int16_t. disable 

#ifndef ACCEMIC_ON
	// Setup UART1
	// PORT1 MODE REGISTER
	// 7.MD1 	= Mode select
	// 6.MD0 	= Mode select
	// 5.CS2	= Clock input selection
	// 4.CS1 	= Clock input selection
	// 3.CS0 	= Clock input selection
	// 2.----	= reserved
	// 1.SCKE	= SCLK enable
	// 0.SOE	= serial output enable
	//
	//	MD1		MD0			Operatig mode
	//	0		0			Async. normal mode
	//	0		1			Async. multi-processor mode
	//	1		0			CLK sync. mode
	//	1		1			DO NOT USE!!!
	//
	//	CS2 to CS0			Clock input
	//	000 to 100			dedicated baud rate generator
	//	101					DO NOT USE!!!
	//	110					16bit reload timer0
	//	111					external clock
	SMR1 = 0x31;						// async. normal mode, 16bit reload timer, serial out enable 	

	// PORT1 CONTROL REGISTER
	// 7.PEN 	= parity enable
	// 6.P   	= parity 0=E; 1=O
	// 5.SBL	= stop bit length 0=1; 1=2
	// 4.CL  	= character length 0=7; 1=8
	// 3.A/D 	= address/data		0=data; 1=addr.
	// 2.REC  	= rx error clear
	// 1.RXE 	= rx enable
	// 0.TXE	= tx enable
	//  
	SCR1 = 0x14;						// 8,1-/data frame
	//SCR1 = 0x17;						// 8,1-rx e tx enable/data frame

	// PORT1 STATUS REGISTER
	// 7.PE  	= parity error
	// 6.ORE 	= over run error
	// 5.FRE	= framing error
	// 4.RDRF	= rx data register full
	// 3.TDRE	= tx data register empty
	// 2.---  	= ---
	// 1.RIE 	= irq rx enable
	// 0.TIE	= irq tx enable
	//  
	SSR1 = 0x00;						// tx & rx irq disabled

	// PORT1 PRESCALER CONTROL REGISTER
	// 7.MD  	= prescaler 0=stopped; 1=operating
	// 6.--- 	= 
	// 5.---	= 
	// 4.--- 	= 
	// 3.DIV3	= divider
	// 2.DIV2 	= divider
	// 1.DIV1	= divider
	// 0.DIV0	= divider
	//  
	//	DIV3 to DIV0		Clock input
	//	1101				/3
	//	1100				/4
	//	1011				/5
	//	1010				/6
	//	1001				/8
	U1CDCR = 0x00;				// prescaler OFF; divider not needed with reload timer 0

	// Setup TIMER0 as PORT1 baud rate generator
	// TIMER0 CONTROL STATUS REGISTER
	// 15.--- 	= 
	// 14.--- 	= 
	// 13.---	= 
	// 12.--- 	= 
	// 11.CSL1	= Clock source divider
	// 10.CSL0 	= Clock source divider
	//  9.MOD2	= operation mode and I/O function
	//  8.MOD1	= operation mode and I/O function
	//  7.MOD0	= operation mode and I/O function
	//  6.OUTE	= output enable bit (1=timer output; 0=normal IO pin)
	//  5.OUTL	= output level for TOUT pin (see following table)
	//  4.RELD	= reload enable (1=reload mode; 0=one shot mode)
	//  3.INTE	= interrupt enable (1=irq request enabled)
	//  2.UF   	= underflow (1=underflow event)
	//  1.CNTE	= count enable (1=waits for a trigger; 0=stops count)
	//  0.TRG 	= trigger (writing 1 generates a trigger in counter)
	//  
	//	CSL1	CSL0		clock cource 
	//	0		0			clock/4 (0.125us @ 16MHz)
	//	0		1			clock/8 (0.5us @ 16MHz)
	//	1		0			clock/32 (2us @ 16MHz)
	//	1		1			external event count mode
	//
	//  Internal clock mode
	//	MOD2    MOD1	MOD0	INPUT PIN FUNCTION		ACTIVE EDGE OR LEVEL
	//	0		0		0		trigger disabled		-
	//	0		0		1		trigger input   		rising edge
	//	0		1		0		edge            		falling edge
	//	0		1		1		edge            		both edges
	//	1		x		0		gate input      		'L' level
	//	1		x		1		gate input         		'H' level
	//	
	//  Event counter mode
	//	MOD2    MOD1	MOD0	INPUT PIN FUNCTION		ACTIVE EDGE OR LEVEL
	//	x		0		0		-               		-
	//	x		0		1		trigger input   		rising edge
	//	x		1		0		edge            		falling edge
	//	x		1		1		edge            		both edges
	//	
	//	OUTE    RELD	OUTL	OUTPUT WAVWFORM
	//	0		X		X		General purpose port
	//	1		0		0		Output 'H' during counting   
	//	1		0		1		Output 'L' during counting   
	//	1		1		0		Toggle output. Starts with 'L'
	//	1		1		1		Toggle output. Starts with 'H'
	//	
	
#endif
	
	TMCSR0 = 0x0010;			//clock/4; general purpose input and output pins; 

	// TIMER0 RELOAD TIMER REGISTER 16bit
	// UART1->bps = ((Clk / N) / (16 * 2 * (n + 1)))
	// reload value = (250000 / Baud_rate - 1)
	TMRLR0 = (uint16_t)(250000 / 9600 - 1);				//9600baud

	TMCSR0 = 0x0013;			//clock/4; general purpose input and output pins; 
}

// enables irqs for selected com
__far void EnableCom(uint8_t _chan)
{
	#ifdef	ENABLE_COM_0
	if (_chan == 0)
	{
		USR0_RIE = 1; // rx int16_t. enable 
		USR0_TIE = 1; // tx int16_t. enable 
	}	
	#endif

	#ifdef	ENABLE_COM_1
	if (_chan == 1)
	{
		SCR1_TXE = 1;	// tx enable
		SCR1_RXE = 1;	// tx enable
		SSR1_RIE = 1;	// rx int16_t. enable 
		SSR1_TIE = 1;	// tx int16_t. enable 
	}	
	#endif

	#ifdef	ENABLE_COM_2
	if (_chan == 2)
	{
		DUART_FIFOCTRL_1 = 0x00;
		DUART_IRQENABLE_1 = 0x03;
		ENIR_EN0 = 1;
	}	
	#endif

	#ifdef	ENABLE_COM_3
	if (_chan == 3)
	{
		DUART_FIFOCTRL_2 = 0x00;
		DUART_IRQENABLE_2 = 0x03;
		ENIR_EN1 = 1;
	}	
	#endif
}

// disables irqs for selected com
__far void DisableCom(uint8_t _chan)
{
	#ifdef	ENABLE_COM_0
	if (_chan == 0)
	{
		USR0_RIE = 0; // rx int16_t. disable 
		USR0_TIE = 0; // tx int16_t. disable 
	}	
	#endif

	#ifdef	ENABLE_COM_1
	if (_chan == 1)
	{
		SCR1_TXE = 0;	// tx disable
		SCR1_RXE = 0;	// tx disable
		SSR1_RIE = 0;	// rx int16_t. disable 
		SSR1_TIE = 0;	// tx int16_t. disable 
	}	
	#endif

	#ifdef	ENABLE_COM_2
	if (_chan == 2)
	{
		DUART_FIFOCTRL_1 = 0x00;
		DUART_IRQENABLE_1 = 0x00;
		ENIR_EN0 = 0;
	}	
	#endif

	#ifdef	ENABLE_COM_3
	if (_chan == 3)
	{
		DUART_FIFOCTRL_2 = 0x00;
		DUART_IRQENABLE_2 = 0x00;
		ENIR_EN1 = 0;
	}	
	#endif
}

// sets baud rate for specified channel
__far void SetBaudRate(uint8_t _chan, int32_t _baud)
{
	uint32_t dummy_l;

	#ifdef	ENABLE_COM_0
	if (_chan == 0)
	{
		// default setting 9600,N,8,1
		//  BAUD RATE TABLE with PLL*4=16MHz
		//	0x0C		= 38400bps
		//	0x2C		= 19200bps
		//	0x34		= 10400bps
		//	0x3C		= 9600bps
		//	0x4C		= 4800bps
		// WARNING!!!
		// This procedure will only accept the baud rate values
		// above decribed. In each other way the baud rate register
		// will not be affected!!!
		DisableCom(0);
		//USR0_RIE = 0; // rx int16_t. disable 
		//USR0_TIE = 0; // tx int16_t. disable 

		switch(_baud)
		{
			case 38400L:
				URD0 = 0x0C;					
				break;
			case 19200L:
				URD0 = 0x2C;					
				break;
			case 10400L:
				URD0 = 0x34;					
				break;
			case 9600L:
				URD0 = 0x3C;					
				break;
			case 4800L:
				URD0 = 0x4C;					
				break;
			default:
				break;
		}

		EnableCom(0);
		//USR0_RIE = 1; // rx int16_t. enable 
		//USR0_TIE = 1; // tx int16_t. enable 
	}	
	#endif

	#ifdef	ENABLE_COM_1
	if (_chan == 1)
	{
		// default setting 9600,N,8,1
		DisableCom(1);
		//SSR1_RIE = 0; // rx int16_t. disable 
		//SSR1_TIE = 0; // tx int16_t. disable 

		TMCSR0_CNTE = 0;			// count disabled

		// TIMER0 RELOAD TIMER REGISTER 16bit
		// UART1->bps = ((Clk / N) / (16 * 2 * (n + 1)))
		// reload value = (250000 / Baud_rate - 1)
		dummy_l = (uint16_t)(250000 / _baud - 1);				
		TMRLR0 = dummy_l;				//reload value for desired baud rate

		TMCSR0_CNTE = 1;			// count enabled
		TMCSR0_TRG = 1;				// send a trigger to counter

		EnableCom(1);
		//SSR1_RIE = 1; // rx int16_t. enable 
		//SSR1_TIE = 1; // tx int16_t. enable 
	}	
	#endif

	#ifdef	ENABLE_COM_2
	if (_chan == 2)
	{
		DisableCom(2);
		// default setting N,8,1
		// internal divisor: div = CrystalFrequency / (BaudRate * 16)
		dummy_l = (int32_t)16 * _baud;
		dummy_l = (int32_t)DUART_CLOCK_RATE / dummy_l;

		DUART_LINECTRL_1 |= 0X80;									// enable divisor update
		DUART_ALTERNATE_1 = 0X02;
		DUART_DIVISORLOW_1 = (uint8_t)(dummy_l & 0x00ff);				// scrive parte bassa
		DUART_DIVISORHIGH_1 = (uint8_t)((dummy_l & 0xff00) >> 8);		// scrive parte alta
		DUART_LINECTRL_1 = 0X7f & ((8 - 5) | (1 << 2) | 0x10);		// disabilita scrittura divisore e imposta resto del protocollo
		EnableCom(2);
	}	
	#endif

	#ifdef	ENABLE_COM_3
	if (_chan == 3)
	{
		DisableCom(3);
		// default setting N,8,1
		// internal divisor: div = CrystalFrequency / (BaudRate * 16)
		dummy_l = (int32_t)16 * _baud;
		dummy_l = (int32_t)DUART_CLOCK_RATE / dummy_l;

		DUART_LINECTRL_2 |= 0X80;									// enable divisor update
		DUART_ALTERNATE_2 = 0X02;
		DUART_DIVISORLOW_2 = (uint8_t)(dummy_l & 0x00ff);				// scrive parte bassa
		DUART_DIVISORHIGH_2 = (uint8_t)((dummy_l & 0xff00) >> 8);		// scrive parte alta
		DUART_LINECTRL_2 = 0X7f & ((8 - 5) | (1 << 2) | 0x10);		// disabilita scrittura divisore e imposta resto del protocollo
		EnableCom(3);
	}	
	#endif
}

// ----------------------------------------------------------------------------
//					serial software setup
// ----------------------------------------------------------------------------
__far void ComInit()
{
	// Inizializzazione strutture gestione seriale 0
	com[0].rx_buf			= rx_buf_com0;
	com[0].rx_buf_len 		= RX_BUF_LEN_0;
	com[0].rx_in			= 0;
	com[0].rx_out			= 0;

	com[0].tx_buf			= tx_buf_com0;
	com[0].tx_buf_len 		= TX_BUF_LEN_0;
	com[0].tx_in			= 0;
	com[0].tx_out			= 0;

	com[0].fase_rx 			= 0;

//	com[0].data_length 		= 0;
//	com[0].status 			= 0;

	com_struct_ptr[0] = &com[0];

	// Inizializzazione strutture gestione seriale 1
	com[1].rx_buf			= rx_buf_com1;
	com[1].rx_buf_len 		= RX_BUF_LEN_1;
	com[1].rx_in			= 0;
	com[1].rx_out			= 0;

	com[1].tx_buf			= tx_buf_com1;
	com[1].tx_buf_len 		= TX_BUF_LEN_1;
	com[1].tx_in			= 0;
	com[1].tx_out			= 0;

	com[1].fase_rx 			= 0;

//	com[1].data_length 		= 0;
//	com[1].status 			= 0;

	com_struct_ptr[1] = &com[1];

	// Inizializzazione strutture gestione seriale 2
	com[2].rx_buf			= rx_buf_com2;
	com[2].rx_buf_len 		= RX_BUF_LEN_2;
	com[2].rx_in			= 0;
	com[2].rx_out			= 0;

	com[2].tx_buf			= tx_buf_com2;
	com[2].tx_buf_len 		= TX_BUF_LEN_2;
	com[2].tx_in			= 0;
	com[2].tx_out			= 0;

	com[2].fase_rx 			= 0;

//	com[2].data_length 		= 0;
//  com[2].status 			= 0;

	com_struct_ptr[2] = &com[2];

	// Inizializzazione strutture gestione seriale 3
	com[3].rx_buf			= rx_buf_com3;
	com[3].rx_buf_len 		= RX_BUF_LEN_3;
	com[3].rx_in			= 0;
	com[3].rx_out			= 0;

	com[3].tx_buf			= tx_buf_com3;
	com[3].tx_buf_len 		= TX_BUF_LEN_3;
	com[3].tx_in			= 0;
	com[3].tx_out			= 0;

	com[3].fase_rx 			= 0;

//	com[3].data_length 		= 0;
//	com[3].status 			= 0;
	
	com_struct_ptr[3] = &com[3];

	// init hardware
	HwComInit();
}

// ----------------------------------------------------------------------------
//					Interrupt Seriali
// ----------------------------------------------------------------------------
// USR0 uart0 status register
// 7 RDRF	se1,0	ok	rx reg full
// 6 ORFE	overrun / framing err
// 5 PER	parity  err
// 4 TDRE	tx reg empty
// 3 RIE	rx int16_t en
// 2 TIE	tx int16_t en
// 1 RBF	receiver busy
// 0 TBF	transmitter busy
#define USR0_MASK 			0xE0
#define USR0_OK				0x80
#define UMC0_ERROR_RESET	0x04

// SSR1 uart0 serial status register
// 7 PER	parity  err
// 6 ORE 	overrun
// 5 FRE 	framing
// 4 RDRF	rx reg full
// 3 TDRE	tx reg empty
// 2 -
// 1 RIE	rx int16_t en
// 0 TIE	tx int16_t en
#define SSR1_MASK 	0xF0
#define SSR1_OK		0x10

// DUART_LINE_STATUS_1 duart 0 line status register
// 7 error in receiver FIFO
// 6 TEMT Trasmitter empty
// 5 THRE Trasmitter holding register
// 4 BI break interrupt
// 3 FE Framing error
// 2 PE parity error
// 1 OE overrun error
// 0 DR data ready
#define DUART_LINESTATUS_1_MASK 	0x8F
#define DUART_LINESTATUS_1_OK		0x01
#define DUART_TEMT_1_EMPTY			0x40
#define DUART_THRE_1_EMPTY			0x20

// DUART_LINE_STATUS_2 duart 1 line status register
// 7 error in receiver FIFO
// 6 TEMT Trasmitter empty
// 5 THRE Trasmitter holding register
// 4 BI break interrupt
// 3 FE Framing error
// 2 PE parity error
// 1 OE overrun error
// 0 DR data ready
#define DUART_LINESTATUS_2_MASK 	0x8F
#define DUART_LINESTATUS_2_OK		0x01
#define DUART_TEMT_2_EMPTY			0x40
#define DUART_THRE_2_EMPTY			0x20

//__interrupt 
__far void RxSer0 (void)
{
	#ifdef ENABLE_COM_0
		if ( (USR0 & USR0_MASK) == USR0_OK) 
		{ // no error
			com[0].rx_buf[com[0].rx_in++] = UIDR0;

			if (com[0].rx_in >= com[0].rx_buf_len)
				com[0].rx_in = 0;
		}
		else
		{ 
			// some error -> don't add
			// resets flags
			UMC0 &= ~UMC0_ERROR_RESET;
		}
	#endif
}

// tx ch 0 ----------------------------------------------------
//__interrupt 
__far void TxSer0()
{
	#ifdef ENABLE_COM_0
		if (com[0].tx_in != com[0].tx_out) 
		{ 
			// something to send
			UODR0 = com[0].tx_buf[com[0].tx_out++];
			
			if (com[0].tx_out >= com[0].tx_buf_len)
				com[0].tx_out = 0;
		}
		else
		{ 
			// nothing to send: disables tx irq
			USR0_TIE = 0; // tx int16_t. enable 
		}
	#endif
}

// rx ch 1 --------------------------------------------------------
//__interrupt 
__far void RxSer1()
{
	#ifdef ENABLE_COM_1
	  #ifndef ACCEMIC_ON
		if ( (SSR1 & SSR1_MASK) == SSR1_OK) 
		{ 
			//----------------------------------
		    if (eorx_com_et == 0)
		    	ResetOrol(&timer_rx_frame_com_et);
		   	//----------------------------------
			rx_com_et[eorx_com_et++] = SIDR1;
			//----------------------------------
			ResetOrol(&timer_rx_intrabyte_com_et);
			//-------------------------------	

		}
		else
		{ 
			// some error -> don't add
			// resets flags
			SCR1_REC = 0;
		}
	  #endif
	#endif
}

// tx ch 1 ----------------------------------------------------
//__interrupt 
#define debug_led PDRA_PA0
__far void TxSer1()
{
	#ifdef ENABLE_COM_1
	  #ifndef ACCEMIC_ON
	
		if (    (indice_tx_com_et == eotx_com_et) || (   (GetTime(&timer_tx_intrabyte_com_et)  < ECU.intrabyte_tx) && (indice_tx_com_et != 0) ) )
		{
			       SSR1_TIE = 0; // tx int16_t. enable 
				   return;    
		}

	    if (indice_tx_com_et != eotx_com_et)			 //  && TX1_READY credo inutile
		{ 
			// something to send
			
					
			if (indice_tx_com_et == 0)
			{
				ResetOrol (&timer_attivazione);
				ResetOrol (&timer_tester_present);
			}
			
			
   		    SODR1 = tx_com_et[indice_tx_com_et++];
   			ResetOrol (&timer_tx_intrabyte_com_et);
					
		}
		else
		{ 
			// nothing to send: disables tx irq
			SSR1_TIE = 0; // tx int16_t. enable 
		}
	  #endif	
	#endif
}

// rx ch 2 --------------------------------------------------------
//__interrupt 
// Seriale dedicata alla comunicazione con il PC
__far void RxSer2()
{ 
	    #ifdef ENABLE_COM_2
		uint8_t dummy;
		uint8_t dummy_2;
		uint8_t cksum, indice;
		static int16_t ByteIndex = 0;
		static int16_t ExpectedLen=-1;
		
		if (GetTime(&timer_com_pc) > timeout_com_pc)
    	ByteIndex =0;
    		
		dummy_2 = DUART_LINESTATUS_1;
		dummy = DUART_RXBUFFER_1;

		if ((dummy_2 & DUART_LINESTATUS_1_MASK) == DUART_LINESTATUS_1_OK) 
		{ 			
			// no error	
			switch(ByteIndex)
			{
				
				case 0:
					if(dummy == 0x5b)
						rx_com_pc[ByteIndex++] = dummy;
					break;
				case 1:
					rx_com_pc[ByteIndex++] = dummy;
					ExpectedLen = dummy<<8;
					break;
				case 2:
					rx_com_pc[ByteIndex++] = dummy;
					ExpectedLen |= dummy;
					break;
				case 10:
					rx_com_pc[ByteIndex++] = dummy;
					if((rx_com_pc[1]==0x20)&&(rx_com_pc[5] == 0x0B) && (rx_com_pc[6] == 0x22) && 
							(rx_com_pc[7] == 0x3F) && (rx_com_pc[8] == 0xFF) && (rx_com_pc[9] == 0x01) && (rx_com_pc[10] == 0xE7))
					{
						eorx_com_pc = 11;
						ByteIndex = 0;	
						return;
					}	
					else
						ByteIndex--;
				default:
					rx_com_pc[ByteIndex++] = dummy;
					if(ByteIndex != ExpectedLen) break;					
					
					//if( ((rx_com_pc[1] << 8) | rx_com_pc[2])==ByteIndex)
					{
						cksum = 0;
						for (indice = 0; indice < ByteIndex - 1; indice++)
						{
							cksum = cksum ^ rx_com_pc[indice];
						}
					
						if (cksum != rx_com_pc[ByteIndex -1])
							eorx_com_pc=0;
						else
							eorx_com_pc = ByteIndex;
						ByteIndex = 0;	
						ExpectedLen =-1;					
					}
					//else if((rx_com_pc[2]==0x20)&&(rx_com_pc[5] == 0x0B) && (rx_com_pc[6] == 0x22) && (rx_com_pc[7] == 0x3F) && (rx_com_pc[8] == 0xFF) && (rx_com_pc[9] == 0x01) && (rx_com_pc[10] == 0xE7))
					break;				
			}
			//rx_com_pc[eorx_com_pc++] = dummy;
		
			ResetOrol(&timer_com_pc);
													
		}
		// some error -> don't add
		// the flags are already resetted by the previous read of the line status register
	#endif
}

// tx ch 2 ----------------------------------------------------
//__interrupt 
__far void TxSer2()
{
	#ifdef ENABLE_COM_2
			
		if (indice_tx_com_pc == eotx_com_pc)
		   return; 
		if (DUART_LINESTATUS_1 & DUART_THRE_1_EMPTY)
   			DUART_TXBUFFER_1 = tx_com_pc[indice_tx_com_pc++];
   			
		// nothing to send: irq disabled automatically
	#endif
}

// rx ch 3 --------------------------------------------------------
//__interrupt 
__far void RxSer3()
{
	#ifdef ENABLE_COM_3
	  #ifdef ACCEMIC_ON	
		uint8_t dummy;
		uint8_t dummy_2;	

		dummy_2 = DUART_LINESTATUS_2 ;
		dummy 	= DUART_RXBUFFER_2;

		if ((dummy_2 & DUART_LINESTATUS_2_MASK) == DUART_LINESTATUS_2_OK) 
		{ 	
						    		
			//----------------------------------
		    if (eorx_com_et == 0)
		    	ResetOrol(&timer_rx_frame_com_et);
		   	//----------------------------------
			rx_com_et[eorx_com_et++] = dummy;
			//----------------------------------
			ResetOrol(&timer_rx_intrabyte_com_et);
			//-------------------------------		
            
		}
		// some error -> don't add
		// the flags are already resetted by the previous read of the line status register
	  #endif	
	#endif
}

// tx ch 3 ----------------------------------------------------
//__interrupt 
__far void TxSer3()
{
	#ifdef ENABLE_COM_3
	  #ifdef ACCEMIC_ON	
		if (    (indice_tx_com_et == eotx_com_et) || (   (GetTime(&timer_tx_intrabyte_com_et)  < ECU.intrabyte_tx) && (indice_tx_com_et != 0) ) )
		   return; 
		if (DUART_LINESTATUS_2 & DUART_THRE_2_EMPTY)
		{
			if (indice_tx_com_et == 0)
			{
				ResetOrol (&timer_attivazione);
				ResetOrol (&timer_tester_present);
			}
   			DUART_TXBUFFER_2 = tx_com_et[indice_tx_com_et++];
   			ResetOrol (&timer_tx_intrabyte_com_et);
   		}
		// nothing to send: irq disabled automatically
	  #endif	
	#endif
}

// resets duart chip
__far void DuartReset()
{
	// reset bit = 7
	// 1 = reset
	// 0 = normal operation

	// sets reset line
	PDR4 |= 0x80;
	// resets reset line
	PDR4 &= 0x7f;
}

// **************************************
// puts a uint8_t in the serial buffer
// _com: channel
// _ch: value to process
__far void PutByte(uint8_t _com, uint8_t _ch)
{
	com[_com].tx_buf[com[_com].tx_in] = _ch;
	com[_com].tx_in++;

	if (com[_com].tx_in >= com[_com].tx_buf_len)
		com[_com].tx_in = 0;
}

// **************************************
// puts a string in the serial buffer
// _com: channel
// _val: string pointer
__far void PutString(uint8_t _com, uint8_t *_str)
{
	while (*_str)
		PutByte(_com, *_str++);
}

// **************************************
// puts a string in int32_t format in the serial buffer
// _com: channel
// _val: value to process
// _len: length of the string
__far void PutLong(uint8_t _com, int32_t _val, uint8_t _len)
{
	uint8_t i;
	int32_t mask = 1;

	for(i = 0; i < _len - 1; i++)
		mask *= 10;

	for(i = 0; i < _len; i++)
	{
		PutByte(_com, _val / mask + '0');
		_val %= mask;
		mask /= 10;
	}
}

// **************************************
// puts a string in hex format in the serial buffer
// _com: channel
// _val: value to process
// _len: length of the string
__far void PutHex(uint8_t _com, int32_t _val, uint8_t _len)
{
	uint8_t i;
	int32_t mask = 1;
	uint8_t res;

	for(i = 0; i < _len - 1; i++)
		mask *= (int32_t)0x10;

	for(i = 0; i < _len; i++)
	{
		res = (uint8_t)(_val / mask);
		
		if (res <= 9)
			PutByte(_com, res + '0');
		else
			PutByte(_com, res + 'A' - 0x0A);
			
		_val %= mask;
		mask /= (int32_t)16;
	}
}

// **************************************
// if necessary, re-enable tx irq
// _com: channel
__far void Sveglia_tx(uint8_t _com)
{
	if (com[_com].tx_in != com[_com].tx_out)
		EnableCom(_com);
}

// **************************************
// this function returns the presence of characters in shift register
// _com: channel
__far uint8_t BytesInShiftRegister(uint8_t _com)
{
	uint8_t res;
	
	#ifdef ENABLE_COM_0
	if (_com == 0)
	{
		// controllo TBF
		res = ~(USR0 & 0x01);				// TBF=1: trasmission busy
	}
	#endif
	
	#ifdef ENABLE_COM_1
	if (_com == 1)
	{
		// WARNING!!! In this serial port this information is not present.
		// The procedure returns always buffer empty in order to avoid any
		// application stack.
		// controllo TBF
		res = 0;				// libero
	}
	#endif
	
	#ifdef ENABLE_COM_2
	if (_com == 2)
	{
		res = DUART_LINESTATUS_1 & DUART_TEMT_1_EMPTY;
	}
	#endif
	
	#ifdef ENABLE_COM_3
	if (_com == 3)
	{
		res = DUART_LINESTATUS_2 & DUART_TEMT_2_EMPTY;
	}
	#endif
	
	return (res) ? 0 : 1;
}

// **************************************
// this function returns the presence of characters in rx_buffer 
// _com: channel
__far uint8_t BytesInReceiveBuffer(uint8_t _com)
{
	//return (com[_com].rx_in == com[_com].rx_out) ? 0 : 1;
	return (com_struct_ptr[_com]->rx_in == com_struct_ptr[_com]->rx_out) ? 0 : 1;
}

// **************************************
// this function returns the presence of characters in tx_buffer 
// _com: channel
__far uint8_t BytesInTxBuffer(uint8_t _com)
{
	//return (com[_com].tx_in == com[_com].tx_out) ? 0 : 1;
	return (com_struct_ptr[_com]->tx_in == com_struct_ptr[_com]->tx_out) ? 0 : 1;
}

// **************************************
// this function returns next character in rx_buffer
// _com: channel
// WARNING!!! it must be used only after checking
// the presence of characters in rx_buffer with BytesInReceiveBuffer()
__far uint8_t GetByte(uint8_t _com)
{
	uint8_t ret_val;

	if (com_struct_ptr[_com]->rx_in == com_struct_ptr[_com]->rx_out)
		return 0;
	else 
	{
		ret_val = com_struct_ptr[_com]->rx_buf[com_struct_ptr[_com]->rx_out++];
		
		if (com_struct_ptr[_com]->rx_out >= com_struct_ptr[_com]->rx_buf_len)
			com_struct_ptr[_com]->rx_out = 0;

		return ret_val;
	}
}


//----------------------------------------------------------------------------------------------
// Prelevo un dato da una struttura di rx specificando l'offset
__near uint8_t GetBytefromBuffer(uint8_t K_L, uint8_t offset)
{
	uint8_t ret_val;
	if (K_L == LLINE)
		ret_val = com[LLINE].rx_buf[offset];
	else
		ret_val = com[KLINE].rx_buf[offset];

	return ret_val;
}

// ------------------------------------------------------------------------
__far BOOL Tx_Empty(uint8_t _com)
{
	//Se i due puntatori sono uguali -> tutti i caratteri sono trasmessi (= buffer tx vuoto)
	if (com[_com].tx_in == com[_com].tx_out)
		return TRUE;
	else
		return FALSE;	
}


__far void Put_and_ck(uint8_t _com, uint8_t car)
{
	com[_com].tx_calc_ck += (uint32_t)car;
	PutByte(_com, car);
}

__far uint8_t Get_and_ck(uint8_t _com)
{
	uint8_t car = GetByte(_com);
	com[_com].calc_ck += (uint32_t)car;
	return car;
}

//Resetta i puntatori di rx per ricominciare da zero
__far void Reset_rx(uint8_t _com)
{
	com[_com].rx_in  = 0;
	com[_com].rx_out = 0;
}

__far void PutLongInt(uint8_t _com, int32_t _val, uint8_t _len)
{
	uint8_t i;
	int32_t mask;
		
	mask = 1;
	
	for(i = 0; i < _len - 1; i++)
		mask *= 10;

	for(i = 0; i < _len; i++)
	{
		PutByte(_com, _val / mask + '0');
		_val %= mask;
		mask /= 10;
	}

}



// sets serial matrix to redirect seria ports
__far void SetMatrice(uint8_t b_lo, uint8_t b_hi)
{
#define SERIAL_MTRX_0			0xD80000L
#define SERIAL_MTRX_1			0xDC0000L
/*
--			|	ADDR_0		|	ADDR_1
--		bit	|  6|5|4 2|1|0	|  5|4	 1|0
--			|	s0	   s1	| UART1	UART2
------------------------------------------
--	s232a	| 0 0 0	 0 0 1	|  1 1	 - -
--	s232b	| 0 0 1	 0 0 0	|  - - 	 1 1
--	at		| 0 1 0	 0 1 1	|  1 0	 - -
--	s485	| 0 1 1	 0 1 0	|  - - 	 1 0
--	kpc		| 1 0 0  1 0 1	|  0 1	 - -
--	lpc		| 1 0 1	 1 0 0	|  - -	 0 1
--	kecu	| 1 1 0	 1 1 1	|  0 0	 - -
--	lecu	| 1 1 1	 1 1 0	|  - -	 0 0 
*/
// default settings
//	s232a	=	s0
//	s232b	=	s1
//	k ecu	=	uart1
//	l ecu	=	uart2
	
	*(uint8_t __far*)SERIAL_MTRX_0 = b_lo;	// setto la matrice seriale
	*(uint8_t __far*)SERIAL_MTRX_1 = b_hi;	// setto la matrice seriale
}

//__interrupt 
__far void Duart_1_2 (void)
{
	uint8_t read_uart;

//	if (INT0)
// 020723MD passo ad usare flag int16_t pendente
	if (EIRR_ER0)
	{
		read_uart = DUART_IRQID_1 & 0x0F;
		if ((read_uart <= 0x04) && (read_uart)) //DATA AVAILABLE or LINE STATUS IRQ
			RxSer2();

		if ((read_uart & 0x0F) == 0x02) //Register empty
			TxSer2();

		EIRR_ER0 = 0;
	}
//	if (INT1)
// 020723MD passo ad usare flag int16_t pendente
	if (EIRR_ER1)
	{
		read_uart = DUART_IRQID_2 & 0x0F;
		if ((read_uart <= 0x04) && (read_uart)) //DATA AVAILABLE or LINE STATUS IRQ
			RxSer3();

		if ((read_uart & 0x0F) == 0x02) //Register empty
			TxSer3();

		EIRR_ER1 = 0;
	}
}


__far void duart_init(void)
{ 
//uart 0
	ENIR_EN0 = 0;

	// Attivo sui livelli
	ELVR_LA0 = 1;
	ELVR_LB0 = 0;
	
	EIRR_ER0 = 0;

	ENIR_EN0 = 1;
// uart 1
	ENIR_EN1 = 0;

	// Attivo sui livelli
	ELVR_LA1 = 1;
	ELVR_LB1 = 0;
	
	EIRR_ER1 = 0;

	ENIR_EN1 = 1;

}

__far void duart_reset ()
{
	ENIR_EN0 = 0;
}


