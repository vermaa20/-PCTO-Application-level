#include "stdint.h"
//------------------------------------------------------------------------------
// HEADING

// PROJECT NAME:     Sis_NNN.prj/Sis_RAM_NNN.prj
// PROJECT RELEASE:  VIEW HEADING OF "sistema.c"
// FILE NAME:        Vectors.c
// FILE RELEASE:     1.0
// DATE:             February 2004
// FILE DESCRIPTION: Interrupt vector definition and Interrupt level (priority)
//                   setting.
// REVIEW  BY:       Ing. Andrea Acunzo - Ing. Diego Mainardi
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// FURTHER INFORMATIONS

//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// AVAILABLE PRCEDURE/FUNCTION

// __far void InitVariante(void)
// __far void InitIndexAtt (void)
// __far void InitInfo (void)
// __far void InitStati (void)
// __far void InitParam (void)
// __far void InitAtt(void)
// __far void InterpretaInfo (void)
// void DisabilitaSingoloSnap(int16_t pid_attivo)
// __far void InterpretaParametriStati (void)
// __far void Azzera_errori (uint8_t _conta_mem, uint8_t _conta_att)
// uint8_t DisponiErrori(uint8_t _NumErr)
// __far void InterpretaErrori(void)
// __far void CancErrori(void)
// __far void InterpretaAttivazione(void)
// __far uint8_t GestioneErroreTX(uint8_t errore,BOOL reset)
// __far uint8_t GestioneErroreRX(uint8_t errore,BOOL reset)
// __far uint8_t Attiva_Fast(BOOL Reset)
// int16_t Send5Baud (uint8_t _send_byte, BOOL Reset)
// int16_t Wait_iso (uint8_t linea_utiliz, BOOL Reset)
// __far uint8_t AttivaEcu(BOOL Reset)
// __far void Riattiva(void)
// uint8_t ComponiDomanda (int16_t _service,int16_t _pid,uint8_t Stato)
// uint16_t SequenzaDomande (BOOL Reset)
// __far uint8_t Tx_Request(uint8_t K_l,uint16_t Wait_Time, BOOL Reset)
// uint8_t RispostaOk (uint8_t _com, uint8_t _byte_da_ricevere)
// __far uint8_t RxAnswer(uint8_t K_l, BOOL Reset)
// void InterpretaRisposta(void)
// __near uint8_t SystemManager(BOOL Reset)
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// INCLUDE HEADER LIST

#include "mb90540.h"
#include "typedefs.h"

#include "vectors.h"

#include "sistema.h"

#ifndef ACCEMIC_ON
 #ifdef	EMULATOR_ON
	#include "ram_code.h"
 #endif
#endif


//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// CODE

//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to set priority level of interrupt procedure.
//                Either use your own placeholder or add necessary code here.
//                This function  pre-sets all interrupt control registers.
//                It can be used to set all interrupt priorities in static
//                applications. If this file contains assignments to dedicated
//                resources, verify  that the appropriate controller is used.
//                NOTE: value 7 disables the interrupt and value 0 sets highest
//                priority.
//                NOTE: Two resource interrupts always share one ICR register.
// F/P CALLING:   init_function_table (main.c)
// F/P CALLED:    main (main.c)
// PARAMETER IN:  
// PARAMETER OUT:
//------------------------------------------------------------------------------
void InitIrqLevels(void)
{
//  ICRxx               shared IRQs for ICR

    ICR00 = 5;      //  IRQ11
                    //  IRQ12
    ICR01 = 7;      //  IRQ13     
                    //  IRQ14
    ICR02 = 5;      //  IRQ15  Duart 1/2
                    //  IRQ16
    ICR03 = 7;      //  IRQ17
                    //  IRQ18
    ICR04 = 7;      //  IRQ19
                    //  IRQ20
    ICR05 = 5;      //  IRQ21
                    //  IRQ22 PPG0/1
    ICR06 = 3;      //  IRQ23
                    //  IRQ24 J1850
    ICR07 = 7;      //  IRQ25
                    //  IRQ26
    ICR08 = 7;      //  IRQ27
                    //  IRQ28
    ICR09 = 7;      //  IRQ29
                    //  IRQ30
    ICR10 = 7;      //  IRQ31
                    //  IRQ32
    ICR11 = 7;      //  IRQ33
                    //  IRQ34
    ICR12 = 7;      //  IRQ35
                    //  IRQ36
    ICR13 = 5;      //  IRQ37 RxSer0
                    //  IRQ38 RxSer0                
    #ifndef ACCEMIC_ON                
    	ICR14 = 5;      //  IRQ39 TxSer1
    #endif                	//  IRQ40 TxSer1
                                            
    ICR15 = 7;      //  IRQ41
                    //  IRQ42 

} // end InitIrqLevels procedure


//------------------------------------------------------------------------------
// COMPILER DIRECTIVE
#ifdef EMULATOR_ON 
	#ifndef BOOTLOADER_ON
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// DESCRIPTION:   Redirect the address for interrupt procedure (for all). They
//                are the irq procedures which point to internal ram vectors.
// F/P CALLING:   The interrupt-event calls these procedures
// F/P CALLED:
// PARAMETER IN:
// PARAMETER OUT:
//------------------------------------------------------------------------------
#ifndef ACCEMIC_ON
	__interrupt void Irq_vect009(void)
	{
		((__far void (*)())vect009)();
	} // end Irq_vect009 procedure
#endif
//------------------------------------------------------------------------------
	__interrupt void Irq_vect010(void)
	{
		((__far void (*)())vect010)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect011(void)
	{
		((__far void (*)())vect011)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect012(void)
	{
		((__far void (*)())vect012)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect013(void)
	{
		((__far void (*)())vect013)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect014(void)
	{
		((__far void (*)())vect014)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect015(void)
	{
		((__far void (*)())vect015)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect016(void)
	{
		((__far void (*)())vect016)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect017(void)
	{
		((__far void (*)())vect017)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect018(void)
	{
		((__far void (*)())vect018)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect019(void)
	{
		((__far void (*)())vect019)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect020(void)
	{
		((__far void (*)())vect020)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect021(void)
	{
		((__far void (*)())vect021)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect022(void)
	{
		((__far void (*)())vect022)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect023(void)
	{
		((__far void (*)())vect023)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect024(void)
	{
		((__far void (*)())vect024)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect025(void)
	{
		((__far void (*)())vect025)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect026(void)
	{
		((__far void (*)())vect026)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect027(void)
	{
		((__far void (*)())vect027)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect028(void)
	{
		((__far void (*)())vect028)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect029(void)
	{
		((__far void (*)())vect029)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect030(void)
	{
		((__far void (*)())vect030)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect031(void)
	{
		((__far void (*)())vect031)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect032(void)
	{
		((__far void (*)())vect032)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect033(void)
	{
		((__far void (*)())vect033)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect034(void)
	{
		((__far void (*)())vect034)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect035(void)
	{
		((__far void (*)())vect035)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect036(void)
	{
		((__far void (*)())vect036)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect037(void)
	{
		((__far void (*)())vect037)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect038(void)
	{
		((__far void (*)())vect038)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect039(void)
	{
		((__far void (*)())vect039)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect040(void)
	{
		((__far void (*)())vect040)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect041(void)
	{
		((__far void (*)())vect041)();
	}

//------------------------------------------------------------------------------
	__interrupt void Irq_vect042(void)
	{
		((__far void (*)())vect042)();
	} // end Irq_vect042 procedure


	#endif
#endif


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is a placeholder for all vector definitions.
//                Either use your own placeholder or add necessary code here.
// F/P CALLING:   reset_function_table (Vectors.c)
// F/P CALLED:
// PARAMETER IN:
// PARAMETER OUT:
//------------------------------------------------------------------------------
void DefaultIRQHandler (void)
{
} // end DefaultIRQHandler procedure


//------------------------------------------------------------------------------
// DESCRIPTION:   This function is to redirect Irq/function vectors.
//                Either use your own placeholder or add necessary code here.
// F/P CALLING:   init_function_table (main.c)
// F/P CALLED:
// PARAMETER IN:  _original: original interrupt procedure address
//                *_new: final interrupt procedure address
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void redirect_function_table(int32_t _original, int32_t *_new)
{
	*(int32_t __far*)(_original) = (int32_t)_new;
} // end redirect_function_table procedure


//------------------------------------------------------------------------------
// DESCRIPTION:   initialise Irq/function vectors with dummy procedure.
//                Either use your own placeholder or add necessary code here.
// F/P CALLING:   init_function_table (main.c)
// F/P CALLED:    DefaultIRQHandler (Vectors.c)
// PARAMETER IN:
// PARAMETER OUT:
//------------------------------------------------------------------------------
__far void reset_function_table()
{
	uint16_t ind;
	int32_t *p_vector = (int32_t *)&vect000;

	for (ind=0; ind < 256; ind++)
	  {
      *p_vector++ = (int32_t)DefaultIRQHandler;
    }
} // end reset_function_table procedure

