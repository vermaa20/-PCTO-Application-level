#include "stdint.h"
// generiche funzionamento --------------------------
#include "typedefs.h"

#ifdef TIME_C
	uint16_t  main_time = 0;		// max 65s
	uint16_t	timing_10ms		= 10;
	uint16_t	timing_100ms	= 100;
#else
	extern uint16_t  main_time;		// max 65s
	extern uint16_t	timing_10ms;
	extern 	uint16_t	timing_100ms;
#endif

extern __far void timer_init(void);
extern __far void ResetOrol(uint16_t *_orol);
extern __far uint16_t GetTime(uint16_t *_orol);
extern __far void PPG0_IRQHandler (void);
