#include "stdint.h"
/*�����������������������������������������������������������������������ͻ*/
/*�                          F U J I T S U                                �*/
/*�                                                                       �*/
/*�              M i k r o e l e k t r o n i k   G m b H                  �*/
/*�                                                                       �*/
/*�                                                                       �*/
/*�  Filename:       typedefs.h                                           �*/
/*�  Description:    Definition of some useful typedef's                  �*/
/*�  Series:         for all C-Compilers (MB89620)                        �*/
/*�  Version:        V01.01                                               �*/
/*�  Design:         J�rgen Suppelt 23.06.93                              �*/
/*�  Change:         J�rgen Suppelt 07.06.94                              �*/
/*�                  Change of bit order in TBitWord (Lower & Higher Bits)�*/
/*�                                                                       �*/
/*�����������������������������������������������������������������������ͼ*/


#ifndef TYPEDEFS_H
#define TYPEDEFS_H

//------------------------------------------------------------------------------
// START TECNOMOTOR

#define FALSE           0
#define TRUE            1

// MT021115 Aggiunte define qui

//Stati funzioni e codici errore
#define IDLE			0x00
#define ENDOK			0x10
#define WRONGSTEP		0x20
#define TOUT			0x30
#define RUNNING			0x40
#define WAIT_COMP		0x50
#define ERRORE			0x60
// STOP  TECNOMOTOR
//------------------------------------------------------------------------------


// connectors map
#define	CONNECTOR_4_232_USER		1
#define	CONNECTOR_5_232_PROG		2
#define	CONNECTOR_2_KPC				3
#define	CONNECTOR_2_LPC				4


// serial matrix addresses
#define SERIAL_MTRX_0			0xD80000L
#define SERIAL_MTRX_1			0xDC0000L

// serial matrix defines
#define SERIAL_MATRIX_UART1_232A		0x30
#define SERIAL_MATRIX_UART1_ATMEL		0x20
#define SERIAL_MATRIX_UART1_KPC			0x10
#define SERIAL_MATRIX_UART1_KECU		0x00

#define SERIAL_MATRIX_UART2_232B		0x03
#define SERIAL_MATRIX_UART2_485			0x02
#define SERIAL_MATRIX_UART2_LPC			0x01
#define SERIAL_MATRIX_UART2_LECU		0x00

#define SERIAL_MATRIX_S0_232A			0x00
#define SERIAL_MATRIX_S0_232B			0x10
#define SERIAL_MATRIX_S0_ATMEL			0x20
#define SERIAL_MATRIX_S0_485			0x30
#define SERIAL_MATRIX_S0_KPC			0x40
#define SERIAL_MATRIX_S0_LPC			0x50
#define SERIAL_MATRIX_S0_KECU			0x60
#define SERIAL_MATRIX_S0_LECU			0x70

#define SERIAL_MATRIX_S1_232A			0x01
#define SERIAL_MATRIX_S1_232B			0x00
#define SERIAL_MATRIX_S1_ATMEL			0x03
#define SERIAL_MATRIX_S1_485			0x02
#define SERIAL_MATRIX_S1_KPC			0x05
#define SERIAL_MATRIX_S1_LPC			0x04
#define SERIAL_MATRIX_S1_KECU			0x07
#define SERIAL_MATRIX_S1_LECU			0x06

// /MT021115LC

#define VOID            void

typedef uint8_t   BOOL;
typedef uint8_t   BYTE,uchar;
typedef uint16_t  WORD,ushort;
typedef uint32_t   DWORD,ulong;
typedef uint16_t    UINT,uint;
typedef int32_t   LONG;

typedef          uint8_t*  PSTR;
typedef const    uint8_t*  PCSTR;
typedef          BYTE*  PBYTE;
typedef          int16_t*   PINT;
typedef          WORD*  PWORD;
typedef          int32_t*  PLONG;
typedef          DWORD* PDWORD;

typedef const    uint8_t   CSTR;

#define LOBYTE(w)       ( (BYTE) (w) )
#define HIBYTE(w)       ( (BYTE) ( (UINT) (w)>>8 ))
#define LOWORD(l)       ( (WORD) (l) )
#define HIWORD(l)       ( (WORD) ( (DWORD) (l)>>16 ))
#define MAKELONG(lo,hi) ((LONG)(((WORD)(lo))|(((DWORD)((WORD)(hi)))<<16)))
#define MAKEWORD(lo,hi) ((WORD)(((BYTE)(lo))|(((WORD)((BYTE)(hi)))<<8)))

typedef union                           /* typedef TBitByte */
{ BYTE BYTE;
  struct { BYTE D0:1, D1:1, D2:1, D3:1, D4:1, D5:1, D6:1, D7:1;} BIT;
} TBitByte;

typedef union                           /* typedef TBitWord */
{
  WORD WORD;
  struct { BYTE H, L;} BYTE;
  struct { BYTE D8:1, D9:1, DA:1, DB:1, DC:1, DD:1, DE:1, DF:1;
           BYTE D0:1, D1:1, D2:1, D3:1, D4:1, D5:1, D6:1, D7:1;} BIT;
} TBitWord;



//------------------------------------------------------------------------------
// START TECNOMOTOR
//------------------------------------------------------------------------------
// TYPE AND STRUCTURE DECLARATIONS

// New definitions of "Byte"
typedef union{
    uchar	byte;
    unsigned bit0 :1;
    unsigned bit1 :1;
    unsigned bit2 :1;
    unsigned bit3 :1;
    unsigned bit4 :1;
    unsigned bit5 :1;
    unsigned bit6 :1;
    unsigned bit7 :1;
}byte;



// New definitions of "word"
typedef union{
    ushort	word;
	struct
		{
		unsigned bit0  :1;
		unsigned bit1  :1;
		unsigned bit2  :1;
		unsigned bit3  :1;
		unsigned bit4  :1;
		unsigned bit5  :1;
		unsigned bit6  :1;
		unsigned bit7  :1;

		unsigned bit8  :1;
		unsigned bit9  :1;
		unsigned bit10 :1;
		unsigned bit11 :1;
		unsigned bit12 :1;
		unsigned bit13 :1;
		unsigned bit14 :1;
		unsigned bit15 :1;
		}l_bit;
}l_word;


// New definitions of "double word"
typedef union{
    udouble_word;
	struct
		{
		unsigned bit0  :1;
		unsigned bit1  :1;
		unsigned bit2  :1;
		unsigned bit3  :1;
		unsigned bit4  :1;
		unsigned bit5  :1;
		unsigned bit6  :1;
		unsigned bit7  :1;

		unsigned bit8  :1;
		unsigned bit9  :1;
		unsigned bit10 :1;
		unsigned bit11 :1;
		unsigned bit12 :1;
		unsigned bit13 :1;
		unsigned bit14 :1;
		unsigned bit15 :1;

		unsigned bit16 :1;
		unsigned bit17 :1;
		unsigned bit18 :1;
		unsigned bit19 :1;
		unsigned bit20 :1;
		unsigned bit21 :1;
		unsigned bit22 :1;
		unsigned bit23 :1;

		unsigned bit24 :1;
		unsigned bit25 :1;
		unsigned bit26 :1;
		unsigned bit27 :1;
		unsigned bit28 :1;
		unsigned bit29 :1;
		unsigned bit30 :1;
		unsigned bit31 :1;
		}lw_bit;
}l_dword;

// STOP  TECNOMOTOR
//------------------------------------------------------------------------------


#endif                                 // End "ifndef" including this Header once
