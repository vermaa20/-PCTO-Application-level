#include "stdint.h"
//------------------------------------------------------------------------------
// HEADING

// PROJECT NAME:     Sis_NNN.prj/Sis_RAM_NNN.prj
// PROJECT RELEASE:  VIEW HEADING OF "sistema.c"
// FILE NAME:        vectors.h
// FILE RELEASE:     1.0
// DATE:             February 2004
// FILE DESCRIPTION: Contents Interrupt functions declarations and prototypes.
// REVIEW  BY:       Ing. Andrea Acunzo - Ing. Diego Mainardi
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// FURTHER INFORMATIONS

// Include this file in each C module you plan to
// use pointers to irqs/normal procedures pointed by
// the vectors stored in internal ram.
	
// In order to call the procedure pointed by the
// listed vectors you must use the following format:
	
//           (__far void (*)())vect044)();
	
// or, if you prefer, to keep the code more readable...
	
//           #define procedure_name ((__far void (*)())vect044)
	
//           procedure_name();
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// COMPILER DIRECTIVE

#ifndef VECTORS_H                     // To include this Header once and
#define VECTORS_H                     // avoiding extra compilation
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// CODE

#ifdef EMULATOR_ON 
	#ifndef BOOTLOADER_ON

//------------------------------------------------------------------------------
// Prototypes
   
// Add your own prototypes here. Each vector definition needs is proto-
// type. Either do it here or include a header file containing them.


// __interrupt void Irq_vect007					(void); // 7      Written in "Vectors.c"
// __interrupt void Irq_vect008					(void); // 8      Written in "Vectors.c"
#ifndef ACCEMIC_ON
	__interrupt void Irq_vect009					(void); // 9      Written in "Vectors.c"
#endif	
	__interrupt void Irq_vect010					(void); //10      Written in "Vectors.c"
	__interrupt void Irq_vect011					(void); //11      Written in "Vectors.c"
	__interrupt void Irq_vect012					(void); //12      Written in "Vectors.c"
	__interrupt void Irq_vect013					(void); //13      Written in "Vectors.c"
	__interrupt void Irq_vect014					(void); //14      Written in "Vectors.c"
	__interrupt void Irq_vect015					(void); //15      Written in "Vectors.c"
	__interrupt void Irq_vect016					(void); //16      Written in "Vectors.c"
	__interrupt void Irq_vect017					(void); //17      Written in "Vectors.c"
	__interrupt void Irq_vect018					(void); //18      Written in "Vectors.c"
	__interrupt void Irq_vect019					(void); //19      Written in "Vectors.c"
	__interrupt void Irq_vect020					(void); //20      Written in "Vectors.c"
	__interrupt void Irq_vect021					(void); //21      Written in "Vectors.c"
	__interrupt void Irq_vect022					(void); //22      Written in "Vectors.c"
	__interrupt void Irq_vect023					(void); //23      Written in "Vectors.c"
	__interrupt void Irq_vect024					(void); //24      Written in "Vectors.c"
	__interrupt void Irq_vect025					(void); //25      Written in "Vectors.c"
	__interrupt void Irq_vect026					(void); //26      Written in "Vectors.c"
	__interrupt void Irq_vect027					(void); //27      Written in "Vectors.c"
	__interrupt void Irq_vect028					(void); //28      Written in "Vectors.c"
	__interrupt void Irq_vect029					(void); //29      Written in "Vectors.c"
	__interrupt void Irq_vect030					(void); //30      Written in "Vectors.c"
	__interrupt void Irq_vect031					(void); //31      Written in "Vectors.c"
	__interrupt void Irq_vect032					(void); //32      Written in "Vectors.c"
	__interrupt void Irq_vect033					(void); //33      Written in "Vectors.c"
	__interrupt void Irq_vect034					(void); //34      Written in "Vectors.c"
	__interrupt void Irq_vect035					(void); //35      Written in "Vectors.c"
	__interrupt void Irq_vect036					(void); //36      Written in "Vectors.c"
	__interrupt void Irq_vect037					(void); //37      Written in "Vectors.c"
	__interrupt void Irq_vect038					(void); //38      Written in "Vectors.c"
	__interrupt void Irq_vect039					(void); //39      Written in "Vectors.c"
	__interrupt void Irq_vect040					(void); //40      Written in "Vectors.c"
	__interrupt void Irq_vect041					(void); //41      Written in "Vectors.c"
	__interrupt void Irq_vect042					(void); //42      Written in "Vectors.c"


//------------------------------------------------------------------------------
// Vector definiton

// Use following statements to define vectors. All resource related
// vectors are predefined. Remaining software interrupts can be added here
// as well.
// NOTE: If software interrupts 0 to 7 are defined here, this might 
// conflict with the reset vector in the start-up file.

    #ifdef ACCEMIC_ON
    	#pragma DefaultIRQHandler  9    // software interrupt 9         
    #else
		#pragma intvect Irq_vect009  9    // software interrupt 9         
	#endif
	#pragma intvect Irq_vect010 10    // exeception handler           
	#pragma intvect Irq_vect011 11    // CAN #0 (receive complete)    
	#pragma intvect Irq_vect012 12    // CAN #0 (transmission complete/node status transition) 
	#pragma intvect Irq_vect013 13    // CAN #1 (receive complete)    
	#pragma intvect Irq_vect014 14    // CAN #1 (transmission complete/node status transition) 
	#pragma intvect Irq_vect015 15    // external interrupt INT0/INT1
	#pragma intvect Irq_vect016 16    // timebase timer               
	#pragma intvect Irq_vect017 17    // 16-bit reload timer #0       
	#pragma intvect Irq_vect018 18    // A/D converter                
	#pragma intvect Irq_vect019 19    // I/O timer                    
	#pragma intvect Irq_vect020 20    // external interrupt INT2/INT3 
	#pragma intvect Irq_vect021 21    // serial I/O                   
	#pragma intvect Irq_vect022 22    // PPG #0/1                     
	#pragma intvect Irq_vect023 23    // input capture CH.0           
	#pragma intvect Irq_vect024 24    // external interrupt INT4/INT5 
	#pragma intvect Irq_vect025 25    // input capture CH.1           
	#pragma intvect Irq_vect026 26    // PPG #2/3                     
	#pragma intvect Irq_vect027 27    // external interrupt INT6/INT7 
	#pragma intvect Irq_vect028 28    // watch timer                  
	#pragma intvect Irq_vect029 29    // PPG #4/5                     
	#pragma intvect Irq_vect030 30    // input capture CH.2/3         
	#pragma intvect Irq_vect031 31    // PPG #6/7                     
	#pragma intvect Irq_vect032 32    // output compare CH.0          
	#pragma intvect Irq_vect033 33    // output compare CH.1          
	#pragma intvect Irq_vect034 34    // input capture CH.4/5         
	#pragma intvect Irq_vect035 35    // output compare CH.2/3 or input capture CH.6/7 
	#pragma intvect Irq_vect036 36    // 16-bit reload timer #1       
	#pragma intvect Irq_vect037 37    // UART #0 (receive complete)   
	#pragma intvect Irq_vect038 38    // UART #0 (transmission compl.)
	#ifndef ACCEMIC_ON
		#pragma intvect Irq_vect039 39    // UART #1 (receive complete)   
		#pragma intvect Irq_vect040 40    // UART #1 (transmission compl.)
	#else
		#pragma intvect DefaultIRQHandler 39    // UART #1 (receive complete)   
		#pragma intvect DefaultIRQHandler 40    // UART #1 (transmission compl.)
    #endif		
	#pragma intvect Irq_vect041 41    // IRQ41-handler                
	#pragma intvect Irq_vect042 42    // delayed interrupt            

	#endif
#endif

//------------------------------------------------------------------------------
// function/procedure declarations
__far void InitIrqLevels(void);                                 // Written in "Vectors.c"
__far void DefaultIRQHandler (void);                            // Written in "Vectors.c"
__far void redirect_function_table(int32_t _original, int32_t *_new); // Written in "Vectors.c"
__far void reset_function_table(void);                          // Written in "Vectors.c"

//------------------------------------------------------------------------------
// external declarations
extern __far void InitIrqLevels(void);                                 // Written in "Vectors.c"
extern __far void DefaultIRQHandler (void);                            // Written in "Vectors.c"
extern __far void redirect_function_table(int32_t _original, int32_t *_new); // Written in "Vectors.c"
extern __far void reset_function_table(void);                          // Written in "Vectors.c"

//------------------------------------------------------------------------------
// the following vectors are free
extern int32_t *vect000;
extern int32_t *vect001;
extern int32_t *vect002;
extern int32_t *vect003;
extern int32_t *vect004;
extern int32_t *vect005;
extern int32_t *vect006;
extern int32_t *vect007;

//------------------------------------------------------------------------------
// the following vectors are used by IRQs functions
extern int32_t *vect008;
extern int32_t *vect009;
extern int32_t *vect010;
extern int32_t *vect011;
extern int32_t *vect012;
extern int32_t *vect013;
extern int32_t *vect014;
extern int32_t *vect015;
extern int32_t *vect016;
extern int32_t *vect017;
extern int32_t *vect018;
extern int32_t *vect019;
extern int32_t *vect020;
extern int32_t *vect021;
extern int32_t *vect022;
extern int32_t *vect023;
extern int32_t *vect024;
extern int32_t *vect025;
extern int32_t *vect026;
extern int32_t *vect027;
extern int32_t *vect028;
extern int32_t *vect029;
extern int32_t *vect030;
extern int32_t *vect031;
extern int32_t *vect032;
extern int32_t *vect033;
extern int32_t *vect034;
extern int32_t *vect035;
extern int32_t *vect036;
extern int32_t *vect037;
extern int32_t *vect038;
extern int32_t *vect039;
extern int32_t *vect040;
extern int32_t *vect041;
extern int32_t *vect042;

//------------------------------------------------------------------------------
// the following vectors are free
extern int32_t *vect043;
extern int32_t *vect044;
extern int32_t *vect045;
extern int32_t *vect046;
extern int32_t *vect047;
extern int32_t *vect048;
extern int32_t *vect049;
extern int32_t *vect050;
extern int32_t *vect051;
extern int32_t *vect052;
extern int32_t *vect053;
extern int32_t *vect054;
extern int32_t *vect055;
extern int32_t *vect056;
extern int32_t *vect057;
extern int32_t *vect058;
extern int32_t *vect059;
extern int32_t *vect060;
extern int32_t *vect061;
extern int32_t *vect062;
extern int32_t *vect063;
extern int32_t *vect064;
extern int32_t *vect065;
extern int32_t *vect066;
extern int32_t *vect067;
extern int32_t *vect068;
extern int32_t *vect069;
extern int32_t *vect070;
extern int32_t *vect071;
extern int32_t *vect072;
extern int32_t *vect073;
extern int32_t *vect074;
extern int32_t *vect075;
extern int32_t *vect076;
extern int32_t *vect077;
extern int32_t *vect078;
extern int32_t *vect079;
extern int32_t *vect080;
extern int32_t *vect081;
extern int32_t *vect082;
extern int32_t *vect083;
extern int32_t *vect084;
extern int32_t *vect085;
extern int32_t *vect086;
extern int32_t *vect087;
extern int32_t *vect088;
extern int32_t *vect089;
extern int32_t *vect090;
extern int32_t *vect091;
extern int32_t *vect092;
extern int32_t *vect093;
extern int32_t *vect094;
extern int32_t *vect095;
extern int32_t *vect096;
extern int32_t *vect097;
extern int32_t *vect098;
extern int32_t *vect099;
extern int32_t *vect100;
extern int32_t *vect101;
extern int32_t *vect102;
extern int32_t *vect103;
extern int32_t *vect104;
extern int32_t *vect105;
extern int32_t *vect106;
extern int32_t *vect107;
extern int32_t *vect108;
extern int32_t *vect109;
extern int32_t *vect110;
extern int32_t *vect111;
extern int32_t *vect112;
extern int32_t *vect113;
extern int32_t *vect114;
extern int32_t *vect115;
extern int32_t *vect116;
extern int32_t *vect117;
extern int32_t *vect118;
extern int32_t *vect119;
extern int32_t *vect120;
extern int32_t *vect121;
extern int32_t *vect122;
extern int32_t *vect123;
extern int32_t *vect124;
extern int32_t *vect125;
extern int32_t *vect126;
extern int32_t *vect127;
extern int32_t *vect128;
extern int32_t *vect129;
extern int32_t *vect130;
extern int32_t *vect131;
extern int32_t *vect132;
extern int32_t *vect133;
extern int32_t *vect134;
extern int32_t *vect135;
extern int32_t *vect136;
extern int32_t *vect137;
extern int32_t *vect138;
extern int32_t *vect139;
extern int32_t *vect140;
extern int32_t *vect141;
extern int32_t *vect142;
extern int32_t *vect143;
extern int32_t *vect144;
extern int32_t *vect145;
extern int32_t *vect146;
extern int32_t *vect147;
extern int32_t *vect148;
extern int32_t *vect149;
extern int32_t *vect150;
extern int32_t *vect151;
extern int32_t *vect152;
extern int32_t *vect153;
extern int32_t *vect154;
extern int32_t *vect155;
extern int32_t *vect156;
extern int32_t *vect157;
extern int32_t *vect158;
extern int32_t *vect159;
extern int32_t *vect160;
extern int32_t *vect161;
extern int32_t *vect162;
extern int32_t *vect163;
extern int32_t *vect164;
extern int32_t *vect165;
extern int32_t *vect166;
extern int32_t *vect167;
extern int32_t *vect168;
extern int32_t *vect169;
extern int32_t *vect170;
extern int32_t *vect171;
extern int32_t *vect172;
extern int32_t *vect173;
extern int32_t *vect174;
extern int32_t *vect175;
extern int32_t *vect176;
extern int32_t *vect177;
extern int32_t *vect178;
extern int32_t *vect179;
extern int32_t *vect180;
extern int32_t *vect181;
extern int32_t *vect182;
extern int32_t *vect183;
extern int32_t *vect184;
extern int32_t *vect185;
extern int32_t *vect186;
extern int32_t *vect187;
extern int32_t *vect188;
extern int32_t *vect189;
extern int32_t *vect190;
extern int32_t *vect191;
extern int32_t *vect192;
extern int32_t *vect193;
extern int32_t *vect194;
extern int32_t *vect195;
extern int32_t *vect196;
extern int32_t *vect197;
extern int32_t *vect198;
extern int32_t *vect199;
extern int32_t *vect200;
extern int32_t *vect201;
extern int32_t *vect202;
extern int32_t *vect203;
extern int32_t *vect204;
extern int32_t *vect205;
extern int32_t *vect206;
extern int32_t *vect207;
extern int32_t *vect208;
extern int32_t *vect209;
extern int32_t *vect210;
extern int32_t *vect211;
extern int32_t *vect212;
extern int32_t *vect213;
extern int32_t *vect214;
extern int32_t *vect215;
extern int32_t *vect216;
extern int32_t *vect217;
extern int32_t *vect218;
extern int32_t *vect219;
extern int32_t *vect220;
extern int32_t *vect221;
extern int32_t *vect222;
extern int32_t *vect223;
extern int32_t *vect224;
extern int32_t *vect225;
extern int32_t *vect226;
extern int32_t *vect227;
extern int32_t *vect228;
extern int32_t *vect229;
extern int32_t *vect230;
extern int32_t *vect231;
extern int32_t *vect232;
extern int32_t *vect233;
extern int32_t *vect234;
extern int32_t *vect235;
extern int32_t *vect236;
extern int32_t *vect237;
extern int32_t *vect238;
extern int32_t *vect239;
extern int32_t *vect240;
extern int32_t *vect241;
extern int32_t *vect242;
extern int32_t *vect243;
extern int32_t *vect244;
extern int32_t *vect245;
extern int32_t *vect246;
extern int32_t *vect247;
extern int32_t *vect248;
extern int32_t *vect249;
extern int32_t *vect250;
extern int32_t *vect251;
extern int32_t *vect252;
extern int32_t *vect253;
extern int32_t *vect254;
extern int32_t *vect255;


#endif                                 // End "ifndef" including this Header once
