#include "stdint.h"
// ******************************************************************
// Multiplexer module header
// ******************************************************************

#include "mb90540.h"
#include "typedefs.h"			// usefull type definitions 


// structures and types
// xxx NOT PRESENT IN THE ORIGINAL MODULE
typedef struct _program_serial_com_struct_type
{
	BYTE	line;				// communication line (phisical line ex: CONNECTOR 4)
	DWORD	baud_rate;			// baud rate
	BYTE	mux_used;			// external mux used or not (1=used)
	BYTE	mux_int_cfg;		// protocol to be used
	DWORD	mux_ext_cfg;		// external mux configuration
	WORD	bbad_hw_version;	// hardware version detected by the Firmware
}program_serial_com_struct;

// defines
// times of the communication protocol
#define MUX_T_START			5							// ms
#define MUX_T_INTERVAL		2							// ms
#define MUX_T_INTERFRAME	50							// ms
#define MUX_T_WAIT_1		90							// us
#define MUX_T_WAIT_0		180							// us

// reception returned code
#define MUX_OK			0
#define MUX_TIMEOUT		1
#define MUX_ERROR		2
#define MUX_WRONG_CMD	3

// mux status defines
#define	MUX_PC_STATUS_IDLE				0x00
#define	MUX_PC_STATUS_CONNECTING		0x01
#define	MUX_PC_STATUS_OK				0x06
#define	MUX_PC_STATUS_TIMEOUT			0x80
#define	MUX_PC_STATUS_ERROR				0x81
#define	MUX_PC_STATUS_MISMATCH			0x82

// protocol defines
#define MUX_SOF					0x5B					// Start Of Frame
#define MUX_SET					0x4D					// MUX setting
#define MUX_READ				0x4E					// MUX reading
#define MUX_SERVICE_NAK			0x7F					// Service NAK

#define	MUX_STATUS_OK				0x00
#define	MUX_STATUS_BUSY				0x01
#define	MUX_STATUS_IDLE				0x02
#define	MUX_STATUS_CHECKSUM			0x6A
#define	MUX_STATUS_FAILURE			0x6B
#define	MUX_STATUS_FUNCTION_NA		0x6C

// analog switches defines
#define		AS_OFF			0x00
#define		AS_KL 			0x01
#define		AS_CAN			0x02
#define		AS_J1850_PWM	0x04
#define		AS_J1850_VPW	0x08
#define		AS_485			0x10
#define		AS_AMICO		0x20
#define		AS_K_RENAULT	0x40
#define		AS_K_FIAT		0x80

// used in Setta_mux procedure
#define		SM_NO_STANDARD		0
#define		SM_K_L_9141			1
#define		SM_K_L_K2000		2
#define		SM_PWM_J1850		3
#define		SM_VPW_J1850		4
#define		SM_CAN				5
#define		SM_485				6
#define		SM_AMICO			7
#define		SM_K_RENAULT		8
#define		SM_K_FIAT			9
#define 	SM_ENDOK_HW6		0x80
#define 	SM_ENDOK_HW7		0x82
#define 	SM_ENDKO_HW6		0x81
#define 	SM_RUNNING			0x40


// *****************************************************************
// hardware 7 related defines

// the following macros are used to write in the internal mux latches
#define HW7_WRITE_SWITCH_A(_value) (*(WORD __far *)(0xE00000) = (_value))
#define HW7_WRITE_SWITCH_B(_value) (*(WORD __far *)(0xE40000) = (_value))

// MUX Latches status
#define HW7_MUX_ON		0
#define HW7_MUX_OFF		1

// allowed protocols
#define		HW7_PROT_OFF		0x00
#define		HW7_PROT_KL 		0x01
#define		HW7_PROT_CAN		0x02
#define		HW7_PROT_J1850_PWM	0x04
#define		HW7_PROT_J1850_VPW	0x08
#define		HW7_PROT_485		0x10
#define		HW7_PROT_AMICO		0x20
#define		HW7_PROT_K_RENAULT	0x40
#define		HW7_PROT_K_FIAT		0x80

// setup for internal mux
#define		HW7_SETUP_KL 		0
#define		HW7_SETUP_CAN		1
#define		HW7_SETUP_J1850_PWM	2
#define		HW7_SETUP_J1850_VPW	3
#define		HW7_SETUP_485		4
#define		HW7_SETUP_AMICO		5
#define		HW7_SETUP_K_RENAULT	6
#define		HW7_SETUP_K_FIAT	7

// setup for external mux
#define		HW7_EXT_MUX_PIN_1		0x01
#define		HW7_EXT_MUX_PIN_2		0x02
#define		HW7_EXT_MUX_PIN_3		0x04
#define		HW7_EXT_MUX_PIN_6		0x20
#define		HW7_EXT_MUX_PIN_7		0x40
#define		HW7_EXT_MUX_PIN_8		0x80
#define		HW7_EXT_MUX_PIN_9		0x100
#define		HW7_EXT_MUX_PIN_10		0x200
#define		HW7_EXT_MUX_PIN_11		0x400
#define		HW7_EXT_MUX_PIN_12		0x800
#define		HW7_EXT_MUX_PIN_13		0x1000
#define		HW7_EXT_MUX_PIN_14		0x4000
#define		HW7_EXT_MUX_PIN_15		0x2000
// *****************************************************************

// xxx NOT PRESENT IN THE ORIGINAL MODULE
#define HW_V7 0x0700
#define HW_V6 0x0600


// *****************************************************************
// *****************************************************************
// if MUX_LOW_LEVEL_C is defined the compiler will define variables
// otherwise it shares the variables with the other modules
#ifdef MUX_LOW_LEVEL_C
	BYTE	mux_command_frame[16];					// array used for mux frames
	BYTE	mux_response_frame[16];					// array used for mux frames
	WORD	mux_status;								// word used for mux status
	DWORD	mux_ext_cfg;							// external mux configuration
	BYTE	mux_int_cfg;							// internal mux configuration

	// the following table is used to set the internal mux in HW7
	// the latches setup is the same for both BUS+ and BUS- (latches A & B)
	const WORD	hw7_eobd_pin[16] = {0x0001, 0x0002, 0x0004, 0x0000, 0x0000, 0x0008, 0x0010, 0x0020, 
									0x0040, 0x0080, 0x0100, 0x0200, 0x0400, 0x1000, 0x0800, 0x0000};

	// the following tables are used to set the internal mux in HW7
	// the latches setup is different for BUS+ and BUS-
	const WORD	hw7_protocols_a[8] = {0x2000, 0x8000, 0x4000, 0x4000, 0x0000, 0x0000, 0x0000, 0x0000};
	const WORD	hw7_protocols_b[8] = {0x2000, 0x0000, 0x0000, 0x0000, 0x4000, 0x0000, 0x8000, 0x0000};

	// xxx NOT PRESENT IN THE ORIGINAL MODULE
	program_serial_com_struct program_serial_port;
	program_serial_com_struct *p_program_serial_port;
	WORD bbad_hw_version;
#else
	extern BYTE			mux_command_frame[2];			// array used for mux frames
	extern BYTE			mux_response_frame[1];			// array used for mux frames
	extern WORD			mux_status;						// word used for mux status
	extern DWORD		mux_ext_cfg;					// external mux configuration
	extern BYTE			mux_int_cfg;					// internal mux configuration
	extern const WORD	hw7_eobd_pin[16];				// this is used to set the internal mux in HW7
	extern const WORD	hw7_protocols_a[8];				// this is used to set the internal mux in HW7
	extern const WORD	hw7_protocols_b[8];				// this is used to set the internal mux in HW7

	// xxx NOT PRESENT IN THE ORIGINAL MODULE
	extern program_serial_com_struct program_serial_port;
	extern program_serial_com_struct *p_program_serial_port;
	extern WORD bbad_hw_version;
#endif

// *****************************************************************
// *****************************************************************
// extern declaration
extern __far void mux_init(void);
extern __far void mux_send_frame(BYTE *_p_frame);
extern __far BYTE mux_get_frame(BYTE *_p_frame);
extern __far void analog_switch_driver(uint8_t _direction);
extern __far void mux_lines_reset(void);
extern __far void analog_switch_handler(void);
extern __far void hw7_mux_init(void);
extern __far void hw7_mux_handler(void);
extern __far int16_t Setta_mux(int16_t _protocollo,int16_t _reset);
extern __far void build_mux_frame(int16_t _protocollo);
extern __far void usa_mux();

