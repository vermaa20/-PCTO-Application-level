#include "stdint.h"
/* Include this file into each C file which contains RAM code. */
/* All program code (of __far as well as of __near functions) */
/* of the C file will then be assigned to segment "EXTRAMCODE". */

// modificato da A.A. De Filippo per poter lavorare completamente in ram
// la riga 1 identifica l'area in cui viene allocato il codice
// la riga 2 identifica l'area dove vengono allocate le variabili non inizializzate
// la riga 3 identifica l'area dove vengono allocate le variabili inizializzate
// la riga 4 identifica l'area in cui vengono allocate le costanti (es: stringhe)

#pragma section CODE=EXTRAMCODE, attr=CODE				//1
#pragma section FAR_CODE=EXTRAMCODE, attr=CODE			//1

#pragma section DATA=EXTRAMDATA, attr=DATA			//2
#pragma section FAR_DATA=EXTRAMDATA, attr=DATA		//2

#pragma section INIT=EXTRAMINIT, attr=DATA			//3
#pragma section FAR_INIT=EXTRAMINIT, attr=DATA		//3

#pragma section CONST=EXTRAMCONST, attr=CONST		//3
#pragma section FAR_CONST=EXTRAMCONST, attr=CONST	//4

#pragma section DCONST=EXTRAMDCONST, attr=CONST		//4
#pragma section FAR_DCONST=EXTRAMDCONST, attr=CONST	//4
