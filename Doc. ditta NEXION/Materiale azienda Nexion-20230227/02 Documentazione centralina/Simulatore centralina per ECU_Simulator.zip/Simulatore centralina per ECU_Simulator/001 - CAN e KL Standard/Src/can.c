#include "stdint.h"

/* can.c
*******************************************************************
**                                                              
**	                       CAN FUNCTIONS                              
**                                                              
**              	functions for accesing the CAN
**          
**	
*******************************************************************
*/

#define CAN_C
//#include "emulator.h"
#ifndef	EMULATOR_ON
#include "ram_code.h"
#endif

#include "mb90540.h"
#include "can.h"
#include "hw.h"
#include "types.h"

extern uint16_t	timer_rx_frame_com_et;
//---------------------------------------------------------------
extern uint16_t  timer_attivazione;
extern uint16_t  timer_tester_present;

extern uint8_t tx_com_pc[100];
extern uint8_t 	eotx_com_pc, indice_tx_com_pc;

#define OK				0x80

extern tipo_ECU ECU;

#define debug_led PDRA_PA0

// Inizio variabili per Settaggi
// uint8_t Baud_Rate_Imp=1;   // =="1" per 500kbit/s (default), "0" per 250kbit/s
uint16_t Baud_Rate;         // Valore effettivamente assegnato al registro "BTR0" per impostare il baud-Rate

/*
uint8_t Can_Type_Id_Imp=1; // =="1" per CAN standard a 11 bit (default), "0" per CAN esteso a 29 bit
uint16_t Can_Type_Id;       // Valore effettivamente assegnato a IDER0 per impostare il protocollo CAN

uint32_t Id_Tester;          // Valore effettivamente assegnato per controlli sull'ID del Tester (a 11 o a 29 bit)
uint32_t Id_Ecu;             // Valore effettivamente assegnato per controlli sull'ID dell'ECU (a 11 o a 29 bit)
*/
// Fine variabili per Settaggi

__far void RxCan0(void) /* 11 CAN #0 (receive complete)    */
{
	RxCan0Local();
}

__far void TxCan0(void) /* 12 CAN #0 (Transmission complete)    */
{
	TxCan0Local();
}

void ResetRx(void)	//funzione per resettare il buffer di ricezione
{
	uint8_t _i;
	
	count_rx_buffer = 0;	//resetto il contatore
	
	for (_i=0; _i<LENGHT_RX_CAN_BUFFER; _i++)	//resetto il buffer di ricezione
		rx_can_buffer[_i] = 0;
	
	can_num = 0;			//resetto can_num
}

void CAN0_init(void)
{
   /*	
   // inizio settaggi
   if (ECU.baud_rate == 500000)
   {
     Baud_Rate = BAUD_RATE_500k; // Imposto valore per ottenere Baud-Rate di 500 kbit/s (default)
   } 
   // end if se Baud-Rate di 500 kbit/s (default)
   if (ECU.baud_rate == 250000)
   {
     Baud_Rate = BAUD_RATE_250k; // Imposto valore per ottenere Baud-Rate di 250 kbit/s
   } 
   if (ECU.baud_rate == 50000)
   {
   	 Baud_Rate = BAUD_RATE_50k;
   }
   // end else altrimenti Baud-Rate di 250 kbit/s
   */

	if (ECU.baud_rate == 20000)
       Baud_Rate = BAUD_RATE_200k; 
	if (ECU.baud_rate == 25000)
       Baud_Rate = BAUD_RATE_250k; 
	if (ECU.baud_rate == 30000)
       Baud_Rate = BAUD_RATE_300k; 
	if (ECU.baud_rate == 33000)
       Baud_Rate = BAUD_RATE_330k; 
	if (ECU.baud_rate == 33300)
       Baud_Rate = BAUD_RATE_333k; 
	if (ECU.baud_rate == 50000)
       Baud_Rate = BAUD_RATE_500k; 
	if (ECU.baud_rate == 83300)
       Baud_Rate = BAUD_RATE_833k; 
	if (ECU.baud_rate == 95000)
       Baud_Rate = BAUD_RATE_950k; 
	if (ECU.baud_rate == 100000)
       Baud_Rate = BAUD_RATE_1000k; 
	if (ECU.baud_rate == 125000)
       Baud_Rate = BAUD_RATE_1250k; 
	if (ECU.baud_rate == 200000)
       Baud_Rate = BAUD_RATE_2000k; 
	if (ECU.baud_rate == 250000)
       Baud_Rate = BAUD_RATE_2500k; 
	if (ECU.baud_rate == 333300)
       Baud_Rate = BAUD_RATE_3333k; 
	if (ECU.baud_rate == 500000)
       Baud_Rate = BAUD_RATE_5000k; 
	if (ECU.baud_rate == 1000000)
       Baud_Rate = BAUD_RATE_10M; 
	
   /*	
   if (Can_Type_Id_Imp)
   {
       Can_Type_Id = CAN_TYPE_ID_11; // Imposto valore per ottenere CAN standard a 11 bit (default)
       Id_Tester = ID_TESTER_11;     // Assegno ID a 11 bit del Tester
       Id_Ecu = ID_ECU_11;           // Assegno ID a 11 bit dell'ECU
   }                                 // end if se CAN standard a 11 bit (default)
   else
   {
       Can_Type_Id = CAN_TYPE_ID_29; // Imposto valore per ottenere CAN standard a 29 bit
       Id_Tester = ID_TESTER_29;     // Assegno ID a 29 bit del Tester
       Id_Ecu = ID_ECU_29;           // Assegno ID a 29 bit dell'ECU
   }          	                     // end else altrimenti CAN esteso a 29 bit
                                     // fine settaggi
   */ 

  CSR0         = 0x81;                 /* bit 7: enable transmit output pin  */
                                       /* bit 0: stop bus operation          */
  while (!CSR0_HALT);
  
  TCANR0       = 0xffff;               /* cancel all Transmissions           */
  BVALR0       = 0;                    /* all message buffer are invalid     */
  BTR0         = Baud_Rate;   				 /* <<< set bit timing                 */
  CSR0         = 0x0080;               /* activate can bus operation         */

  while (CSR0_HALT);                   /* wait for Bus-connection            */
    
/* NON NECESSARIA PERCHE' AZZERANDO GLI "AMRX--" AUTOMATICAMENTE SI AZZERANO ANCHE GLI"AMR--" CHE NE E' UN "SOTTOINSIEME"
  AMR00        = 0;                    // <<< acceptance mask definition 0
  AMR10        = 0;                    // <<< acceptance mask definition 1
*/
  AMRX00        = 0;                   /* <<< acceptance mask definition 0   */
  AMRX10        = 0;                   /* <<< acceptance mask definition 1   */
}


void CAN0_buffer1(void)
// RICEZIONE RICEZIONE RICEZIONE RICEZIONE RICEZIONE RICEZIONE RICEZIONE RICEZIONE 
{
/* CAN0: messagebuffer 1 will be used as receive-buffer                   */
  
  BVALR0_BVAL1 = 0;       	/* message buffer are invalid                   */

/* 
  SETTO TUTTI I BUFFER ALLO STESSO MODO ANZICHE' SOLO QUELLO EFFETTIVAMENTE USATO
  IDER0_IDE6   = 0;       		// <<< 0->11bit; 1->29bit indentifier
*/

/*
   IDER0 = Can_Type_Id; // Definisce il tipo di Id, standard (0x00) o esteso (0x01)
   if (Can_Type_Id_Imp)
     {
    	 IDR0(1) = Id_Ecu;  // ID ECU a 11 bit
     } // end if se CAN standard a 11 bit (default)
   else
     {
       IDRX0(1) = Id_Ecu; // ID ECU a 29 bit
     } // end else altrimenti CAN esteso a 29 bit
*/

   //IDER0 = ECU.id_length;  // Definisce il tipo di Id, standard (0x00) o esteso (0x01)
   
   if (ECU.id_length == 0)
   {
     IDER0 = 0x0000;
   	 IDR0(1) = (DWORD)ECU.id_risposta;  // ID ECU a 11 bit
   	 //IDR0(1) = 0x000000FC;  // ID ECU a 11 bit
   	 //IDR0(1) = 0x000040F9;  // ID ECU a 11 bit
   } 
   // end if se CAN standard a 11 bit (default)
   else
   {
     IDER0 = 0xFFFF; 
     IDRX0(1) = ECU.id_risposta; // ID ECU a 29 bit
   } 
   // end else altrimenti CAN esteso a 29 bit
          
  AMSR0_AMS1   = 0;       	/* <<< Acceptance Mask:                         */
                          	/* 0 : full bit compare (full can)              */
                          	/* 1 : full bit mask (basic can)                */
                          	/* 2 : use acceptance mask 0                    */
                          	/* 2 : use acceptance mask 1                    */

  TIER0_TIE1   = 0;       	/* <<< 0: diasble / 1: enable Trx-Interrupt     */

  RIER0_RIE1	 = 1; 		/* Abilito interrupt di rx						*/

  RFWTR0_RFWT1 = 0;       	/* <<< 0: no wait for remote request            */

  TRTRR0_TRTR1 = 0;       	/* <<< 0: Data / 1: Remote frame Trx            */

  BVALR0_BVAL1 = 1;       	/* message buffer are valid                     */
}


void CAN0_buffer6(void)
// TRASMISSIONE TRASMISSIONE TRASMISSIONE TRASMISSIONE TRASMISSIONE TRASMISSIONE TRASMISSIONE
{
/* CAN0: messagebuffer 6 will be used as send-buffer */
  
  BVALR0_BVAL6 = 0;       		/* message buffer are invalid                      */
	
/* 
  SETTO TUTTI I BUFFER ALLO STESSO MODO ANZICHE' SOLO QUELLO EFFETTIVAMENTE USATO
  IDER0_IDE6   = 0;       		// <<< 0->11bit; 1->29bit indentifier
*/


   //IDER0 = ECU.id_length; // Definisce il tipo di Id, standard (0x00) o esteso (0x01)



   if (ECU.id_length == 0)
   {
   	 IDER0 = 0x0000; 
   	 IDR0(6) = ECU.id_domanda;  // ID TESTER a 11 bit
   	 //IDR0(6) = 0x000000F6;  // ID TESTER a 11 bit
   } 
   // end if se CAN standard a 11 bit (default)
   else
   {
     IDER0 = 0xFFFF; 
     IDRX0(6) = ECU.id_domanda; // ID TESTER a 29 bit
   } 
   // end else altrimenti CAN esteso a 29 bit

  AMSR0_AMS6   = 0;       /* <<< Acceptance Mask:                            */
                          /* 0 : full bit compare (full can)                 */
                          /* 1 : full bit mask (basic can)                   */
                          /* 2 : use acceptance mask 0                       */
                          /* 2 : use acceptance mask 1                       */

  TIER0_TIE6   = 0;       /* <<< 0: diasble / 1: enable Trx-Interrupt        */

  RFWTR0_RFWT6 = 0;       /* <<< 0: no wait for remote requeset              */

  TRTRR0_TRTR6 = 0;       /* <<< 0: Data / 1: Remote frame Trx               */

  BVALR0_BVAL6 = 1;       /* message buffer are valid                        */
}

/*---------------------------------------------------------------------*/
WORD SwapByte(WORD w)
{
	WORD wH;
	WORD wa;
	wH = w >>8;
	wa = w <<8;
	wa |= wH;
	return wa;
}

/*---------------------------------------------------------------------*/
// spedisce il contenuto di can_pack_tx
void PutPackCan (uint8_t len)
{
//int32_t j;	
	//DLCR0(6) = 8;				// lunghezza dati
	DLCR0(6) = len > 8 ? 8 : len;				// lunghezza dati

	//carico nel buffer 6 il contenuto di can_pack_tx
	
	DTR0_WORD(6,0) = (WORD)((WORD)can_pack_tx[0]+0x100*(WORD)can_pack_tx[1]); // dati
	DTR0_WORD(6,1) = (WORD)((WORD)can_pack_tx[2]+0x100*(WORD)can_pack_tx[3]);	// dati
	DTR0_WORD(6,2) = (WORD)((WORD)can_pack_tx[4]+0x100*(WORD)can_pack_tx[5]);	// dati
	DTR0_WORD(6,3) = (WORD)((WORD)can_pack_tx[6]+0x100*(WORD)can_pack_tx[7]);	// dati
	
	ResetOrol (&timer_tester_present);
	ResetOrol (&timer_attivazione);
	
	/*
	DTR0_BYTE(6,0) = can_pack_tx[0];
	DTR0_BYTE(6,1) = can_pack_tx[1];
	DTR0_BYTE(6,2) = can_pack_tx[2];
	DTR0_BYTE(6,3) = can_pack_tx[3];
	DTR0_BYTE(6,4) = can_pack_tx[4];
	DTR0_BYTE(6,5) = can_pack_tx[5];
	DTR0_BYTE(6,6) = can_pack_tx[6];
	DTR0_BYTE(6,7) = can_pack_tx[7];
	*/

	TREQR0 = 1 << 6;	//Abilito la trasmissione		        

	
	while(TxEmptyCan() == FALSE);

	
/*	j=0;
	while(!TxEmptyCan)
		{
		j++;//anto per verificare che il prec msg 
		if(j>2000)
		   break;			
		}		   //sia ok		
*/

}


/*---------------------------------------------------------------------*/
// Controlla che il precedente msg del can0 sia stato trasmesso
BOOL TxEmptyCan(void)
{
	if (TREQR0_TREQ6 && !CSR0_HALT)
		return FALSE;		
	else
   		return TRUE;
}

/*---------------------------------------------------------------------*/
// Gestore di interrupt, per il momento gestisce solo il Can0, buffer0
void TxCan0Local (void)
{
  if(TCR0_TC0)		// Quando si � completata una tx, questo bit deve essere
	TCR0_TC0 = 0;	// ad 1, lo pongo a zero per far avvenire una nuova tx
}
/*---------------------------------------------------------------------*/

// Gestore d'interrupt (� lo stesso per tutti i buffer), non controlla gli altri buffer
// Copia le seguenti informazioni provenienti
// dal buffer0 del CAN0 e li mette in serial0(Tx):
//   Apertura pacchetto '[' (1 byte)
//   ID_message
//   Tipo di pacchetto (DATA, REQUEST)
//   Lunghezza messaggio
//   Dati (se lunghezza messaggio > 0)
//   Chiusura pacchetto ']'
//	  CAN_ID(buf,i)	=>	(Frame[buf].ID[i])
//	  CAN_TYPE (buf)	=>	(Frame[buf].Type)
//    CAN_LEN(buf)	 =>	(Frame[buf].Len)
//	  CAN_DATA(buf,i)	=> 7(Frame [buf].Data[i])
void RxCan0Local(void)	//fuzione che gestisce l'interrupt di ricezione
{
    uint8_t _len, _pos;
    uint8_t cksum, indice;
    
	ResetOrol (&timer_rx_frame_com_et);

	if (RCR0_RC1)  /* <<< wait for receive complete indication of buffer 1 */
	{	
		do
    	{
    		ROVRR0 = ~(1 << 1);               /* clear Overrun-flag Buffer 1 */
   			_len = DLCR0(1);
  			
  			can_num++;		//incremento can_num per ogni pacchetto che ricevo  			
   			
  			eotx_com_pc 	    = 0;
   			indice_tx_com_pc  = 0;
   			
				tx_com_pc[eotx_com_pc++] = 0x5B;
				tx_com_pc[eotx_com_pc++] = 0;
				tx_com_pc[eotx_com_pc++] = 0;
				tx_com_pc[eotx_com_pc++] = 0x30;
				tx_com_pc[eotx_com_pc++] = 0x32 + 0x40;
				tx_com_pc[eotx_com_pc++] = OK;
				
  			count_rx_buffer =0;
    		
    		for (_pos=0; _pos< _len; _pos++)
	  		{
	  			
	  			if (count_rx_buffer >= LENGHT_RX_CAN_BUFFER)	//per sicurezza
	  				break;
	  			//rx_can_buffer[count_rx_buffer++] = DTR0_BYTE(1, _pos);
	  			tx_com_pc[eotx_com_pc++]= DTR0_BYTE(1, _pos);
				}
				
		
				if(DTR0_BYTE(1,1)==0x3e)
				{
					can_pack_tx[0] = 0x02;
					can_pack_tx[1] = 0x7e;
					can_pack_tx[2] = 0x00;
					//ECU.id_domanda = 0x000000fd;
			
					//CAN0_buffer6();
					PutPackCan(3);	
					can_num=0;
				}
			
				tx_com_pc[1] = ((eotx_com_pc + 1)&0x00FF00)>>8;
   			tx_com_pc[2] = (eotx_com_pc + 1)&0x00FF;
   			
				cksum = 0;
				for (indice = 0; indice < eotx_com_pc; indice++)
				{
					cksum ^= tx_com_pc[indice];
				}
				tx_com_pc[eotx_com_pc++] = cksum;
				    		
     	}  
     	while (ROVRR0_ROVR1);  /* check for overrun: 
                               It may happen that another 
                               CAN-message is received while data was stored  */

      	RCR0 = ~(1 << 1); /* clear Receive IRQ: RCR_RCx=0; */
	}
}

/*---------------------------------------------------------------------*/


