#include "stdint.h"
// ******************************************************************
// serial communication header
// ******************************************************************

#include "mb90540.h"
#include "typedefs.h"			// usefull type definitions 


// strutture o tipi

typedef struct _per_com
{
	// rx & tx buffer related variables
	uint8_t	*rx_buf;		// rx buffer pointer
	uint16_t	rx_buf_len;		// rx buffer length
	uint16_t  rx_in;			// rx buffer input pointer
	uint16_t  rx_out;			// rx buffer output pointer

	uint8_t	*tx_buf;		// tx buffer pointer
	uint16_t  tx_buf_len;		// tx buffer length
	uint16_t  tx_in;			// tx buffer input pointer
	uint16_t	tx_out;			// tx buffer output pointer

	// handle variables
	uint8_t	fase_rx;
	uint8_t	*scan_ptr;
	uint16_t	frame_act_length;
	uint16_t	frame_time;

	// protocol variables
	// WARNING!!! do not change the sequence of the following variables
	uint8_t	target;
	uint8_t	source;
	uint8_t	frame_id;
	uint16_t	frame_length;          	
	uint8_t	function;
	uint8_t	service;
	uint8_t	service_type;
	uint16_t	data_ptr;				// data field pointer
	uint16_t	data_length;          	// data field length
	uint16_t	rx_ck;					// cksum ricevuto
	uint16_t	calc_ck;				// cksum calcolato
	uint16_t	tx_calc_ck;				// calcolato per il pacchetto da inviare
	uint8_t	status;					// frame status flags 

	//
}per_com;

// general
#define SOT	'['					// start of frame
#define FRAMING_TIMEOUT	500		// [ms] usato in RxDecode per link seriali std

// bit declaration of the frame status
#define FRAME_STATUS_CLEAR		0x00
#define FRAME_STATUS_OK			0x01
#define FRAME_STATUS_CKS_ERR	0x02
#define FRAME_STATUS_PROCESSING	0x04
#define FRAME_STATUS_PROCESSED	0x08
#define FRAME_STATUS_FUNC_ERR	0x10
#define FRAME_STATUS_SERV_ERR	0x20
#define FRAME_STATUS_TYPE_ERR	0x40
#define FRAME_STATUS_BIT7		0x80

// please, use the following to allocate space for the serial channels
#define NUMBER_OF_SERIALS 4

// please, use the following generate code for the desired channels
#define ENABLE_COM_0
#define ENABLE_COM_1
#define ENABLE_COM_2
#define ENABLE_COM_3

// blocks for each serial channel
// COM_0
#ifdef ENABLE_COM_0
	#define RX_BUF_LEN_0	10               // 
	#define TX_BUF_LEN_0	10               // 
#else
	#define RX_BUF_LEN_0	1               // 
	#define TX_BUF_LEN_0	1               // 
#endif

// COM_1
#ifdef ENABLE_COM_1
	#define RX_BUF_LEN_1	128               // 
	#define TX_BUF_LEN_1	32     			// 
#else
	#define RX_BUF_LEN_1	1               // 
	#define TX_BUF_LEN_1	1   			// 
#endif

// COM_2
#ifdef ENABLE_COM_2
	#define RX_BUF_LEN_2	32              // 
	#define TX_BUF_LEN_2	160              // 

	#define DUART_CLOCK_RATE 3686400
	#define DUART_BASE_ADDR 0x400000

	#define DUART_RXBUFFER_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+8)
	#define DUART_TXBUFFER_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+8)
	#define DUART_IRQENABLE_1  		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+9)
	#define DUART_IRQID_1 			*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+10)
	#define DUART_FIFOCTRL_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+10)
	#define DUART_LINECTRL_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+11)
	#define DUART_MODEMCTRL_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+12)
	#define DUART_LINESTATUS_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+13)
	#define DUART_MODEMSTATUS_1 	*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+14)
	#define DUART_SCRATCH_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+15)
	#define DUART_DIVISORLOW_1 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+8)
	#define DUART_DIVISORHIGH_1		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+9)
	#define DUART_ALTERNATE_1		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+10)
#else
	#define RX_BUF_LEN_2	1              // 
	#define TX_BUF_LEN_2	1              // 
#endif

// COM_3
#ifdef ENABLE_COM_3
	#define RX_BUF_LEN_3	10               // 
	#define TX_BUF_LEN_3	10   			// 

	#ifndef DUART_CLOCK_RATE
		#define DUART_CLOCK_RATE 3686400
		#define DUART_BASE_ADDR 0x400000
	#endif

	#define DUART_RXBUFFER_2		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR)
	#define DUART_TXBUFFER_2 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR)
	#define DUART_IRQENABLE_2  		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+1)
	#define DUART_IRQID_2 			*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+2)
	#define DUART_FIFOCTRL_2 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+2)
	#define DUART_LINECTRL_2 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+3)
	#define DUART_MODEMCTRL_2 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+4)
	#define DUART_LINESTATUS_2 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+5)
	#define DUART_MODEMSTATUS_2 	*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+6)
	#define DUART_SCRATCH_2 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+7)
	#define DUART_DIVISORLOW_2 		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR)
	#define DUART_DIVISORHIGH_2		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+1)
	#define DUART_ALTERNATE_2		*(uint8_t __far *)((uint32_t)DUART_BASE_ADDR+2)
#else
	#define RX_BUF_LEN_3	1               // 
	#define TX_BUF_LEN_3	1   			// 
#endif

// *****************************************************************
// *****************************************************************
// if SERIAL_C is defined the compiler will define variables
// otherwise it shares the variables with the other modules
#ifdef SERIAL_C
	per_com com[NUMBER_OF_SERIALS];

	// COM_0
	uint8_t rx_buf_com0[RX_BUF_LEN_0];        // rx buffer COM 0
	uint8_t tx_buf_com0[TX_BUF_LEN_0];        // tx buffer COM 0

	// COM_1
	uint8_t rx_buf_com1[RX_BUF_LEN_1];        // rx buffer COM 1
	uint8_t tx_buf_com1[TX_BUF_LEN_1];        // tx buffer COM 1

	// COM_2
	uint8_t rx_buf_com2[RX_BUF_LEN_2];        // rx buffer COM 2
	uint8_t tx_buf_com2[TX_BUF_LEN_2];        // tx buffer COM 2

	// COM_3
	uint8_t rx_buf_com3[RX_BUF_LEN_3];        // rx buffer COM 3
	uint8_t tx_buf_com3[TX_BUF_LEN_3];        // tx buffer COM 3

	per_com *com_struct_ptr[NUMBER_OF_SERIALS];		// pointers to previous structures
#else
	extern per_com com[];

	// COM_0
	extern uint8_t rx_buf_com0[];        // rx buffer COM 0
	extern uint8_t tx_buf_com0[];        // tx buffer COM 0

	// COM_1
	extern uint8_t rx_buf_com1[];        // rx buffer COM 1
	extern uint8_t tx_buf_com1[];        // tx buffer COM 1

	// COM_2
	extern uint8_t rx_buf_com2[];        // rx buffer COM 2
	extern uint8_t tx_buf_com2[];        // tx buffer COM 2

	// COM_3
	extern uint8_t rx_buf_com3[];        // rx buffer COM 3
	extern uint8_t tx_buf_com3[];        // tx buffer COM 3

	extern per_com *com_struct_ptr[];		// pointers to previous structures
#endif

extern uint16_t timeout_com_pc;

// *****************************************************************
// *****************************************************************
//Prototypes

__far void HwComInit(void);
__far void SetBaudRate(uint8_t _chan, int32_t _baud);
__far void ComInit(void);
__far void RxSer0(void);
__far void TxSer0(void);
__far void RxSer1(void);
__far void TxSer1(void);
__far void RxSer2(void);
__far void TxSer2(void);
__far void RxSer3(void);
__far void TxSer4(void);
__far void DuartReset(void);
__far void PutByte(uint8_t _com, uint8_t _ch);
__far void PutString(uint8_t _com, uint8_t *_str);
__far void PutLong(uint8_t _com, int32_t _val, uint8_t _len);
__far void PutHex(uint8_t _com, int32_t _val, uint8_t _len);
__far void Sveglia_tx(uint8_t _com);
__far uint8_t BytesInShiftRegister(uint8_t _com);
__far uint8_t BytesInReceiveBuffer(uint8_t _com);
__far uint8_t BytesInTxBuffer(uint8_t _com);
__far uint8_t GetByte(uint8_t _com);
__near uint8_t GetBytefromBuffer(uint8_t K_L, uint8_t offset);
__far void EnableCom(uint8_t _chan);
__far void DisableCom(uint8_t _chan);
// *****************************************************************
// *****************************************************************
// extern declaration
extern __far void HwComInit(void);
extern __far void SetBaudRate(uint8_t _chan, int32_t _baud);
extern __far void ComInit(void);
// extern __far void RxSer0(void);
// extern __far void TxSer0(void);
// extern __far void RxSer1(void);
// extern __far void TxSer1(void);
extern __far void RxSer2(void);
extern __far void TxSer2(void);
extern __far void RxSer3(void);
extern __far void TxSer4(void);
extern __far void DuartReset(void);
extern __far void PutByte(uint8_t _com, uint8_t _ch);
extern __far void PutString(uint8_t _com, uint8_t *_str);
extern __far void PutLong(uint8_t _com, int32_t _val, uint8_t _len);
extern __far void PutHex(uint8_t _com, int32_t _val, uint8_t _len);
extern __far void Sveglia_tx(uint8_t _com);
extern __far uint8_t BytesInShiftRegister(uint8_t _com);
extern __far uint8_t BytesInReceiveBuffer(uint8_t _com);
extern __far uint8_t BytesInTxBuffer(uint8_t _com);
extern __far uint8_t GetByte(uint8_t _com);
extern __far void EnableCom(uint8_t _chan);
extern __far void DisableCom(uint8_t _chan);
//-------------------------------



extern __far BOOL Tx_Empty(uint8_t _com);
extern __far void Put_and_ck(uint8_t _com, uint8_t car);
extern __far uint8_t Get_and_ck(uint8_t _com);
extern __far void Reset_rx(uint8_t _com);
extern __far void PutLongInt(uint8_t _com, int32_t _val, uint8_t _len);
extern __far void SetMatrice(uint8_t b_lo, uint8_t b_hi);

extern __far void duart_init(void);
extern __far void duart_reset(void);
extern __far void Duart_1_2 (void);

extern __far void RxSer0(void);
extern __far void RxSer1(void);
extern __far void TxSer0(void);
extern __far void TxSer1(void);
