#include "stdint.h"
/**********************************************************
*
* The following software is for demonstration purposes only. 
* It is not fully tested, nor validated in order to fullfill  
* its task under all circumstances. Therefore, this software  
* or any part of it must only be used in an evaluation        
* laboratory environment.                                    
* This software is subject to the rules of Accemic's 
* standard DISCLAIMER, available at www.accemic.com.
*
* Copyright (c) 2001-2003 Accemic GmbH & Co. KG 
* All rights reserved  
*
***********************************************************
*
* Module name        : monitor.h
* Version            : 1.0       
* Date of creation.  : 07.03.2003
* Last Modification  : 07.03.2003
* Authors            : Rainer Harthaus (RH)
* 
***********************************************************
* 
* Description: 
* monitor function prototypes
*
***********************************************************
*
* History
*
* Vers   * Datum    * Name  * Subject
* 1.00   * 07.03.03 * RH    * first creation
* 
***********************************************************
*
* Please visit www.accemic.com
* for updates and other valuable developer ressources
*
**********************************************************/

#ifndef MONFUNC_H
#define MONFUNC_H

#define FAR __far 

/**********************************************************
***********************************************************
*
* acc_printf
*
***********************************************************
***********************************************************
* 
* Description: 
* Displays text in the Target Message Box
* 
* Sample Project: Messaging
*
***********************************************************
* 
* Parameters:  
* Flag:		    See above
* Data:		    Pointer to data to transmit
* Position:	    Position of row (if type==ACC_TYPE_ROW)
* WaitOnSended: 0 Do not wait for tranmission end
*		        1 Wait for transmission end
* Buffer:		Transmission buffer;
*               must be at least sizeof(Data) + 5 Bytes
* 
***********************************************************
* 
* Return value:
* -1 :Error
*  0 :PC not connected or transmission not possible
*  1 :transmitted
*
***********************************************************
* 
* Remark: 
* Kernel will notify the end of transmission 
* by setting Buffer[0] to 0
**********************************************************/

extern uint8_t FAR (* FAR acc_printf) ( uint8_t Location,
                                         uint8_t Type,
                                         FAR void* Data,
                                         uint8_t Position,
                                         uint8_t WaitOnSended,
                                         FAR uint8_t* Buffer);
  
/**********************************************************
* Values for Location
**********************************************************/
#define ACC_TYPE_LISTBOX      0x00
#define ACC_TYPE_ROW_TEXT     0x08
#define ACC_TYPE_ROW_CAPTION  0xF0

/**********************************************************
* Defintions for types to display
* (specify if ACC_TYPE_LISTBOX or ACC_TYPE_ROW_TEXT)
**********************************************************/
#define ACC_TYPE_STRING       0x10
#define ACC_TYPE_UCHAR        0x30	/* 1 Byte   */
#define ACC_TYPE_CHAR         0x40  /* 1 Byte   */
#define ACC_TYPE_USHORT       0x50	/* 2 Bytes  */
#define ACC_TYPE_SHORT        0x60  /* 2 Bytes  */
#define ACC_TYPE_ULONG        0x70  /* 4 Bytes  */
#define ACC_TYPE_LONG         0x80  /* 4 Bytes  */
#define ACC_TYPE_FLOAT        0x90	/* 4 Bytes  */
#define ACC_TYPE_DOUBLE       0xA0	/* 8 Bytes  */

/**********************************************************
* Values for Wait
**********************************************************/
#define ACC_NOT_WAIT          0
#define ACC_WAIT              1


/**********************************************************
***********************************************************
*
* acc_MessageBox
*
***********************************************************
***********************************************************
* 
* Description: 
* Displays a Message Box on Accemic MDE
* 
* Sample Project: Messaging
*
***********************************************************
* 
* Parameters:  
* Msg:          Message text to show
* Flags:        See above
* Buffer:       Transmission buffer
*               must be at least sizeof(Msg) + 4 Bytes
* 
***********************************************************
* 
* Return value:
* -1 :Error
*  0 :PC not connected or transmission not possible
*  other: see above
*
**********************************************************/

extern uint8_t FAR (* FAR acc_MessageBox)(FAR uint8_t* Msg,
                                           uint8_t Flag, 
                                           FAR uint8_t* Buffer);

/**********************************************************
* Values for Flag
* Indicates what kind of button to show
**********************************************************/
#define MB_OK				  0
#define MB_OKCANCEL			  1
#define MB_ABORTRETRYIGNORE	  2
#define MB_YESNOCANCEL		  3
#define MB_YESNO              4
#define MB_RETRYCANCEL        5

/**********************************************************
* Return values
* Indicates what kind of button was pressed
**********************************************************/
#define IDERROR              -1  /* Error */
#define IDNOTCONNECTED        0  /* PC not connected or transmission not possible */
#define IDOK                  1	 /* Button OK     was pressed */
#define IDCANCEL              2	 /* Button Cancel was pressed */
#define IDABORT	              3	 /* Button Abort  was pressed */
#define IDRETRY	              4	 /* Button Retry  was pressed */
#define IDIGNORE              5  /* Button Ignore was pressed */
#define IDYES	              6	 /* Button Yes    was pressed */
#define IDNO	              7	 /* Button No     was pressed */



/**********************************************************
***********************************************************
*
* acc_WatchdogEnable
*
***********************************************************
***********************************************************
* 
* Description: 
* Enable Watchdog support of Accemic MDE
*
***********************************************************
* 
* Remark: 
* Should be called IMMEDIATELY BEFORE
* first watchdog activation
* 
**********************************************************/

extern void FAR (* FAR acc_WatchdogEnable)(void);


/**********************************************************
***********************************************************
*
* acc_KernelUART
*
***********************************************************
***********************************************************
* 
* Description: 
* Enable Watchdog support of Accemic MDE
*
***********************************************************
* 
* Parameters:  
* Disable:     0: Kernel UART is used by monitor kernel
*              1: Kernel UART can be used by application  
*
**********************************************************/

extern void FAR (* FAR acc_KernelUART)(uint8_t Disable);


/**********************************************************
***********************************************************
*
* acc_SetLockState
*
* Sample Project: Security
*
***********************************************************
***********************************************************
* 
* Description: 
* Set the lock/unlock state of the target 
*
***********************************************************
* 
* Parameters:
* State:	   1: No commands are accepted by the kernel
*              0: Kernel is unlocked	
*
**********************************************************/

extern void FAR(* FAR acc_SetLockState)(uint8_t State);

/**********************************************************
* Values for State
**********************************************************/
#define ACC_SYSTEM_LOCKED	            1
#define ACC_SYSTEM_UNLOCKED	            0

#define ACC_SECURE_KEY			        1
#define ACC_SECURE_PASSWORD		        2


/**********************************************************
* other defines
**********************************************************/

#define ACC_COMMAND_EMBOS				0x01
#define ACC_COMMAND_SECURE_CONNECTION 	0x02


#endif
