==========================================================================
                   Demo Project for DevKit16 MB90F543 Series
==========================================================================
                       FUJITSU MIKROELEKTRONIK GMBH                       
                   Am Siebenstein 6-10, 63303 Dreieich                    
                    Tel.: ++49 (6103) 690-0, Fax -122                     
                                                            
 The following  software  is for  demonstration  purposes only.  It is not
 fully  tested, nor validated  in order  to fullfill  its task  under  all
 circumstances.  Therefore,  this software or  any part of it must only be
 used in an evaluation laboratory environment.                                    
 This software is subject to the rules of our standard DISCLAIMER, that is
 delivered with our  SW-tools on the CD  "Micros Documentation & Software"
 (V3.1 see "\START.HTM") or see our Internet Page:
 http://www.fujitsu-fme.com/products/micro/disclaimer.html  
==========================================================================
               
History
Date      Ver   Author  Softune  Description
30.09.99  1.00   tka    V30L22   original version

==========================================================================

